<!-- coderabbit-ai-generated:v1 -->

# Continuum reliability QA

Scope: full-node. Status: **PASS**. Commit: 5d91442e98f78a2af623b8a3c74920805f670cb9.

Node 24.22.1; linux/x64. Source unchanged during run: true.

| Check | Severity | Status | Exit | PASS / FAIL / SKIP |
|---|---|---|---|---|
| full-node | P0 | PASS | 0 | 2398 / 0 / 31 |
| gradle | P0 | NOT_RUN | — | — / — / — |
| lint | P0 | NOT_RUN | — | — / — / — |
| apk | P0 | NOT_RUN | — | — / — / — |
| fold7 | P0 | NOT_RUN | — | — / — / — |
| model-inference | P0 | NOT_RUN | — | — / — / — |

PASS applies only to executed tests in the selected scope. JSON contains commands, case identities, diagnostics, source hashes and original process outcomes. Gradle/lint/APK/device/model inference remain NOT_RUN. No signing or deployment.

<!-- /coderabbit-ai-generated:v1 -->
