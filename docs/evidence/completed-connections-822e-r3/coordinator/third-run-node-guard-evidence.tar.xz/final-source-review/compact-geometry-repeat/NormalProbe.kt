import at.heinz.deviceai.ui.JarvisShellLayout
import at.heinz.deviceai.ui.JarvisShellLayout.Box

private fun bits(v: Float) = v.toRawBits().toUInt().toString(16)
private fun box(v: Box?) = v?.let {
    listOf(it.left, it.top, it.right, it.bottom).joinToString(",") { n -> bits(n) }
} ?: "null"

fun main() {
    val windows = listOf(280f to 720f, 412f to 915f, 600f to 840f, 840f to 649f,
        840f to 1050f, 1280f to 800f, 1536f to 1024f)
    for ((w, h) in windows) for (font in listOf(1f, 1.3f, 1.5f, 2f)) {
        val s = JarvisShellLayout.forContent(w, h, font)
        val p = s.profile
        val fields = mutableListOf("profile=$w,$h,$font", "form=${s.formFactor}",
            "width=${bits(s.width)}", "height=${bits(s.height)}",
            "viewport=${bits(s.viewportHeight)}", "gap=${bits(s.tileGap)}",
            "tiles=${s.tileColumns},${s.tileRows}", "rail=${s.rail}", "overlays=${s.overlays}",
            "window=${p.widthClass},${bits(p.fontScale)},${p.tileColumns},${p.informationColumns},${bits(p.railWidthDp)},${p.referenceComposition}")
        for ((slot, b) in s.boxes) fields += "$slot=${box(b)}"
        s.grid?.let { g ->
            fields += "grid=${bits(g.width)},${bits(g.height)},${bits(g.unit)}"
            for ((area, b) in g.areas) fields += "grid.$area=${box(b)}"
        }
        fields += "head=${box(s.headBounds)}"
        fields += "orb=${box(s.orbBounds)}"
        println(fields.joinToString("|"))
    }
}
