# Compact geometry repeat

This is an explicitly identified repeat of the earlier lightweight geometry check. The first temporary harness was removed after commit; its retained tool stdout is copied in `original-tool24b025.txt`. These probes were reconstructed for a reproducible evidence bundle. They use the same seven window sizes, four font scales and stated geometry criteria; their source text is not claimed to be a recovered copy of the deleted harness.

Only committed source bytes are compiled: baseline `4223ffe3a4fb6c2906f244ec2475d22d150eefd4` and candidate `7e33883543389e487e30aa3c7d83c2afa028df92`. The three Kotlin classes are pure geometry classes. No Android stubs, Gradle, downloaded dependencies or production edits are used.

```sh
python3 /workspace/scratch/822e72396ed9/r2-lm/.compact-check-repeat-7e338835/reproduce.py \
  --repo /workspace/scratch/822e72396ed9/r2-lm \
  --cache /workspace/scratch/822e72396ed9/build-env/gradle-cache/caches/modules-2/files-2.1
```

The runner saves actual argv arrays, cwd, exit codes, stdout/stderr hashes, Git commit/tree/blob identities and source/dependency SHA-256 values in `run/manifest.json`. `run/baseline.normal.stdout.txt` and `run/candidate.normal.stdout.txt` encode normal geometry floats as raw bits; they must be byte-identical. `run/candidate.compact.stdout.txt` lists all compact profiles and their actual before/after dimensions.

Profiles: 280×720, 412×915, 600×840, 840×649, 840×1050, 1280×800, 1536×1024 dp; each with font scales 1, 1.3, 1.5, 2. Normal output includes all shell and grid boxes, head/orb bounds and relevant layout/profile fields. Compact checks require strictly smaller avatar/content height, earlier dialogue, positive bounded shell boxes, a gap between rail and status when a rail exists, and equality when requesting normal geometry again. Bounds allow 0.01 dp rounding tolerance; the smaller/earlier and rail-separation comparisons are strict.

This check does not execute Android Views, preferences, Activity recreation, taps, renderer drawing or device/GPU rendering. Those remain covered by the parent's separate Android run.
