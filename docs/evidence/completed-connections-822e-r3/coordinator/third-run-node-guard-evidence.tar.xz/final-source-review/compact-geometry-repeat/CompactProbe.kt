import at.heinz.deviceai.ui.JarvisShellLayout
import at.heinz.deviceai.ui.JarvisShellLayout.Slot

fun main() {
    val windows = listOf(280f to 720f, 412f to 915f, 600f to 840f, 840f to 649f,
        840f to 1050f, 1280f to 800f, 1536f to 1024f)
    var profiles = 0
    for ((w, h) in windows) for (font in listOf(1f, 1.3f, 1.5f, 2f)) {
        val id = "$w x $h font=$font"
        val normal = JarvisShellLayout.forContent(w, h, font)
        val compact = JarvisShellLayout.forContent(w, h, font, compactPresentation = true)
        val normalAvatar = normal.boxes.getValue(Slot.AVATAR)
        val compactAvatar = compact.boxes.getValue(Slot.AVATAR)
        val normalDialog = normal.boxes.getValue(Slot.DIALOG)
        val compactDialog = compact.boxes.getValue(Slot.DIALOG)
        check(compactAvatar.height < normalAvatar.height) { "$id avatar did not shrink" }
        check(compactDialog.top < normalDialog.top) { "$id conversation did not rise" }
        check(compact.height < normal.height) { "$id content did not shrink" }
        for ((slot, b) in compact.boxes) {
            check(b.width > 0f && b.height > 0f) { "$id $slot nonpositive: $b" }
            check(b.left >= -.01f && b.top >= -.01f && b.right <= compact.width + .01f &&
                b.bottom <= compact.height + .01f) { "$id $slot outside content: $b" }
        }
        val rail = compact[Slot.NAV_RAIL]
        if (rail != null) check(rail.bottom < compact.boxes.getValue(Slot.STATUS).top) {
            "$id rail overlaps status"
        }
        check(JarvisShellLayout.forContent(w, h, font) == normal) { "$id normal did not restore" }
        println("PASS: $id avatar=${normalAvatar.height}->${compactAvatar.height} " +
            "conversation=${normalDialog.top}->${compactDialog.top} content=${normal.height}->${compact.height}")
        profiles++
    }
    check(profiles == 28)
    println("PASS: 28 compact geometry profiles; smaller avatar/content, earlier conversation, bounded boxes, separated rail/status, exact normal restore")
}
