#!/usr/bin/env python3
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

BASE = "4223ffe3a4fb6c2906f244ec2475d22d150eefd4"
CANDIDATE = "7e33883543389e487e30aa3c7d83c2afa028df92"
PREFIX = "app/src/main/java/at/heinz/deviceai/ui/"
SOURCES = ["JarvisShellLayout.kt", "JarvisWindowProfile.kt", "JarvisCockpitGrid.kt"]
DEPENDENCIES = [
    "org.jetbrains.kotlin/kotlin-compiler-embeddable/2.4.0",
    "org.jetbrains.kotlin/kotlin-stdlib/2.4.0",
    "org.jetbrains.kotlin/kotlin-script-runtime/2.4.0",
    "org.jetbrains.kotlin/kotlin-reflect/2.4.0",
    "org.jetbrains.kotlinx/kotlinx-coroutines-core-jvm/1.8.0",
    "org.jetbrains/annotations/13.0",
]

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--cache", type=Path, required=True)
parser.add_argument("--output", type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
out = (args.output or here / "run").resolve()
out.mkdir(parents=True, exist_ok=True)
repo = args.repo.resolve()
java = shutil.which("java")
assert java
manifest = {
    "kind": "source-pinned-repeat-after-original-temporary-harness-removal",
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "baseline": BASE,
    "candidate": CANDIDATE,
    "repo": str(repo),
    "scope": "Pure JVM geometry; no Gradle or Android UI execution",
    "original_result_reference": "Tool output chunk 24b025; transcript copied separately",
    "sources": [],
    "dependencies": [],
    "invocations": [],
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*argv):
    return subprocess.check_output(["git", "-C", str(repo), *argv])

def run(name, argv):
    start = time.monotonic()
    result = subprocess.run(argv, cwd=out, capture_output=True)
    (out / (name + ".stdout.txt")).write_bytes(result.stdout)
    (out / (name + ".stderr.txt")).write_bytes(result.stderr)
    manifest["invocations"].append({"name": name, "argv": argv, "cwd": str(out),
        "exit_code": result.returncode, "duration_seconds": time.monotonic() - start,
        "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)})
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    if result.returncode:
        raise RuntimeError(f"{name}: exit {result.returncode}; see saved stderr")
    return result.stdout

jars = []
for dependency in DEPENDENCIES:
    matches = list((args.cache / dependency).rglob("*.jar"))
    assert len(matches) == 1, (dependency, matches)
    jar = matches[0].resolve()
    jars.append(str(jar))
    manifest["dependencies"].append({"coordinate": dependency, "path": str(jar),
        "bytes": jar.stat().st_size, "sha256": sha(jar.read_bytes())})

compiler_cp = ":".join(jars)
runtime_cp = ":".join([jars[1], jars[5]])
run("java-version", [java, "-version"])
for label, commit in [("baseline", BASE), ("candidate", CANDIDATE)]:
    folder = out / label
    folder.mkdir(exist_ok=True)
    assert git("rev-parse", commit).decode().strip() == commit
    manifest[label + "_tree"] = git("rev-parse", commit + "^{tree}").decode().strip()
    source_args = []
    for filename in SOURCES:
        path = PREFIX + filename
        data = git("show", commit + ":" + path)
        target = folder / filename
        target.write_bytes(data)
        source_args.append(str(target))
        manifest["sources"].append({"label": label, "commit": commit, "path": path,
            "git_blob": git("rev-parse", commit + ":" + path).decode().strip(),
            "bytes": len(data), "sha256": sha(data)})
    probes = ["NormalProbe.kt"] + (["CompactProbe.kt"] if label == "candidate" else [])
    for filename in probes:
        data = (here / filename).read_bytes()
        target = folder / filename
        target.write_bytes(data)
        source_args.append(str(target))
    target_jar = out / (label + ".jar")
    run(label + ".compile", [java, "-Xmx256m", "-cp", compiler_cp,
        "org.jetbrains.kotlin.cli.jvm.K2JVMCompiler", "-no-stdlib", "-no-reflect",
        "-jvm-target", "17", "-classpath", runtime_cp, "-d", str(target_jar), *source_args])
    print(label + " compile exit 0", flush=True)
    run(label + ".normal", [java, "-cp", str(target_jar) + ":" + runtime_cp, "NormalProbeKt"])

baseline = (out / "baseline.normal.stdout.txt").read_bytes()
candidate = (out / "candidate.normal.stdout.txt").read_bytes()
assert len(baseline.splitlines()) == 28
assert baseline == candidate, "Normal geometry output differs"
normal_result = "PASS: 28 normal geometry profiles bit-identical to 4223ffe"
print(normal_result, flush=True)
compact = run("candidate.compact", [java, "-cp", str(out / "candidate.jar") + ":" + runtime_cp,
    "CompactProbeKt"])
print(compact.decode(), end="", flush=True)
manifest["result"] = {
    "normal_profiles": 28,
    "normal_outputs_identical": True,
    "normal_output_sha256": sha(baseline),
    "compact_profiles": 28,
    "compact_exit_code": 0,
    "result": "PASS",
}
manifest["probes"] = [{"path": name, "sha256": sha((here / name).read_bytes())}
    for name in ["NormalProbe.kt", "CompactProbe.kt", "reproduce.py"]]
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(out / "summary.txt").write_text(normal_result + "\n" + compact.decode())
