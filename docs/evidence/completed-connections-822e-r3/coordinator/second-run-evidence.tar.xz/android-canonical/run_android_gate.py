"""Source-bound Android checks."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/822e72396ed9')
REPO = ROOT / 'continuum-attach-r2'


def write(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def capture() -> dict:
    def git(*args: str) -> str:
        return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()
    dirty = git('status', '--porcelain')
    if dirty:
        raise RuntimeError('SOURCE_NOT_CLEAN')
    names = git('ls-files', 'app', '.github', 'scripts', 'tools', 'backend',
                'gradle', 'build.gradle.kts', 'settings.gradle.kts', 'gradle.properties').splitlines()
    hashes = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest()
              for name in names if (REPO / name).is_file()}
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'branch': git('branch', '--show-current'), 'sourceSha256': hashes}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--ui', action='store_true')
    parser.add_argument('--no-lint', action='store_true')
    parser.add_argument('--canonical-qa', action='store_true')
    parser.add_argument('--class-name', action='append', default=[])
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    before = capture()
    write(out / 'source-before.json', before)
    started = time.time()
    free_before = shutil.disk_usage(ROOT).free
    if free_before < 1024 ** 3:
        write(out / 'result.json', {'status': 'NOT_RUN', 'reason': 'LESS_THAN_1_GIB_FREE',
                                   'freeBytes': free_before, 'source': before['commit']})
        return 75
    log_name = 'r3-' + out.name + '.txt'
    command = ['python3', str(ROOT / 'verification-r2/with_c1_build_locks.py'),
               'timeout', '--kill-after=20s', '600s', 'python3',
               str(ROOT / 'build-env/run_gradle.py'), '--offline', '--no-build-cache',
               '-Dorg.gradle.jvmargs=-Xmx1g -XX:ActiveProcessorCount=2 -XX:+UseSerialGC',
               '--init-script', str(ROOT / 'verification-r3/observe-tests.init.gradle')]
    if args.ui:
        command.append('-PcontinuumUiWidgetTests=true')
    if args.canonical_qa:
        command += ['-PdeviceAiMentorPreview=true', '-PcontinuumLocalStandaloneQa=true',
                    '-PcontinuumStandaloneVersionCode=41']
    command.append(':app:testDebugUnitTest')
    for name in args.class_name:
        command += ['--tests', name]
    if not args.no_lint:
        command.append(':app:lintDebug')
    env = dict(os.environ, CONTINUUM_BUILD_ROOT=str(REPO), CONTINUUM_BUILD_LOG=log_name,
               CONTINUUM_R2_EVIDENCE_DIR=str(out),
               CONTINUUM_R3_TEST_PROGRESS=str(out / 'test-progress.json'))
    write(out / 'invocation.json', {'command': command, 'startedAtEpoch': started,
                                    'uiEnabled': args.ui, 'classFilters': args.class_name})
    shutil.copyfile(__file__, out / 'run_android_gate.py')
    shutil.copyfile(ROOT / 'verification-r3/observe-tests.init.gradle', out / 'observe-tests.init.gradle')
    with (out / 'wrapper.log').open('w') as log:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
    after = capture()
    write(out / 'source-after.json', after)
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    suites = []
    stale = []
    (out / 'xml').mkdir()
    for xml in sorted((REPO / 'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml')):
        if xml.stat().st_mtime < started:
            stale.append(xml.name)
            continue
        tree = ET.parse(xml).getroot()
        count = {key: int(tree.attrib.get(key, 0)) for key in totals}
        for key, value in count.items():
            totals[key] += value
        suites.append({'name': tree.attrib['name'], **count})
        shutil.copyfile(xml, out / 'xml' / xml.name)
    totals['passed'] = totals['tests'] - totals['failures'] - totals['errors'] - totals['skipped']
    lint = REPO / 'app/build/reports/lint-results-debug.xml'
    issues = None
    if lint.is_file() and lint.stat().st_mtime >= started:
        issues = len(ET.parse(lint).getroot().findall('issue'))
        shutil.copyfile(lint, out / lint.name)
    gradle_log = ROOT / 'build-env/logs' / log_name
    if gradle_log.is_file():
        shutil.copyfile(gradle_log, out / 'gradle.txt')
    passed = (result.returncode == 0 and before == after and bool(suites)
              and totals['failures'] == 0 and totals['errors'] == 0
              and (args.no_lint or issues == 0))
    receipt = {'status': 'PASS' if passed else 'FAIL_OR_INCOMPLETE',
               'exitCode': result.returncode, 'elapsedSeconds': time.time() - started,
               'sourceCommit': before['commit'], 'sourceTree': before['tree'],
               'sourceUnchanged': before == after, 'totals': totals, 'suites': suites,
               'staleXmlRejected': stale, 'lintIssues': issues, 'lintRules': ['NewApi'],
               'lintRequested': not args.no_lint,
               'uiEnabled': args.ui, 'classFilters': args.class_name,
               'canonicalQaMode': args.canonical_qa,
               'explicitQaVersionCode': 41 if args.canonical_qa else None,
               'freeBytesBefore': free_before, 'freeBytesAfter': shutil.disk_usage(ROOT).free,
               'apkBuilt': False, 'deviceTested': False, 'modelInference': False}
    write(out / 'result.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key != 'suites'}), flush=True)
    return 0 if passed else (result.returncode or 1)


if __name__ == '__main__':
    raise SystemExit(main())
