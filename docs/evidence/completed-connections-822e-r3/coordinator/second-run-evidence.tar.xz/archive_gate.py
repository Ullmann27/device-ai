"""Archive source-bound gate evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('--android', type=Path, required=True)
parser.add_argument('--node', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--remote', required=True)
args = parser.parse_args()
android = json.loads((args.android / 'result.json').read_text())
node = json.loads((args.node / 'result.json').read_text())
assert android['sourceCommit'] == node['sourceCommit']
assert android['sourceUnchanged']
assert len(node['profiles']) == 2
assert all(p['sourceUnchanged'] for p in node['profiles'])
args.out.mkdir(parents=True, exist_ok=True)
archive = args.out / f'{args.label}-evidence.tar.xz'
assert not archive.exists()
files = {}
for directory in [args.android, args.node]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            files[f'{directory.name}/{path.relative_to(directory)}'] = path
files['archive_gate.py'] = Path(__file__)
manifest = {}
with tarfile.open(archive, 'w:xz') as target:
    for name, path in files.items():
        data = path.read_bytes()
        manifest[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        target.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:xz') as target:
    assert len(target.getmembers()) == len(manifest)
    for member in target:
        data = target.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
failures = []
skips = []
suites = {}
for path in sorted((args.android / 'xml').glob('TEST-*.xml')):
    suite = ET.parse(path).getroot()
    name = suite.get('name')
    suites[name] = {key: int(suite.get(key, '0')) for key in ['tests', 'failures', 'errors', 'skipped']}
    for case in suite.findall('testcase'):
        for failure in case.findall('failure') + case.findall('error'):
            failures.append({'class': name, 'test': case.get('name'), 'message': failure.get('message')})
        if case.find('skipped') is not None:
            skips.append({'class': name, 'test': case.get('name')})
required = [
    'ToolExecutionStartLatchTest', 'ReadOnlyToolSizeRegressionTest',
    'cognitive.LocalPromptFrameTest', 'ToolDurableOutcomeTest',
    'localmodel.LocalToolContinuationTest', 'cognitive.ModelNeutralBrainIntegrationTest',
    'cognitive.ReadOnlyMultiStepTest', 'learning.interactive.ResearchFeedbackMultiprocessTest',
    'cognitive.UnknownOutcomeSafetyTest', 'localmodel.LocalInferenceDeliveryTest',
    'cognitive.JournalAvailabilityTest',
]
minimums = {'ShizukuBridgeLifecycleTest': 14, 'ShizukuConnectionDialogTest': 2,
            'ui.ContinuumControlsTest': 7, 'cognitive.OwnerChatIntentRouterTest': 5,
            'cognitive.HybridMemoryRetrieverTest': 6}
requirements = {}
for name, minimum in {**{name: 1 for name in required}, **minimums}.items():
    full_name = 'at.heinz.deviceai.' + name
    actual = suites.get(full_name)
    passed = actual is not None and actual['tests'] >= minimum and not any(actual[k] for k in ['failures', 'errors', 'skipped'])
    requirements[full_name] = {'minimum': minimum, 'actual': actual, 'passed': passed}
node_reports = {}
for profile in ['critical', 'full-node']:
    report = json.loads((args.node / profile / 'report.json').read_text())
    checks = []
    for check in report['checks']:
        tests = check.get('tests', {})
        if 'total' in tests:
            checks.append({'name': check.get('name', check.get('id')), 'status': check['status'],
                           'tests': {k: v for k, v in tests.items() if isinstance(v, (int, bool, str))}})
    node_reports[profile] = {'status': report['status'], 'sourceUnchanged': report['sourceUnchanged'], 'checks': checks}
summary = {
    'schemaVersion': 1,
    'status': 'ANDROID_PASSED_NODE_PASSED' if android['status'] == 'PASS' and all(p['status'] == 'PASS' for p in node['profiles']) else 'GATE_FAILURE_RETAINED',
    'sourceLocal': android['sourceCommit'], 'sourceRemote': args.remote, 'fullTree': android['sourceTree'],
    'android': {k: v for k, v in android.items() if k != 'suites'},
    'suiteCount': len(suites), 'failures': failures, 'skips': skips,
    'mandatorySuites': requirements, 'allMandatorySuitesPassed': all(v['passed'] for v in requirements.values()),
    'androidInvocation': json.loads((args.android / 'invocation.json').read_text()),
    'node': node_reports, 'nodeInvocation': node,
    'countsOverlap': True,
    'archive': {'name': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size, 'files': len(files)},
    'release': {'apkBuilt': False, 'deviceTested': False, 'modelInference': False},
}
(args.out / f'{args.label}-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(args.out / f'{args.label}-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'archive': summary['archive'], 'mandatoryPassed': summary['allMandatorySuitesPassed'], 'totals': android['totals']}))
