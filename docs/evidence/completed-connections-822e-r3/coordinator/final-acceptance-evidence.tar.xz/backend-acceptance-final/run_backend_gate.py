"""Run source-bound backend tests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
repo = Path('/workspace/scratch/822e72396ed9/continuum-attach-r2')
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=False)

def capture():
    def git(*command):
        return subprocess.check_output(['git', *command], cwd=repo, text=True).strip()
    assert not git('status', '--porcelain'), 'SOURCE_NOT_CLEAN'
    files = git('ls-files', 'backend').splitlines()
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'sha256': {name: hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files}}

before = capture()
(out/'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
tests = sorted(str(path.relative_to(repo/'backend')) for path in (repo/'backend/test').glob('*.test.js'))
assert tests
command = ['timeout', '--kill-after=10s', '120s', 'node', '--test', '--test-reporter=junit', *tests]
versions = {name: json.loads((repo/'backend/node_modules'/name/'package.json').read_text())['version']
            for name in ['express', 'express-rate-limit', 'helmet']}
invocation = {'command': command, 'cwd': str(repo/'backend'), 'testFiles': len(tests),
              'nodeVersion': subprocess.check_output(['node', '--version'], text=True).strip(),
              'dependencyVersions': versions,
              'lockfileSha256': hashlib.sha256((repo/'backend/package-lock.json').read_bytes()).hexdigest()}
(out/'invocation.json').write_text(json.dumps(invocation, indent=2)+'\n')
shutil.copyfile(__file__, out/'run_backend_gate.py')
env = dict(os.environ)
for key in list(env):
    if any(part in key.upper() for part in ['API_KEY', 'SIGNING_PASSWORD', 'SIGNING_FILE']):
        env.pop(key)
started = time.time()
with (out/'junit.xml').open('w') as stdout, (out/'stderr.txt').open('w') as stderr:
    completed = subprocess.run(command, cwd=repo/'backend', env=env, stdout=stdout, stderr=stderr)
after = capture()
(out/'source-after.json').write_text(json.dumps(after, indent=2)+'\n')
cases = ET.parse(out/'junit.xml').getroot().findall('.//testcase')
totals = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases),
          'skipped': sum(c.find('skipped') is not None for c in cases)}
totals['passed'] = totals['tests']-totals['failures']-totals['errors']-totals['skipped']
passed = completed.returncode == 0 and before == after and bool(cases) and not totals['failures'] and not totals['errors']
receipt = {'status': 'PASS' if passed else 'FAIL_OR_INCOMPLETE', 'exitCode': completed.returncode,
           'sourceCommit': before['commit'], 'sourceTree': before['tree'], 'sourceUnchanged': before == after,
           'elapsedSeconds': time.time()-started, 'totals': totals,
           'liveApiInference': False, 'serverDeployed': False}
(out/'result.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if passed else (completed.returncode or 1))
