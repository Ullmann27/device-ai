"""Run canonical Node gate profiles."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import shutil

root = Path('/workspace/scratch/822e72396ed9')
repo = root / 'continuum-attach-r2'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, default=root / 'verification-r3/node-gates')
out = parser.parse_args().out
out.mkdir(exist_ok=False)
shutil.copyfile(__file__, out / 'run_node_gates.py')
compiler = Path('/workspace/scratch/18845e31bc4a/regression-audit/real-kotlinc/bin/kotlinc')
env = dict(os.environ)
env['PATH'] = str(compiler.parent) + os.pathsep + str(root / 'build-env/jdk17/bin') + os.pathsep + env.get('PATH', '')
env['JAVA_HOME'] = str(root / 'build-env/jdk17')
env['TMPDIR'] = tempfile.mkdtemp(prefix='continuum-r3-node-', dir='/tmp')
version = subprocess.run([str(compiler), '-version'], env=env, capture_output=True, text=True)
(out / 'kotlin-version.txt').write_text(version.stdout + version.stderr)
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
manifest = {'sourceCommit': source, 'compilerLauncher': str(compiler),
            'compilerLauncherSha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
            'compilerVersionExitCode': version.returncode, 'temporaryRoot': env['TMPDIR'], 'profiles': []}
for profile in ['critical', 'full-node']:
    command = ['timeout', '--kill-after=20s', '900s', 'node',
               'scripts/continuum-reliability-qa.mjs', profile, '--out', str(out / profile)]
    started = time.time()
    with (out / (profile + '-runner.txt')).open('w') as log:
        result = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    report_path = out / profile / 'report.json'
    report = json.loads(report_path.read_text()) if report_path.is_file() else None
    entry = {'profile': profile, 'command': command, 'exitCode': result.returncode,
             'elapsedSeconds': time.time() - started,
             'status': report.get('status') if report else 'INCOMPLETE',
             'sourceUnchanged': report.get('sourceUnchanged') if report else None}
    manifest['profiles'].append(entry)
    (out / 'result.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
raise SystemExit(0 if all(p['exitCode'] == 0 and p['status'] == 'PASS' for p in manifest['profiles']) else 1)
