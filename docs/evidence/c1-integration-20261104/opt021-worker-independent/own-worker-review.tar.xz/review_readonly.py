#!/usr/bin/env python3
"""Read existing worker receipts and immutable Git objects; no tests/builds."""
from pathlib import Path
import collections, hashlib, json, re, subprocess
ROOT=Path('/workspace/scratch/174c84456ee3');REPO=ROOT/'continuum-c1'
OUT=ROOT/'source-audit/optimization021/own-worker-review';OUT.mkdir(parents=True,exist_ok=True)
SOURCE='6f7ca725261eb4df502ee868e94babc4e12afc15'
TREE='d197c1eb872b7b01e78e3150c6eeb0b9381810f9'
REMOTE='4d74de6c5ca04582ff455356440046e9148acbb0'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def read(path,ref=SOURCE):return git('show',ref+':'+path)
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def meta(b):return {'blob':blob(b),'sha256':sha(b),'bytes':len(b)}
def save(name,b):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def savejson(name,obj):save(name,json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
assert git('rev-parse',SOURCE+'^{tree}').decode().strip()==TREE
parent=git('rev-parse',SOURCE+'^').decode().strip()
assert parent=='9a442485f2569b39be2bcd8d6687da6f6c15c45d'
m=json.loads((ROOT/'source-audit/optimization021/worker/manifest.json').read_text())
patch=(ROOT/'source-audit/optimization021/worker/worker.patch').read_bytes()
assert sha(patch)==m['patch_sha256']=='65abb18658fa30cd01a8e6c40fe1547c3aaa175198387a4881e0d50e173e045d'
changed=git('diff','--name-only',parent,SOURCE).decode().splitlines()
non_docs=[p for p in changed if not p.startswith('docs/')]
assert set(non_docs)=={p['path'] for p in m['paths']}
scope=[]
for entry in m['paths']:
 p=entry['path'];target=read(p)
 assert meta(target)=={k:entry['target'][k] for k in ('blob','sha256','bytes')}
 mode=git('ls-tree',SOURCE,'--',p).decode().split()[0]
 assert mode==entry['target']['mode']=='100644'
 if entry['base'] is not None:
  base=read(p,parent)
  assert meta(base)=={k:entry['base'][k] for k in ('blob','sha256','bytes')}
 else:
  assert git('ls-tree',parent,'--',p)==b''
 scope.append({'path':p,'mode':mode,'target':meta(target),'matches_frozen_intake':True})
 save('source/'+p,target)
deps=[]
for d in m['dependencies']:
 b=read(d['path']);current=meta(b)
 deps.append({'path':d['path'],'intake_blob':d['blob'],'current':current,'unchanged':current['blob']==d['blob']})
delta=[d for d in deps if not d['unchanged']]
assert len(delta)==1
assert delta[0]['path']=='.github/continuum/local-teamleader-loop.mjs'
assert delta[0]['current']['blob']=='f83e6a1dcd40e7841734f893895766c6c3b1ed29'
assert read(delta[0]['path'])==read(delta[0]['path'],parent)
save('source/'+delta[0]['path'],read(delta[0]['path']))
runs={}
logs={}
for label in ('opt021-worker-node-01','opt021-worker-parity-01'):
 rb=(ROOT/'qa'/(label+'.result.json')).read_bytes()
 lb=(ROOT/'qa'/(label+'.log')).read_bytes()
 r=json.loads(rb);text=lb.decode();head=json.loads(text.splitlines()[0])
 assert r['source']==head['source']=={'commit':SOURCE,'tree':TREE,'dirty':''}
 assert r['sourceUnchanged'] is True
 assert r['exitCode']==r['processReturnCode']==0 and r['status']=='PASS'
 assert head['command']==r['command'] and head['runnerSha256']==r['runnerSha256']
 assert text.rstrip().endswith('EXIT_CODE=0')
 save('raw/'+label+'.result.json',rb);save('raw/'+label+'.log',lb)
 runs[label]={'receipt':r,'log_sha256':sha(lb),'result_sha256':sha(rb),'log_bytes':len(lb)}
 logs[label]=text
node=logs['opt021-worker-node-01']
cases=re.findall(r'^ok (\d+) - (.*)$',node,re.M)
assert [int(n) for n,_ in cases]==list(range(1,122))
assert len({name for _,name in cases})==121
assert not re.search(r'^not ok |^(?:ok|not ok).*#\s*(?:SKIP|TODO)\b',node,re.M|re.I)
summary={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',node,re.M)}
assert summary=={'tests':121,'suites':0,'pass':121,'fail':0,'cancelled':0,'skipped':0,'todo':0}
assert re.findall(r'^1\.\.(\d+)$',node,re.M)==['121']
expected_files=[s for s in m['acceptance']['node'] if s.endswith('.test.mjs')]
actual_files=[s for s in runs['opt021-worker-node-01']['receipt']['command'] if s.endswith('.test.mjs')]
assert expected_files==actual_files and len(actual_files)==10
new_names=re.findall(r"^\+test\('([^']+)'",patch.decode(),re.M)
assert len(new_names)==4 and all(n in {name for _,name in cases} for n in new_names)
pt=logs['opt021-worker-parity-01']
body='\n'.join(pt.splitlines()[1:]).lstrip()
parity,end=json.JSONDecoder().raw_decode(body)
assert parity['status']=='PARITY_PASS' and parity['parityCases']==40960
assert body[end:].strip()=='EXIT_CODE=0'
sourcepath=m['paths'][0]['path'];harnesspath=m['paths'][2]['path']
assert parity['candidateSourceSha256']==sha(read(sourcepath))
assert parity['harnessSha256']==sha(read(harnesspath))
baseline=git('show',parity['baselineSourceBlob'])
assert sha(baseline)==parity['baselineSourceSha256']==m['paths'][0]['base']['sha256']
assert parity['fixtureSizes']==[0,1,20,100,500]
assert parity['fixtureModes']==['mixed-priority','ties','scoped','scoped-no-match']
assert 5*4*2*4**5==40960
localtest=read('.github/continuum/local-teamleader-loop.test.mjs').decode()
assert "from './local-teamleader-loop.mjs'" in localtest or "from './local-teamleader-loop.mjs';" in localtest
remote_object=subprocess.run(['git','-C',str(REPO),'cat-file','-e',REMOTE+'^{tree}'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
remote={'commit':REMOTE,'evidence':'Root report only; remote object not locally available'}
if remote_object:
 rt=git('rev-parse',REMOTE+'^{tree}').decode().strip();assert rt==TREE
 remote={'commit':REMOTE,'tree':rt,'evidence':'Local immutable remote Git object independently matches tree'}
save('frozen-intake/manifest.json',(ROOT/'source-audit/optimization021/worker/manifest.json').read_bytes())
save('frozen-intake/worker.patch',patch)
save('frozen-intake/integration-summary.json',read('docs/evidence/c1-integration-20261104/opt021-worker/summary.json'))
save('source/local-teamleader-loop.test.mjs',localtest)
savejson('C1-OPT-021-own-worker-review.json',{
 'task':'C1-OPT-021-OWN-WORKER-REVIEW','verdict':'BOUNDED_RECEIPTS_AND_SCOPE_CONFIRMED',
 'source':{'commit':SOURCE,'tree':TREE,'parent':parent},'remote':remote,
 'scope':scope,'documentation_paths':[p for p in changed if p.startswith('docs/')],
 'non_documentation_paths_exactly_frozen_worker_three':True,'app_ui_compiler_manifest_workflows_owner_config_diff':'EMPTY_FOR_THIS_COMMIT',
 'dependency_comparison':deps,'only_dependency_delta':delta,
 'current_loop_imported_by_frozen_test':True,'current_loop_unchanged_by_worker_slice':True,
 'node':{'files':actual_files,'cases':121,'pass':121,'fail':0,'skip':0,'cancelled':0,'todo':0,
  'format':'NODE_TAP; no JUnit XML claimed','all_case_names':[n for _,n in cases],'four_added_regressions':new_names},
 'parity':parity,'parity_scope':'40 frozen synthetic documents times 1024 filter combinations = 40960 object-identity selector decisions; separate from 121 Node tests',
 'receipts':runs,'runtime_claims':'Existing Root runs independently read; no rerun by reviewer',
 'limitations':['Bounded worker acceptance only, not Android/Fold7 or full gate','No performance measurement or speedup claim','Missing022 26-case prior acceptance is separate and not recounted here','Remote mapping only as marked in remote.evidence'],
 'tests_by_reviewer':'NOT_RUN','builds_by_reviewer':'NOT_RUN','repository_changes':'NONE','locks':'NOT_ACQUIRED','external_C2_ACK':'NOT_CLAIMED'})
print(json.dumps({'verdict':'BOUNDED_RECEIPTS_AND_SCOPE_CONFIRMED','source':SOURCE,'tree':TREE,'paths':len(scope),'node_cases':121,'parity_decisions':40960,'only_dependency_delta':delta,'remote':remote},indent=2))

