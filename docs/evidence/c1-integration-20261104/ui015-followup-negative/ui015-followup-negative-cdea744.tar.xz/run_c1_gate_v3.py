from __future__ import annotations
import datetime, fcntl, hashlib, json, os, pathlib, signal, subprocess, sys, time

WORK = pathlib.Path('/workspace/scratch/174c84456ee3')
ROOT = WORK / 'continuum-c1'
QA = WORK / 'qa'
LOCKS = [
 pathlib.Path('/workspace/scratch/b6ee64d418cf/toolchain/gradle-build.lock'),
 pathlib.Path('/workspace/scratch/d663e8444310/qa/gradle.lock'),
]
def git(*args):
 return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
def now():
 return datetime.datetime.now(datetime.timezone.utc).isoformat()
label = sys.argv[1]
if pathlib.Path(label).name != label or not sys.argv[2:]:
 raise SystemExit('Expected a simple label and an explicit command')
args = sys.argv[2:]
result_path = QA / (label + '.result.json')
log_path = QA / (label + '.log')
if result_path.exists() or log_path.exists():
 raise SystemExit('Evidence label already exists')
source = {'commit': git('rev-parse','HEAD'), 'tree': git('rev-parse','HEAD^{tree}'), 'dirty': git('status','--porcelain')}
if source['dirty']:
 raise SystemExit('Source must be clean before a full gate')
record = {'taskId': 'C1-COMBINED-GATES-001', 'label': label, 'source': source, 'command': args,
 'runnerSha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), 'requestedAt': now(), 'locks': [str(x) for x in LOCKS], 'exitCode': None, 'status': 'WAITING_FOR_LOCKS'}
wait_seconds = int(os.environ.get('C1_LOCK_WAIT_SECONDS', '45'))
if not 45 <= wait_seconds <= 900:
 raise SystemExit('C1_LOCK_WAIT_SECONDS must be an integer from 45 to 900')
record['lockWaitSeconds'] = wait_seconds
result_path.write_text(json.dumps(record,indent=2)+'\n')
locks = []
deadline = time.monotonic() + wait_seconds
next_heartbeat = time.monotonic()
try:
 for name in LOCKS:
  if not name.is_file():
   record.update(status='BLOCKED',reason='EXISTING_SHARED_LOCK_MISSING')
   raise SystemExit(75)
  handle = name.open('a')
  locks.append(handle)
  while True:
   try:
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    break
   except BlockingIOError:
    if time.monotonic() >= next_heartbeat:
     record.update(waitingForLock=str(name), heartbeatAt=now())
     result_path.write_text(json.dumps(record,indent=2)+'\n')
     next_heartbeat = time.monotonic() + 5
    if time.monotonic() >= deadline:
     record.update(status='BLOCKED',reason='SHARED_BUILD_LOCK_BUSY')
     raise SystemExit(75)
    time.sleep(.25)
 record['freeBytesAtStart'] = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
 if record['freeBytesAtStart'] < 512*1024*1024:
  record.update(status='BLOCKED',reason='LESS_THAN_512_MIB_FREE')
  raise SystemExit(75)
 record.update(status='RUNNING',startedAt=now())
 result_path.write_text(json.dumps(record,indent=2)+'\n')
 env = dict(os.environ)
 for key in ['NODE_TEST_CONTEXT','CONTINUUM_REPAIR_DEPTH','CONTINUUM_QA_DEPTH',
             'CONTINUUM_LOCAL_SIGNING_FILE','CONTINUUM_LOCAL_SIGNING_PASSWORD','CONTINUUM_LOCAL_SIGNING_P12_BASE64',
             'CONTINUUM_MENTOR_SIGNING_FILE','CONTINUUM_MENTOR_SIGNING_PASSWORD','CONTINUUM_MENTOR_SIGNING_P12_BASE64']:
  env.pop(key,None)
 tc = pathlib.Path('/workspace/scratch/b6ee64d418cf/toolchain')
 env.update(JAVA_HOME=str(tc/'jdk17'),ANDROID_HOME=str(tc/'android-sdk'),
  ANDROID_SDK_ROOT=str(tc/'android-sdk'),ANDROID_USER_HOME=str(WORK/'android-user'),
  GRADLE_USER_HOME='/workspace/scratch/d663e8444310/gradle-cache')
 env['PATH'] = str(tc/'jdk17/bin')+os.pathsep+env.get('PATH','')
 with log_path.open('x') as log:
  log.write(json.dumps(record)+'\n');log.flush()
  proc = subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  progress = next((pathlib.Path(x.split('=',1)[1]) for x in args if x.startswith('-PcontinuumAuditProgressFile=')),None)
  if progress is not None and not progress.resolve().is_relative_to(QA.resolve()):
   progress = None
  record.update(overallTimeoutSeconds=1800, individualTestTimeoutSeconds=180 if progress else None)
  overall_deadline = time.monotonic()+1800
  abort_reason = None
  while proc.poll() is None:
   if time.monotonic() >= overall_deadline:
    abort_reason = 'OVERALL_TIMEOUT_1800_SECONDS'
   elif progress is not None and progress.is_file():
    try:
     active = json.loads(progress.read_text())
     if active.get('active') is True and isinstance(active.get('startedAtMillis'),int) and time.time()*1000-active['startedAtMillis']>180000:
      abort_reason = 'TEST_TIMEOUT_180_SECONDS:'+str(active.get('className'))+'#'+str(active.get('name'))
      record['activeTestAtTimeout'] = active
    except (OSError, ValueError):
     pass
   if abort_reason:
    record['abortReason'] = abort_reason
    try: os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError: pass
    try: proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
     try: os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError: pass
     proc.wait()
    break
   time.sleep(.25)
  record['processReturnCode'] = proc.returncode
  code = 124 if abort_reason else proc.returncode
  record.update(exitCode=code,status='PASS' if code==0 else 'FAIL',finishedAt=now())
  log.write('\nEXIT_CODE='+str(code)+'\n')
 current = {'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'dirty':git('status','--porcelain')}
 record['sourceUnchanged'] = current == source
 if not record['sourceUnchanged']:
  record.update(status='FAIL',reason='SOURCE_CHANGED_DURING_GATE',exitCode=76)
 raise SystemExit(code if record['sourceUnchanged'] else 76)
finally:
 record['recordedAt']=now()
 result_path.write_text(json.dumps(record,indent=2)+'\n')
 for handle in reversed(locks):
  fcntl.flock(handle,fcntl.LOCK_UN)
  handle.close()
 print(json.dumps(record),flush=True)
