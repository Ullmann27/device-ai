# Drei historische Boardlinks — begrenzter Korrekturvorschlag

Alle drei historischen Dateien wurden erfolgreich am ausdrücklich beauftragten #498-Pin `e95076c2a396a785ae80bceca0610890ff1af5d9` gelesen. Die vom Connector gelieferten Git-Blobs wurden aus den unveränderten UTF-8-Bytes nachgerechnet. Alle drei Zielpfade fehlen im gepinnten C1-Baum4da039d und in der beim Lesen vorhandenen Arbeitskopie. Das ist ein realer Dokumentationsfehler; kein Test-/Produktionsfehler wird dadurch umetikettiert.

Board: `/workspace/scratch/174c84456ee3/continuum-c1/docs/research/omega/ASTRA-NUCLEUS-HANDOFF-20261104.md`. Beim Vorschlag SHA-256 `4bc51e2b087c4adc5fede7ef56cb3267f2dde9f43f3ed2b56597b55d10a769b4`. Der Board-Arbeitsstand wurde zwischenzeitlich von C1 fortgeschrieben und unterscheidet sich vom4da-Pin (dessen SHA-256 `884946f3cd83f9489ca2c6dc7fbb4f1c3170a8ca185148055d4c8059bff01c06`). Deshalb werden beide Zeilenbezüge genannt; der Vorschlag verändert ausschließlich die drei Linkziele.

| Zeile im gelesenen Arbeitsstand | Bisheriges relatives Ziel | Validierte unveränderliche URL | Historischer Git-Blob |
| --- | --- | --- | --- |
| 79 (Pin4da: 76) | `astra-nucleus/GENERATION-1.json` | [GENERATION-1.json](https://github.com/Ullmann27/device-ai/blob/e95076c2a396a785ae80bceca0610890ff1af5d9/docs/research/omega/astra-nucleus/GENERATION-1.json) | `1335bbafbda06b0ddfe7758c8331cbb854fa95b0` |
| 81 (Pin4da: 78) | `ASTRA-NUCLEUS-ACTION-PACKAGE-20261104.md` | [Chat-Aufträge](https://github.com/Ullmann27/device-ai/blob/e95076c2a396a785ae80bceca0610890ff1af5d9/docs/research/omega/ASTRA-NUCLEUS-ACTION-PACKAGE-20261104.md) | `caa523104c1bccd9e5b61eeae486a40352edf1e2` |
| 131 (Pin4da: 128) | `../../evidence/astra-nucleus-20261104/parameter-layout-counts.json` | [Tensorliste und Rechnung](https://github.com/Ullmann27/device-ai/blob/e95076c2a396a785ae80bceca0610890ff1af5d9/docs/evidence/astra-nucleus-20261104/parameter-layout-counts.json) | `b5461ad94301145710644a5a542539f33bc1836b` |

Der historische Inhalt wird **nicht** in den aktuellen Kandidaten kopiert und nicht als aktuelle Produktabnahme ausgegeben. Die Umstellung auf die exakten historischen URLs erhält den Belegzweck, ohne fehlende lokale Dateien oder einen beweglichen Branchlink vorzutäuschen.

`board-links-proposed.patch` enthält genau drei Linkersetzungen und wurde weder angewandt noch per Apply-Check getestet. Patch SHA-256: `55bfa8242ff18dc09b3ed30f0041de038333af64f352725dd140be172816bb1a`. Das JSON enthält zusätzlich SHA-256, Bytezahlen, Abrufzeitpunkte und Quellbindung jedes Originals. Die drei Originaldateien sind unverändert unter `original/` beigelegt. Keine Repoänderung, keine Tests, keine Kommentare oder Veröffentlichung durch diesen Helfer.
