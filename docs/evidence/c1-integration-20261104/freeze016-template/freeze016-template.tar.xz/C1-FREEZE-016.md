# C1-FREEZE-016 — Quellenmanifest- und Gate-Vorlage

**TEMPLATE ONLY — aktiver Intake; kein finaler Freeze, kein Gesamt-PASS.** Am 04.11.2026 wurden lokal `4da039d55d44f7087a9e4cd7bd72dc5a0089029e`, Tree `974e949a022a7774c6c5c702631217fffb8f8018` und ein sauberer Arbeitsbaum gelesen. C1 prüft weitere begrenzte Beiträge aus #522 und #524. Vor den abschließenden Gates sind Kandidat und alle Pins nach deren Annahme oder bewusster Zurückstellung erneut festzulegen. Diese Vorlage startet nichts und integriert keinen weiteren Branch.

## 1. Quellzuordnung und Herkunft

Lokaler Prüfkontext: `integration/continuum-c1-candidate-20261104`, `/workspace/scratch/174c84456ee3/continuum-c1`. Von C1 gemeldete veröffentlichte Entsprechung: `20d9dd8779c63452815a701b8f5956e426abf4aa`, identischer Gesamtbaum `974e949a022a7774c6c5c702631217fffb8f8018`. Dieses Remote-Objekt ist lokal nicht vorhanden; die Remote-Zuordnung wurde in diesem netzfreien Auftrag nicht erneut unabhängig geprüft. Das JSON trennt diesen gemeldeten Bezug von der direkt gelesenen lokalen Identität.

App-Tree: `2d7d31944f852d8c238f9a996cb42d2725d20dd0`; Scripts: `ca3460d5dab6c632ceeb84742cd04f80190a07f4`; Tools: `2932a76d4012444e329e1ae1399d05e963567612`. Alle Root-Objekte, gelesenen Vertrags-/Harness-Dateien mit Git-Blob/Modus/SHA-256, konkrete Node-Dateiauswahl und die vorhandenen echten Kotlin-CLI-Abhängigkeiten stehen im JSON. Laufzeiten, Exitcodes und Ergebnisse bleiben darin ausdrücklich leer/NOT_RUN.

Geltende Grundlagen: `AGENTS.md`, Projektvertrag, aktueller C1-Handoff, `scripts/render-continuum-owner-continuous-qa.sh`, bestehender Evidence-/JUnit-Validator und lokale v2-Harnessdateien. Der Render-Launcher besitzt zusätzliche Service-/Branchbindungen und Vorbereitung/Downloads; er wird lokal nicht durch erfundene Render-Umgebungswerte umgangen. Die unten genannten lokalen Commands führen seinen tatsächlichen Gateumfang mit vorhandener Toolchain aus.

## 2. Ressourcen, Werkzeug und Startbedingungen

Der v2-Wrapper nimmt seriell `/workspace/scratch/b6ee64d418cf/toolchain/gradle-build.lock` und `/workspace/scratch/d663e8444310/qa/gradle.lock`; wartet höchstens45Sekunden und lehnt fehlende Locks bzw. weniger als512MiB frei ab. Während dieser Lektüre waren758.366.208Bytes frei (rund723MiB). Das überschreitet nur den technischen Mindestwert; **ausreichender Platz für einen vollen `--rerun-tasks`-Lauf ist nicht belegt**. Keine zusätzliche Cachekopie oder Toolchaininstallation gehört zu dieser Vorlage. Belegung wurde hier nicht durch Locknahme getestet.

Vorhandener gemeinsamer Cache: `/workspace/scratch/d663e8444310/gradle-cache`; JDK17/Gradle8.11.1/SDK unter `/workspace/scratch/b6ee64d418cf/toolchain`. Die reale Kotlin-CLI ist `/workspace/scratch/18845e31bc4a/regression-audit/real-kotlinc/bin/kotlinc`: Der gelesene Launcher ruft den vorhandenen offiziellen Kotlin-Kompiler mit Java auf; er ersetzt keine Compilerantwort. Acht bestehende JARs und der Launcher sind gehasht. Version/Startfähigkeit wird erst beim wirklichen Gate bestätigt.

Die v2-Hülle entfernt sechs Signingvariablen und geerbten Node-/Repair-/QA-Kontext. Sie protokolliert unveränderte Quelle, Kommando, Wrapperhash, Exitcode und tatsächlichen Prozesscode. Gesamtgrenze1800Sekunden; Android-Testgrenze180Sekunden über `observe-tests.init.gradle`. Überschreitung bleibt FAIL/124, niemals Skip/PASS. Der Init-Hook selbst, Kotlinlauncher/-JARs und Dependency-Receipt müssen mit ihren Hashes in den späteren Beleg eingehen, weil sie außerhalb des Git-Baums liegen.

## 3. Konkrete lokale Gate-Reihenfolge

Die Befehle sind eine ausführbare **Vorlage für den später von C1 festgelegten Kandidaten**. Die aktuell eingesetzten Pins dürfen nach weiterem Intake nicht blind beibehalten werden. Frische Laufkennung; Ausgabe ausschließlich außerhalb des Checkouts. Kein Klassenfilter, kein Signing, kein Installationsbefehl.

```bash
set -euo pipefail
c1_root=/workspace/scratch/174c84456ee3/continuum-c1
c1_qa=/workspace/scratch/174c84456ee3/qa
c1_wrapper="$c1_qa/run_c1_gate_v2.py"
c1_gradle=/workspace/scratch/b6ee64d418cf/toolchain/gradle-8.11.1/bin/gradle
c1_kotlin_bin=/workspace/scratch/18845e31bc4a/regression-audit/real-kotlinc/bin
# Diese zwei Pins NACH Abschluss des aktiven Intake bewusst neu festlegen.
c1_source=4da039d55d44f7087a9e4cd7bd72dc5a0089029e
c1_tree=974e949a022a7774c6c5c702631217fffb8f8018
c1_run="c1-final-$(date -u +%Y%m%dT%H%M%SZ)"
export PATH="$c1_kotlin_bin:$PATH"
cd "$c1_root"
c1_gate() {
  test "$(git rev-parse HEAD)" = "$c1_source"
  test "$(git rev-parse 'HEAD^{tree}')" = "$c1_tree"
  test -z "$(git status --porcelain)"
  python3 "$c1_wrapper" "$c1_run-$1" "${@:2}"
}
```

### Node und Backend

```bash
c1_gate kotlin-cli "$c1_kotlin_bin/kotlinc" -version
c1_gate node-special node --test scripts/continuum-atomic-acceptance.test.mjs scripts/continuum-gguf-preflight.test.mjs scripts/continuum-gguf-preflight.integration.test.mjs scripts/continuum-owner-v38-release.test.mjs scripts/continuum-owner-continuous-release.test.mjs
node -p 'Date.now()' > "$c1_qa/$c1_run-critical.start-ms"
c1_gate critical node scripts/continuum-reliability-qa.mjs critical --out "$c1_qa/$c1_run-critical-output"
node scripts/continuum-qa-evidence.mjs node "$c1_qa/$c1_run-critical-output/report.json" "$c1_source" critical "$(cat "$c1_qa/$c1_run-critical.start-ms")" > "$c1_qa/$c1_run-critical-proof.json"
node -p 'Date.now()' > "$c1_qa/$c1_run-full-node.start-ms"
c1_gate full-node node scripts/continuum-reliability-qa.mjs full-node --out "$c1_qa/$c1_run-full-node-output"
node scripts/continuum-qa-evidence.mjs node "$c1_qa/$c1_run-full-node-output/report.json" "$c1_source" full-node "$(cat "$c1_qa/$c1_run-full-node.start-ms")" > "$c1_qa/$c1_run-full-node-proof.json"
c1_gate backend-check npm --prefix backend run check
c1_gate backend-test npm --prefix backend test
```

`critical` umfasst process, storage-agent, android-source-contracts und host-checker. `full-node` erfasst die direkten `.test.mjs` in `.github/continuum` (228) und `scripts` (96); keine rekursive `tools/`-Abnahme. Die drei echten Kotlin-Delegations-/Besitzer-Preview-Testdateien dürfen nicht wegen fehlendem `kotlinc` ausfallen oder übersprungen werden. Ihre realen Compilerfälle werden in den frischen Falllisten geprüft; die bewusst simulierten Compilerfehler des Hostclassifier-Unit-Tests sind ein anderer, transparenter Testsachverhalt.

Backend `check` und `test` sind die zusätzliche im C1-Handoff genannte Backend-Abnahme; das zentrale Render-Skript selbst ruft sie nicht auf. `npm --prefix backend test` verwendet den vorhandenen Package-Script `node --test test/*.test.js`. Der vorhandene Dependency-Receipt belegt die frühere bytegleiche Übernahme; diese Lektüre installierte und testete nichts.

Die zusätzlichen `tools/*`-Isolationssuiten bleiben separate Entwicklungswerkzeug-Abnahme. Die bekannten38Fehler werden weder gelöscht noch als zentrale App-PASS ausgegeben. Tatsächliche Isolationsfähigkeiten benötigen weiterhin ihre echten Belege. Node-Suitezahlen überlappen; nicht addieren.

### Vollständiges Android-Gate

```bash
node -p 'Date.now()' > "$c1_qa/$c1_run-full-android.start-ms"
c1_gate full-android "$c1_gradle" --offline --no-daemon --rerun-tasks --max-workers=2 --console=plain \
  '-Dorg.gradle.jvmargs=-Xmx1600m -XX:MaxMetaspaceSize=512m' \
  -Pkotlin.compiler.execution.strategy=in-process \
  -PdeviceAiMentorPreview=true -PcontinuumUiWidgetTests=true \
  -PcontinuumLocalStandaloneQa=true -PcontinuumStandaloneVersionCode=41 \
  -PcontinuumAuditTestClasses= \
  "-PcontinuumAuditProgressFile=$c1_qa/$c1_run-android-active-test.json" \
  -I "$c1_qa/observe-tests.init.gradle" \
  :app:compileDebugKotlin :app:testDebugUnitTest :app:lintDebug
node scripts/continuum-qa-evidence.mjs android "$c1_root" \
  "$(cat "$c1_qa/$c1_run-full-android.start-ms")" \
  > "$c1_qa/$c1_run-android-junit-proof.json"
```

`-PcontinuumAuditTestClasses=` setzt die vom Init-Skript gelesene Auswahl ausdrücklich leer; weder `--tests` noch ein Klassen-/Methodenfilter. `--rerun-tasks` ist vorhanden. `continuumUiWidgetTests=true` aktiviert den gesamten `src/uiTest/java`-Quellensatz, echte Ressourcenintegration und die vorhandenen offline gebundenen Robolectric-Plattformen. Die Gradle-Allowlist bleibt exakt Compile/Test/Lint. Der Wert41 ist ausschließlich der bereits verwendete QA-Parameter, keine Aussage über den aktuellen Kanal und keine neue Updateversion.

## 4. Zwingende Evidence-Prüfung

Ein Exit0 allein reicht nicht. Kritische/full-node-Receipts müssen den tatsächlichen Test-HEAD, das Profil, unveränderte Quelle, komplette JUnit-Fälle, bestätigte Prozessbeendigung und passende Laufzeitgrenzen belegen. Für Android müssen sämtliche XMLs frisch, regulär, exakt zu Klasse/Fallzahl passend und fehlerfrei sein. Alte Fokus-XMLs sind kein Ersatz. Roh-XML, Lint-XML und Logs vor weiteren Testaufrufen unverändert extern sichern und hashen.

### Elf zentral verpflichtende JVM-Suiten

Jeweils mindestens ein ausgeführter Fall, null Skip/Fehler/Error:

- `at.heinz.deviceai.ToolExecutionStartLatchTest`
- `at.heinz.deviceai.ReadOnlyToolSizeRegressionTest`
- `at.heinz.deviceai.cognitive.LocalPromptFrameTest`
- `at.heinz.deviceai.ToolDurableOutcomeTest`
- `at.heinz.deviceai.localmodel.LocalToolContinuationTest`
- `at.heinz.deviceai.cognitive.ModelNeutralBrainIntegrationTest`
- `at.heinz.deviceai.cognitive.ReadOnlyMultiStepTest`
- `at.heinz.deviceai.learning.interactive.ResearchFeedbackMultiprocessTest`
- `at.heinz.deviceai.cognitive.UnknownOutcomeSafetyTest`
- `at.heinz.deviceai.localmodel.LocalInferenceDeliveryTest`
- `at.heinz.deviceai.cognitive.JournalAvailabilityTest`

### Fünf zusätzliche Mindestzahlen des zentralen Launchers

| Klasse | Mindestzahl, jeweils null Skip |
| --- | ---: |
| `at.heinz.deviceai.ShizukuBridgeLifecycleTest` | 14 |
| `at.heinz.deviceai.ShizukuConnectionDialogTest` | 2 |
| `at.heinz.deviceai.ui.ContinuumControlsTest` | 7 |
| `at.heinz.deviceai.cognitive.OwnerChatIntentRouterTest` | 5 |
| `at.heinz.deviceai.cognitive.HybridMemoryRetrieverTest` | 6 |

Unveränderter bestehender Mindestprüfblock aus dem zentralen Launcher; nach erfolgreicher allgemeiner Freshness-/JUnit-Prüfung aus dem Checkout ausführen:

```bash
python3 - <<'PY'
import glob, xml.etree.ElementTree as ET
expected={
 'at.heinz.deviceai.ShizukuBridgeLifecycleTest':14,
 'at.heinz.deviceai.ShizukuConnectionDialogTest':2,
 'at.heinz.deviceai.ui.ContinuumControlsTest':7,
 'at.heinz.deviceai.cognitive.OwnerChatIntentRouterTest':5,
 'at.heinz.deviceai.cognitive.HybridMemoryRetrieverTest':6,
}
seen={name:0 for name in expected};skips={name:0 for name in expected};failures=0
files=glob.glob('app/build/test-results/testDebugUnitTest/TEST-*.xml')
if not files: raise SystemExit('QA_RED JUnit reports missing')
for p in files:
 root=ET.parse(p).getroot()
 for case in root.iter('testcase'):
  cls=case.get('classname','')
  if case.find('failure') is not None or case.find('error') is not None: failures+=1
  if cls in seen:
   seen[cls]+=1
   if case.find('skipped') is not None: skips[cls]+=1
if failures or any(seen[name]<minimum or skips[name] for name,minimum in expected.items()):
 raise SystemExit('QA_RED mandatory owner suites '+repr({'seen':seen,'skips':skips,'failures':failures}))
print('CONTINUUM_CONTINUOUS_OWNER_REQUIRED_ANDROID_GREEN',seen)
PY
```

### C1-Abdeckungsinventar innerhalb des Voll-Laufs

Die folgende Tabelle zählt die aktuell vorhandenen `@Test`-Methoden aus Quellen, **keine Laufresultate**. Sie dient der Kontrolle, dass die tatsächlich geänderten/verbundenen Klassen im vollständigen Lauf ausgeführt werden; sie ist keine neue Filterliste und ersetzt keine andere Suite. Nach weiterem Intake neu abgleichen.

| Klasse | aktuell deklarierte Methoden |
| --- | ---: |
| `at.heinz.deviceai.chief.ChiefBotAddressRouterTest` | 18 |
| `at.heinz.deviceai.cockpit.CompiledMemoryOrbIntegrationTest` | 4 |
| `at.heinz.deviceai.cognitive.MemoryRecallObservationTest` | 6 |
| `at.heinz.deviceai.learning.ContinuumRetrievalExperimentTest` | 2 |
| `at.heinz.deviceai.learning.TemporalCueCalendarTest` | 15 |
| `at.heinz.deviceai.learning.TemporalCueDailyBoundaryTest` | 12 |
| `at.heinz.deviceai.ContinuumAvatar3dLifecycleUiTest` | 4 |
| `at.heinz.deviceai.ContinuumAvatarNativeUiTest` | 3 |
| `at.heinz.deviceai.ContinuumBotTaskRoutingUiTest` | 11 |
| `at.heinz.deviceai.ContinuumHologramMotionUiTest` | 6 |
| `at.heinz.deviceai.ContinuumReferenceCockpitUiTest` | 8 |
| `at.heinz.deviceai.ContinuumTaskEffectsCallerUiTest` | 5 |
| `at.heinz.deviceai.ContinuumTaskEffectsUiTest` | 3 |
| `at.heinz.deviceai.JarvisShellStageUiTest` | 3 |
| `at.heinz.deviceai.JarvisAvatarSlotUiTest` | 1 |
| `at.heinz.deviceai.MemoryRecallActivityUiTest` | 2 |
| `at.heinz.deviceai.ui.JarvisMemorySignalWiringUiTest` | 5 |
| `at.heinz.deviceai.ui.JarvisSequenceTurnLifecycleUiTest` | 25 |

Der bestehende Validator erlaubt Skip außerhalb seiner elf Pflichtsuiten; solche Fälle transparent auflisten, niemals als ausgeführte Fähigkeit zählen. Die fünf Mindestklassen und die konkret verlangte C1-Anschlussabdeckung dürfen nicht stillschweigend verschwinden.

### Lintumfang

`:app:lintDebug` prüft durch `checkOnly=NewApi` ausschließlich NewApi, mit `abortOnError=true`; `checkReleaseBuilds=false`. Der Ergebnistext muss diesen begrenzten konfigurierten Umfang nennen. Kein Anspruch auf sämtliche Android-Lintkategorien.

## 5. Bedingtes unsigniertes Originalpaket

Erst nach verifizierten erforderlichen Node-/Backend-/Android-/Evidence-Gates auf demselben festgelegten Quellstand, ausreichendem Platz und unveränderter Quelle vorbereiten. Der zentrale Launcher sammelt seinen Assembly-Schritt auch nach anderen roten Gates und verwirft abschließend den Gesamtstand; daraus entsteht keine Freigabe. C1 kann bei einem roten früheren Gate begründet anhalten und zuerst dessen Ursache bearbeiten.

```bash
c1_gate unsigned-apk "$c1_gradle" --offline --no-daemon --rerun-tasks --max-workers=2 --console=plain \
  '-Dorg.gradle.jvmargs=-Xmx1600m -XX:MaxMetaspaceSize=512m' \
  -Pkotlin.compiler.execution.strategy=in-process \
  -PdeviceAiMentorPreview=true -PcontinuumLocalRenderUnsigned=true \
  -PcontinuumStandaloneVersionCode=41 :app:assembleRelease :app:bundleRelease
```

Der Code41 ist hier weiterhin nur ein reproduzierbarer **nicht veröffentlichter QA-Artefaktparameter**. Für ein künftiges Besitzerupdate muss der dann tatsächlich aktuelle Geräte-/Kanalstand neu gelesen und ein zulässiger höherer Code ausdrücklich gebunden werden; dieser Kanal ist hier UNVERIFIED.

- QA-Debugidentität: `at.heinz.deviceai.continuumlocal.qa`, Label `Continuum Lokal QA NICHT INSTALLIEREN`; erlaubte Aufgaben ausschließlich Compile/Test/Lint, keine QA-APK-Erzeugung.
- Unsigned-Transport: `at.heinz.deviceai.continuumlocal`; `signingConfig=null`; nur `assembleRelease` und optional `bundleRelease`. Kein zusätzlicher Testfilter/Init-Hook für diesen Taskblock.
- Gradle verlangt kanonischen Code26..9999; zentraler Launcher enger39..9999. Name ist `0.3.(code−1)`.
- Originalsignierungs-Konfiguration: Alias `continuum-local`, PKCS12. Historischer Zertifikatanker aus #475: `6354e91dc0ca8df9173885f32402fd817f46e798f369206d4fd710ff3d03ee23`; das ist keine frische Prüfung des Geräts oder Kanals.
- APK-Abnahme: normale Nicht-Symlink-Datei über1.000.000Bytes, SHA-256/Größe, `aapt2 dump badging` exakt zu Originalpaket/Code/Name; `apksigner verify` darf das erwartete unsignierte Artefakt nicht als signiert bestätigen. Tatsächliche Tools/Parameter/Quellen und alle Gates binden.
- Höchster erlaubter Ergebnisstatus dieses unsignierten Schritts: `UNSIGNED_BUILD_VERIFIED_DEVICE_NOT_RUN`. Originalsignierung, Veröffentlichung, Downloadfreigabe und Installation bleiben eigene bestehende Freigabe-/Verifikationsschritte.

## 6. Ein Integrationsbranch, getesteter Ancestor und nachfolgender Belegcommit

Nach Abschluss des aktiven Intake auf dem vorhandenen Branch den tatsächlich zu testenden Quellcommit **S** und dessen vollständigen Tree **T** festlegen. Alle verpflichtenden Läufe starten und enden auf S. Keine Quellen-, Test-, Wrapper- oder Dokumentationsmutation während dieser Gates. Originale Receipts behalten genau ihre tatsächliche `source.commit`.

Anschließend auf demselben Branch einen separaten Belegcommit **E** erzeugen, dessen Änderungen ausschließlich unter `docs/` liegen. Die Evidenz nennt S ausdrücklich als getesteten Ancestor; E trägt `EVIDENCE_ONLY / NOT_RUN_ON_E`. Kein Amend/Squash des getesteten S und kein nachträgliches Umschreiben von Rohreceipts. Eine zusätzliche Integrationsbranch ist dafür nicht nötig.

Lokal S→E und remote veröffentlichter S-Gegenpart→E-Gegenpart jeweils in ihrer tatsächlichen Objekthistorie prüfen:

```bash
git merge-base --is-ancestor "$tested_source_commit" "$evidence_commit"
git diff --name-status "$tested_source_commit" "$evidence_commit"
git diff --quiet "$tested_source_commit" "$evidence_commit" -- . ':(exclude)docs/**'
```

Die beiden Variablen sind mit den **dann existierenden** Commit-IDs zu belegen, nicht ausgedachte zukünftige SHAs. `git diff` muss mindestens die gewünschten Belegdateien nennen und außerhalb `docs/` leer sein. Gesamttree von E ist wegen neuer Belege anders; der alte vollständige Testtree T wird unverändert im Receipt geführt. Die codebezogenen Unterbäume bleiben zusätzlich identisch.

Bei getrennten lokalen/Connector-Historien ausdrücklich beide IDs und die unabhängig geprüfte vollständige Baumgleichheit speichern. **Lokales4da und Remote20d9 sind nicht derselbe Commit; Baumgleichheit ist kein Cross-History-Ancestrybeweis.** Der ursprüngliche lokale Lauf bleibt an seinen echten lokalen SHA gebunden. Keine PASS-Behauptung auf E oder einer anderen späteren SHA ohne dort ausgeführten neuen Lauf.

## 7. Offene Grenzen und Koordination

Diese Arbeit hat null Builds, null Tests, null Netzwerkzugriffe und keine Repoänderungen ausgeführt. Gesamt-PASS, Modellinferenz, Gerät/Fold7, native GPU/3D und reale Audiozustellung sind nicht belegt. Frühere gezielte Ergebnisse bleiben ausschließlich an ihre jeweils genannten Quellen gebunden.

C1 hat inzwischen tatsächliche Memory- und Landscape-ACK-/Finalmeldungen in #519-Kommentaren gelesen; die frühere pauschale Aussage „keine ACK beobachtet“ aufgrund bloßer PR-Body-Lektüre war unvollständig. Diese Vorlage übernimmt die Korrektur als Parent-Mitteilung; C2 weiterhin ohne beobachtetes ACK. Neue Beiträge und der separate historische Boardlinkfehler werden nicht in diese Kandidatenidentität hineinerfunden.

## Beobachtung beim Speichern der Vorlage

HEAD blieb4da039d. Der Arbeitsbaum war inzwischen durch den laufenden C1-Intake **nicht mehr sauber**: geändert waren `ContinuumReferenceCockpitUiTest.kt`, `ContinuumTaskEffectsCallerUiTest.kt` und `JarvisShellStageUiTest.kt`; hinzu kam das ungetrackte Belegverzeichnis `docs/evidence/c1-integration-20261104/ui015-own-negative/`. Das JSON enthält die genaue Statusausgabe. Dieser Helfer hat keine dieser Änderungen erzeugt. Die gehashten Quellverträge und das Methodeninventar beziehen sich weiterhin ausschließlich auf den unveränderlichen4da039d-Commit; diese Vorlage bestätigt keinen aktuellen finalen Arbeitsstand.
