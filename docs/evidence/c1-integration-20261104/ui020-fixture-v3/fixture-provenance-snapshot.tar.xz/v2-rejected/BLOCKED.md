# V2 blockiert — nicht importieren

Der manuelle öffentliche Saved-State-Neuaufbau ist kein äquivalenter Ersatz für den originalen Recreationpfad. Er setzt isChangingConfigurations nicht und übernimmt die NonConfigurationInstances nicht. AgentActivity verwendet das Flag tatsächlich in LocalDialogueRetention.activityDestroyed und vor Runtime-Unload. Die bisherigen Draft-/WorkArea-/Kompaktassertions allein beweisen diese Lebenszyklusgrenze nicht.

Der vorhandene Patch bleibt als verworfene, ungeprüfte Hypothese erhalten. Keine Tests/Builds ausgeführt; keine C1-Übernahme. Die nullsichere Diagnosebeschriftung und die explizite Decor-Messung sind getrennte Fixturekorrekturen; sie ersetzen keine korrekte Recreation. V3 muss den ursprünglichen Konfigurations-/NonConfig-Pfad erhalten und den realen Traversal bei weiterhin begrenzter, pausierter VSync erlauben.
