#!/usr/bin/env python3
"""Read-only source/receipt analysis. Does not execute project code or tests."""
from pathlib import Path
import ast, collections, hashlib, json, re, shutil, subprocess, zipfile
ROOT=Path('/workspace/scratch/174c84456ee3')
SRC=ROOT/'repair-review/ui020-fixture-v2'
OUT=ROOT/'source-audit/ui020-fixture-v2'
REPO=ROOT/'continuum-c1'
OUT.mkdir(parents=True,exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def meta(b): return {'bytes':len(b),'sha256':sha(b),'blob':blob(b)}
def save(name,b):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b if isinstance(b,bytes) else b.encode())
def savejson(name,x): save(name,json.dumps(x,indent=2,ensure_ascii=False)+'\n')
m=json.loads((SRC/'FIXTURE-V2.json').read_text())
path=m['path'];base=(SRC/'base-ContinuumReferenceCockpitUiTest.kt').read_bytes()
target=(SRC/'target-ContinuumReferenceCockpitUiTest.kt').read_bytes()
patch=(SRC/'C1-UI-020-fixture-v2.patch').read_bytes()
assert sha(patch)==m['patchSha256']=='073fff46afbacb0758a1f6adffac283a125ad8c47188162d7ab9d0db5096c854'
assert len(patch)==m['patchBytes']
assert blob(base)==m['baseBlob']=='315f42d32518f0c8de4a73cb46c349bd8dbb04d6'
assert sha(base)==m['baseSha256']
assert blob(target)==m['targetBlob']=='5cf932547c0c57486dbbe95316517913dc6c3ac5'
assert sha(target)==m['targetSha256']
gitbase=subprocess.check_output(['git','-C',str(REPO),'show',m['baseCommit']+':'+path])
assert gitbase==base
treemode=subprocess.check_output(['git','-C',str(REPO),'ls-tree',m['baseCommit'],'--',path]).decode().split()[0]
assert treemode=='100644'
lines=patch.decode().splitlines(True);old=base.decode().splitlines(True);out=[];cursor=0;i=0;hunks=[]
assert sum(s.startswith('diff --git ') for s in lines)==1
assert lines[0].rstrip()==f'diff --git a/{path} b/{path}'
while not lines[i].startswith('@@ '):i+=1
while i<len(lines):
    match=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n',lines[i]);assert match
    at=int(match[1])-1;oldcount=int(match[2] or 1);newcount=int(match[4] or 1)
    assert at>=cursor
    out+=old[cursor:at];cursor=at;assert len(out)==int(match[3])-1
    i+=1;seenold=seennew=0
    while i<len(lines) and not lines[i].startswith('@@ '):
        pfx=lines[i][0];v=lines[i][1:];assert pfx in ' +-'
        if pfx in ' -':assert old[cursor]==v;cursor+=1;seenold+=1
        if pfx in ' +':out.append(v);seennew+=1
        i+=1
    assert (seenold,seennew)==(oldcount,newcount)
    hunks.append({'old_start':at+1,'old_count':oldcount,'new_start':int(match[3]),'new_count':newcount})
out+=old[cursor:];assert ''.join(out).encode()==target
# Extract only our previously reviewed pure lexer helpers. The prior receipt's
# module-level repository analysis is not imported or executed.
tree=ast.parse((ROOT/'source-audit/ui020/review_readonly.py').read_text())
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('mask_kotlin','endbalanced','inspect_class')]
env={'re':re}
exec(compile(ast.Module(body=functions,type_ignores=[]),'<own-static-kotlin-lexer>','exec'),env)
inspect=env['inspect_class'];mask=env['mask_kotlin']
bm,ba,bh=inspect(base.decode(),'ContinuumReferenceCockpitUiTest')
tm,ta,th=inspect(target.decode(),'ContinuumReferenceCockpitUiTest')
assert bm==tm==[x['name'] for x in m['methods']] and len(tm)==8
assert bh==th
primitive_names={'assertEquals','assertFalse','assertNotNull','assertSame','assertTrue'}
def canonical(s): return re.sub(r'\s+',' ',s).strip()
def primitives(calls):
    return [canonical(x) for x in calls if re.match(r'\w+',x)[0] in primitive_names]
bp=primitives(ba);tp=primitives(ta)
# Exactly one original primitive assertion now names the new controller.
rename_old='assertTrue(controller.get().window.decorView.isAttachedToWindow)'
rename_new='assertTrue(resumedController.get().window.decorView.isAttachedToWindow)'
assert bp.count(rename_old)==1 and tp.count(rename_new)==1
normalized_bp=[rename_new if x==rename_old else x for x in bp]
removed=list((collections.Counter(normalized_bp)-collections.Counter(tp)).elements())
added=list((collections.Counter(tp)-collections.Counter(normalized_bp)).elements())
assert removed==[]
assert len(bp)==125 and len(tp)==130 and len(added)==5
for token in ('@Ignore','performClick('): assert token not in mask(target.decode())
assert not re.search(r'\bassume\w*\s*\(',mask(target.decode()))
helper_start='    private fun assertMinimumTarget('
def fn_source(s,start):
    p=s.index(start);masked=mask(s);o=masked.index('{',p);e=env['endbalanced'](masked,o,'{','}')
    return s[p:e]
for fn in ('assertMinimumTarget','assertRealTargets','assertRailGeometry','checkProfile'):
    start='    private fun '+fn+'('
    assert fn_source(base.decode(),start)==fn_source(target.decode(),start)
# Original real tap path after the diagnostic label remains byte-identical.
bs=fn_source(base.decode(),'    private fun tap(')
ts=fn_source(target.decode(),'    private fun tap(')
assert bs[bs.index('        var parent = target.parent'):]==ts[ts.index('        var parent = target.parent'):]
# The public lifecycle setup remains sdk28 and full real-window attachment.
assert '@Config(sdk = [28]' in target.decode()
provenance=json.loads((SRC/'controller-provenance.json').read_text())
jar=Path(provenance['jar'])
assert sha(jar.read_bytes())==provenance['jarSha256']
with zipfile.ZipFile(jar) as z: cb=z.read(provenance['class'])
assert sha(cb)==provenance['classSha256']
assert sha((SRC/'ActivityController-4.14.1.javap.txt').read_bytes())==provenance['javapSha256']
sdk=json.loads((SRC/'sdk28-provenance.json').read_text())
sdkreads=[]
with zipfile.ZipFile(sdk['jar']) as z:
    for name,expected in sdk['classesSha256'].items():
        b=z.read(name);assert sha(b)==expected
        sdkreads.append({'class':name,'sha256':sha(b),'bytes':len(b)})
actpath='app/src/main/java/at/heinz/deviceai/AgentActivity.kt'
act=subprocess.check_output(['git','-C',str(REPO),'show',m['baseCommit']+':'+actpath])
acttext=act.decode()
assert 'LocalDialogueRetention.activityDestroyed(isChangingConfigurations)' in acttext
assert 'if (!isChangingConfigurations && !retainGemma &&' in acttext
assert 'class AgentActivity : Activity()' in acttext
p=acttext.index('    override fun onSaveInstanceState(');q=acttext.index('    override fun ',acttext.index('    override fun onDestroy()',p)+10)
save('frozen/AgentActivity-onSave-onDestroy.txt',acttext[p:q])
for f in sorted(SRC.rglob('*')):
    if f.is_file():
        save('frozen/'+str(f.relative_to(SRC)),f.read_bytes())
savejson('assertion-integrity.json',{
 'kind':'STATIC_SOURCE_COMPARISON_ONLY','methods_before':bm,'methods_after':tm,
 'all_assert_prefixed_calls_before':len(ba),'all_assert_prefixed_calls_after':len(ta),
 'primitive_junit_assertions_before':len(bp),'primitive_junit_assertions_after':len(tp),
 'allowed_equivalent_receiver_rename':{'before':rename_old,'after':rename_new},
 'removed_original_primitive_assertions':removed,'added_primitive_assertions':added,
 'unchanged_helpers':['assertMinimumTarget','assertRealTargets','assertRailGeometry','checkProfile'],
 'real_tap_dispatch_and_scroll_path_byte_identical_after_label':True,
 'no_new_ignore_assumptions_or_performClick':True,
 'limitation':'Preserved assertions do not preserve the lifecycle stimulus. V2 omits changingConfigurations and retained NonConfigurationInstances.'})
savejson('C1-UI-020-fixture-v2-independent-review.json',{
 'task':'C1-UI-020-FIXTURE-V2-REVIEW','verdict':'BLOCKED_ROTATION_SEMANTICS_GAP',
 'reason':'Manual destroy/new does not set changingConfigurations=true or carry NonConfigurationInstances; production onDestroy branches on that flag.',
 'base_commit':m['baseCommit'],'base_tree':m['baseTree'],'file':path,'mode':treemode,
 'base':meta(base),'target':meta(target),'patch':meta(patch),'hunks':hunks,'reconstructed_target_match':True,
 'assertions':{'methods':8,'primitive_before':len(bp),'primitive_after':len(tp),'removed_after_equivalent_receiver_rename':removed,'added':added,'all_assert_prefixed_before':len(ba),'all_assert_prefixed_after':len(ta)},
 'lifecycle':{'sdk':28,'old_sequence':'windowFocusChanged(false) -> pause -> stop -> saveInstanceState(Bundle) -> destroy -> isDestroyed assertion',
   'new_sequence':'buildActivity(new object) -> create(Bundle) -> start -> restoreInstanceState(Bundle) -> postCreate(Bundle) -> resume -> postResume -> visible -> 16ms frame advance -> attached assertion -> focus',
   'valid_public_saved_state_sequence':True,'topActivityResumed_sdk28':'No-op per existing controller bytecode API<29 guard',
   'actual_recreate_changingConfigurations_true':True,'actual_recreate_retains_nonconfiguration_instances':True,
   'v2_sets_changingConfigurations_true':False,'v2_transfers_nonconfiguration_instances':False,
   'equivalent_rotation':'NO','process_death_equivalence':'NOT_CLAIMED; same Application/static state remains'},
 'cleanup':{'tracks_all_fixture_created_controllers':True,'reverse_order_close':True,'destroy_fallback':True,'destroyed_assertion':True,
   'preserves_primary_failure_with_suppressed_cleanup_failures':True,'cleanup_failure_fails_successful_body':True,'font_restoration_in_cleanup':True,
   'limits':['Pre-try preference setup/controller-construction failures retain the old pre-try cleanup boundary; this is not a new V2 regression.',
             'Actual destruction and cleanup have not been run by this reviewer. isDestroyed flag is necessary but alone does not prove all teardown work completed; thrown failures remain visible.']},
 'production_source_evidence':{'commit':m['baseCommit'],'path':actpath,**meta(act),
   'material_branches':['LocalDialogueRetention.activityDestroyed(isChangingConfigurations)','!isChangingConfigurations && !retainGemma before model unload']},
 'framework_evidence':{'controller_jar_hash_independently_matches':True,'controller_class_hash_independently_matches':True,
   'supplied_javap_hash_matches_provenance':True,'sdk28_classes_independently_read':sdkreads,
   'disassembly_generation':'Not rerun; read supplied javap text and independently verified original JAR/class hashes'},
 'recommendation':'Do not integrate V2 as equivalent rotation coverage. Review V3 preserving actual recreate semantics and the original assertions.',
 'execution':{'tests':'NOT_RUN','builds':'NOT_RUN','project_code':'NOT_EXECUTED','repository_edits':'NONE','locks':'NOT_ACQUIRED','external_C2_ACK':'NOT_CLAIMED'}})
print(json.dumps({'verdict':'BLOCKED_ROTATION_SEMANTICS_GAP','patch_sha256':sha(patch),'target_blob':blob(target),'methods':len(tm),'primitive_assertions':[len(bp),len(tp)],'all_assert_prefixed':[len(ba),len(ta)],'removed_primitive_assertions':removed,'added_primitive_assertions':added,'hunks':len(hunks),'framework_hashes_match':True},indent=2))

