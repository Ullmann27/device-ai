# C1-UI-020 Fixture V2 — unabhängiger statischer Review

## Entscheidung: BLOCKIERT wegen verlorener Rotationssemantik

Der vorgelegte Patch ist als Ersatz für den bisherigen Rotations-/Recreate-Test nicht übernehmbar. Er erhält die funktionalen Assertions, ändert aber den auslösenden Lebenszyklus so, dass andere Produktionszweige ausgeführt werden. Eine engere Saved-State-Neuinstanzprüfung wäre eine andere Abnahmegrenze und ersetzt den ursprünglichen Auftrag nicht.

Die tatsächliche AgentActivity ruft im unveränderlichen C1-Stand `f31855138d77ecb5e05e7a17a620b1fd6e9d28c5` in `onDestroy` sowohl `LocalDialogueRetention.activityDestroyed(isChangingConfigurations)` auf als auch die Bedingung `!isChangingConfigurations && !retainGemma` vor dem Modell-Unload. Der normale Robolectric-4.14.1-`recreate()`-Bytecode setzt `changingConfigurations=true` und überträgt die zurückbehaltenen NonConfigurationInstances an die neue Activity. **V2 tut beides nicht.** Dies ist eine beobachtbare Änderung der getesteten Produktionspfade, keine rein technische Traversal-Reparatur.

Der Befund wurde Root und repair_review unmittelbar gemeldet. repair_review hat die Blockade bestätigt und untersucht V3 mit Erhalt der ursprünglichen Recreate-Semantik. Es wurde kein Ersatztest ausgeführt und keine Anforderung abgesenkt.

## Identität und Assertionintegrität

| Gegenstand | Unabhängig geprüft |
| --- | --- |
| Pfad | `app/src/uiTest/java/at/heinz/deviceai/ContinuumReferenceCockpitUiTest.kt` |
| Basisblob | `315f42d32518f0c8de4a73cb46c349bd8dbb04d6` |
| Zielblob | `5cf932547c0c57486dbbe95316517913dc6c3ac5` |
| Ziel-SHA256 | `dc8087c6d8fc65fae9630d3f6c363db3dd5019a77b83385be8581a6d3f53d34f` |
| Patch-SHA256 | `073fff46afbacb0758a1f6adffac283a125ad8c47188162d7ab9d0db5096c854` |
| Umfang | Eine Testdatei, neun Hunks, Dateimodus 100644 |
| Methoden | Alle acht Namen und vorhandenen Profilkonfigurationen erhalten |
| Primitive JUnit-Assertions | 125 → 130; keine ursprüngliche Assertion entfernt |
| Alle assert-präfigierten Aufrufe inkl. Helper | 151 → 156; lexikalische Zählung, kein Laufbeleg |

Die neun Hunks wurden im Speicher auf die tatsächliche Git-Basis angewendet; das vollständige Resultat stimmt bytegenau mit dem angegebenen Ziel überein. Nur eine ursprüngliche Assertion benennt ihren Controller entsprechend der neuen Variablen um. Die fünf ergänzten JUnit-Assertions betreffen alte Decor-Anbindung, tatsächliches Destroy, andere Activity-Instanz, zerstörte Fixture-Activities und Anbindung vor erneutem Fokus.

`assertMinimumTarget`, `assertRealTargets`, `assertRailGeometry` und `checkProfile` bleiben vollständig bytegleich. Der tatsächliche Scroll-/DOWN-/UP-Dispatch im Tap-Helper bleibt nach der diagnostischen Labelwahl bytegleich. Es gibt kein neues Ignore, keine Assumption und kein performClick. Der nullsichere Label-Fallback ändert nur den Fehlertext. Die ergänzte Decor-Messung vor der Rücknavigation setzt keine künstlichen Zielgrößen einzelner Controls; sie verwendet die aktuellen Fenstermaße und behält die anschließenden realen Ziel-/Klickprüfungen bei.

Diese positive Assertionintegrität hebt den Lifecycle-Blocker nicht auf.

## Öffentliche SDK-28-Sequenz und Cleanup

Die vorgeschlagene Folge `pause → stop → saveInstanceState(Bundle) → destroy` sowie `create(Bundle) → start → restoreInstanceState(Bundle) → postCreate(Bundle) → resume → postResume → visible` verwendet vorhandene öffentliche Controller-Methoden. Nach 16 ms virtueller Framezeit wird die Decor-Anbindung ausdrücklich geprüft, bevor Fokus gesetzt wird. `topActivityResumed(true)` ist im gelesenen 4.14.1-Bytecode für API <29 ein No-op. Die Reihenfolge ist als Saved-State-Destroy/Neuinstanz nachvollziehbar; sie ist weder NonConfig-Rotation noch echter Prozessneustart.

Das Cleanup ist gegenüber V1 strenger: Alle von der Fixture erzeugten Controller werden registriert, in umgekehrter Reihenfolge geschlossen, bei Bedarf zerstört und auf `isDestroyed` geprüft. Primäre Testfehler werden erneut geworfen; Cleanupfehler werden als suppressed ergänzt. Ohne primären Fehler schlägt ein Cleanupfehler den Test fehl. Die Font-Rücksetzung bleibt im Cleanup und Fehler dabei werden sichtbar. `close()` ist laut gelesenem Controller-Bytecode zustandsabhängig; bereits zerstörte Controller werden nicht ein zweites Mal regulär pausiert/gestoppt.

Grenzen: Die vor dem try-Block liegende Präferenz-/Controller-Erstellung behält die alte Cleanup-Grenze; ein Fehler dort wäre nicht vollständig durch dieses finally abgedeckt. Dies ist kein neu eingeführter V2-Fehler. Das SDK setzt `isDestroyed` am Anfang von `performDestroy`; allein dieses Flag beweist daher kein fehlerfreies Ende jeder Teardownarbeit. Die V2-Fehlerbehandlung verschluckt entsprechende geworfene Fehler jedoch nicht.

## Quell- und Frameworkbelege

Der ursprüngliche JAR-Hash von shadows-framework 4.14.1, der ActivityController-Klassenhash und die beiden SDK-28-Klassenhashes für Activity/Instrumentation wurden unabhängig aus den vorhandenen Archiven gelesen und mit der Provenienz verglichen. Die mitgelieferte ActivityController-javap-Datei stimmt mit ihrem Provenienz-Hash überein. Die vorhandenen Disassemblierungen wurden gelesen; hier wurde kein javap-/Java-/Android-Lauf ausgeführt. Relevanter Produktionsquelltext, Originalpatch, Basis/Ziel, Provenienzen und ursprünglicher RED sind unter `frozen/` gesichert.

Der frühere RED bleibt 8 Fälle, 1 PASS, 7 FAIL, 0 SKIP. Er belegt die alte Quelle und wird nicht auf V2 übertragen. **V2: NOT_RUN, BLOCKED_ROTATION_SEMANTICS_GAP.** Keine Repositoryänderung, Tests, Builds, Locks oder externer C2-ACK.

