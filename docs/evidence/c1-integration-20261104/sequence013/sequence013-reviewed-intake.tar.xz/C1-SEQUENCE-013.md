# C1-SEQUENCE-013 — begrenztes Abschlusszustellungs-Paket

Status: **SCRATCH_INTAKE_READY**, nicht angewandt und von diesem Helfer nicht gebaut oder getestet.

## Gebundene Quellen

- C1-Patchbasis: `53ca8b6e3284c27c9c06f1462c469c7cff300e7d`, Baum `39cbcfbd0b5fd0e1f95360aba42f2fa650f9deae`.
- Nachgemeldeter C1-Stand: `ce5bcf6d7c7e87e630b33df86d021dfd4bd52ccd`. Alle 14 betroffenen Basisblobs/Modi sind gegenüber der Patchbasis unverändert; die drei separat integrierten Temporal-Dateien gehören nicht zu diesem Patch.
- Ursprüngliche Quelle: #505 `b2bc510a59e29d4ece478109e12b9785be11ee7d`; lokale, bytegleiche Materialisierung der 14 Dateien in #517 `f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4`, Baum `e996a49cabf181e67156400f51df2a10c85e5a13`.
- Provenienz: unverändertes `round2-505-manifest.json`, SHA-256 `109cc0bf7c10bbc4e521d54015502db2bc0602c7bb773356ee78135f8edcc69c`. Die lokalen Git-Objekte für #505 und den externen Queue-RED-Commit waren nicht vorhanden; die Zielbytes wurden aus dem gepinnten #517-Commit gelesen und gegen alle 14 Quellblobs/SHA-256/Modi dieses ursprünglichen Manifests geprüft. Die späteren Originalbelege wurden separat vom gepinnten Belegcommit `e83f6ac18243b42aadbe8da88df074c7ea1811ef` gelesen.
- Patch: `C1-SEQUENCE-013.patch`, 34980 Bytes, SHA-256 `23c38bf141923ed53a9403f3502683ecd97584303f38feb54ced791eb41e2cf8`.

## Exakter Patchumfang

Genau **14 Dateien**: zwei bestehende App-Dateien und das vollständige neue Werkzeug mit zwölf Dateien. Alle Zielmodi bleiben `100644`, auch `tools/sequence-turn-check/run.sh`; Aufruf mit `bash`. Keine automatische Modusanhebung.

| Pfad | C1-Basisblob | Zielblob #505/#517 | Zielmodus |
| --- | --- | --- | --- |
| `app/src/main/java/at/heinz/deviceai/ui/JarvisSequenceView.kt` | `bd943129a52c92ccb46022c0f083e328acbf24b9` | `86d39aedf0fadb6e0633bec42112b36f3a6fea9c` | `100644` |
| `app/src/uiTest/java/at/heinz/deviceai/ui/JarvisSequenceTurnLifecycleUiTest.kt` | `265b67a874deecedc262b3403349f2151e09af1e` | `51db7f4f6996b314ff715a7ea0978b9b744578dd` | `100644` |
| `tools/sequence-turn-check/README.md` | `absent` | `2456ef7b659c0504ef70b2c6af59d213acc8a814` | `100644` |
| `tools/sequence-turn-check/SequenceLifecycleHostTest.kt` | `absent` | `57d572cee8c0fd959b05e79e06bbe731847c2241` | `100644` |
| `tools/sequence-turn-check/fixtures/AndroidContinuumPainter.kt` | `absent` | `90215867a0bce33d1d9d8050af1873308783a8ae` | `100644` |
| `tools/sequence-turn-check/fixtures/Canvas.kt` | `absent` | `55f9830a93f49e26826aa66dbab72b0598608ca0` | `100644` |
| `tools/sequence-turn-check/fixtures/Clock.kt` | `absent` | `44a9036b054884aaf0ea5f7ffaf3111f0f2cbf6c` | `100644` |
| `tools/sequence-turn-check/fixtures/Context.kt` | `absent` | `bc17a921b3747f36c1d0efeaa84052d2d2d77481` | `100644` |
| `tools/sequence-turn-check/fixtures/DisplayMetrics.kt` | `absent` | `2f9b0601fbd09a1cec4f0b5f39e85dd6dc7644db` | `100644` |
| `tools/sequence-turn-check/fixtures/Handler.kt` | `absent` | `bc432c4e33c8a078b69d46fecd4e3545b6e6dc35` | `100644` |
| `tools/sequence-turn-check/fixtures/Resources.kt` | `absent` | `195fe8046da71a915593f3b0b3fe4550f5d201e6` | `100644` |
| `tools/sequence-turn-check/fixtures/UnavailablePillLabels.kt` | `absent` | `0557fa864939401a3eedf71e2a92a861a435a62d` | `100644` |
| `tools/sequence-turn-check/fixtures/View.kt` | `absent` | `e84c5349bc4a1e4649830e179db6b4970a6f1e53` | `100644` |
| `tools/sequence-turn-check/run.sh` | `absent` | `011816b1a8c0635d58674d9cb3307b168370abcb` | `100644` |

Explizit ausgeschlossen:

- `app/src/main/java/at/heinz/deviceai/learning/ContinuumMemoryRetriever.kt`
- `app/src/test/java/at/heinz/deviceai/learning/TemporalCueDailyBoundaryTest.kt`
- `tools/temporal-cue-host-check/run.sh`

## Minimale Quellbegründung

`TurnEnded` stellt bereits empfangene Abschlussinformation dar. Es wird deshalb vor der Motion-/Detach-Sperre in die bestehende Historie aufgenommen. Nur dessen Hintergrundzustellung wechselt von `View.post` zu `Handler(Looper.getMainLooper())`, damit sie kein späteres Attach dieser View voraussetzt. Normale visuelle Ereignisse behalten Motion-/Detach-Sperre, `View.post` und den Generationsschutz. `clear()`, das Limit von 24 IDs, der getrennte Memory-Strom und die Fortsetzbarkeit nicht abgeschlossener Arbeit bleiben erhalten. Die elf bisherigen UI-Testmethoden bleiben bestehen; vierzehn konkrete Fälle ergänzen sie auf 25. Die neue Hosthülle hat 20 Sequenzmethoden plus fünf unveränderte BrainOrb-Regressionsfälle.

Die Änderung rekonstruiert keine Ereignisse, die dieser Subscriber nie erhielt. Neue View-/Avatarinstanzen übernehmen keinen alten Verlauf. Die 24 IDs begrenzen die bereits verarbeitete Präsentationshistorie, nicht die Android-MessageQueue. Worker-Ausführung, Nutzerfreigaben, ToolGate, Modelle, Paket/Version/Signatur und Gerätebehauptungen werden nicht geändert.

## Originale RED/GREEN-Belege

Die vollständigen Originaldateien liegen unter `evidence/upstream/`. Keine Zeile und kein abschließender Zeilenumbruch wurde normalisiert. Alle 26 gespeicherten Originaldateien wurden gegen ihren Git-Blob geprüft; alle im Queue-Receipt referenzierten Rohdateien zusätzlich gegen dessen SHA-256. Zwei leere Host-Compilerlogs sind durch das GitHub-Verzeichnis mit Größe 0 und Git-Blob `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391` belegt; der Blob-Textabruf lieferte dafür keinen Text. Der vollständige Quellenindex steht im JSON.

| Originalprüfung | Tatsächliches Ergebnis | Quellbindung und Grenze |
| --- | --- | --- |
| Host-RED | 25 Fälle, 3 Assertion-Fehler | Produktionsblob `bd943129a52c92ccb46022c0f083e328acbf24b9`, identisch zum C1-Basisblob; vollständige Originalquellen mit offen dokumentierten Android-/Painter-Stand-ins. |
| Host-Handler-GREEN | 25 Fälle, 0 Fehler | Zielblob `86d39aedf0fadb6e0633bec42112b36f3a6fea9c`; Host-Handler wirft bei `post` und simuliert keine Queue. |
| Echter fokussierter Robolectric-RED | 2 gezielte Methoden, 2 Assertion-Fehler | **Zwischenstand `d24ad51b0235826cf0baaa998a2fb4af80a17404`**, Produktionsblob `e892cdc13a6dbc30e9b11275861a6826ffea978f`; ausdrücklich **nicht C1-Basis**. |
| Echter fokussierter Robolectric-GREEN | 25 Methoden, 0 Fehler | Lokal `d91fe8b1141d35341b67298a04f3913fd1bf0876`, veröffentlichte Quelle `b2bc510a59e29d4ece478109e12b9785be11ee7d`, Baum `7770e3ef628f301bf40161e4a99906836c63b296`; Produktionsblob und Testblob stimmen mit dem Zielpaket überein. |

Die beiden Queue-RED-Fälle sind `backgroundCompletionBeforeFirstAttachDoesNotWaitForAttachment` und `detachedSubscriberRetiresBackgroundCompletionsWithoutReattach`. Testblob vor/nach dem Handlerfix: `51db7f4f6996b314ff715a7ea0978b9b744578dd`. Der RED meldet eine wieder sichtbare Karte bzw. eine leere statt der letzten 24 Abschluss-IDs; GREEN meldet im Original-JUnitlog `OK (25 tests)`.

Originale Startbefehle und alle Classpath-/SDK-/Quellhashes stehen in den beiden `build/robolectric-*/manifest.json`; der unveränderte damalige Launcher `build/run-direct-robolectric.py` ist beigelegt. Diese Befehle wurden hier nicht ausgeführt. Der ergänzende Hostbefehl ist im Werkzeug-README enthalten:

```bash
CONTINUUM_KOTLIN_COMPILER_LIB=/workspace/scratch/b7d23de0e715/build-toolchain/gradle-8.11.1/lib \
  bash tools/sequence-turn-check/run.sh /absoluter/neuer/ausgabeordner
```

## C1-Abnahme und Grenzen

Der externe GREEN-Lauf ist kein identischer C1-Quellabschluss. Abweichende Eingangsdateien: `app/src/main/java/at/heinz/deviceai/avatar/AvatarContract.kt`. Die vollständige Hashgegenüberstellung steht im JSON.

Externes RED/GREEN wird nicht als frischer C1-PASS übernommen. Nach Integration muss C1 seine vollständigen quellgebundenen Android-Gates mit aktivierten UI-Tests einschließlich `JarvisSequenceTurnLifecycleUiTest` ausführen. In diesem Intake erfolgten weder Patchanwendung oder Apply-Check noch Build oder Test.

Die originalen Grenzen des fokussierten Robolectric-Laufs bleiben bestehen:

- No app AndroidManifest.xml: Robolectric explicitly falls back to Android OS resources. Original tests were not edited to suppress the warning.
- Not a full Gradle, APK/resource-packaging, Android device, GPU, audio, signing, release or installation gate.
- Prior full Gradle attempt failed during Kotlin compilation before tests; this focused run does not replace that failure.
- Real compiled business dependency directory comes from the prior 822e build; exact SafePillActionGate source equality and four class hashes are recorded. All observed app-class names belong to the fresh candidate compilation; no Pill class appeared in either trace.

Keine Aussage über reale Modellinferenz, Fold7/GPU/Audio, APK-Abnahme, Signierung, Veröffentlichung oder Installation.
