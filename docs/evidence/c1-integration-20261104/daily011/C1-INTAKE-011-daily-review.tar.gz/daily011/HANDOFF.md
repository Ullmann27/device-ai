# C1-INTAKE-011 — eigenständiger Tagesgrenzen-Slice

**Status: LOCAL_ONLY / NOT_PUSHED / NOT_APPLIED.** Dieses Paket ist ein
quellgebundener Intake für den seriellen Einbau durch C1. Es wurden keine
Repository-Dateien verändert, keine Tests oder Compiler gestartet und keine
gemeinsamen Locks berührt.

## Verbindliche Quellen

- C1-Basis: `165fc9f58ae9e36295690df60145174fd5dc58e7`.
- Veröffentlichter Quellcheckpoint aus PR #505:
  [`b2bc510a59e29d4ece478109e12b9785be11ee7d`](https://github.com/Ullmann27/device-ai/commit/b2bc510a59e29d4ece478109e12b9785be11ee7d),
  Gesamtbaum `7770e3ef628f301bf40161e4a99906836c63b296`.
- Aktueller, im vorangegangenen Intake gelesener #505-Beleghead:
  `e83f6ac18243b42aadbe8da88df074c7ea1811ef`. Seine Unterbäume `app`, `scripts`
  und `tools` wurden mit dem Quellcheckpoint als identisch abgeglichen.
- Der Memory-Autor übergab ursprünglich den lokalen Slice-Commit
  `4b120c2a5d5b8425c0a99d0668a9d869c153ab27`. Für diesen Intake werden ausschließlich
  die veröffentlichten Inhalte des oben genannten Quellcheckpoints verwendet.

Die Zielbytes wurden aus den zuvor bereits gelesenen, exakt gepinnten
GitHub-Quellantworten gesichert. Vor dem Schreiben wurden Git-Blob-Hash und
SHA-256 erneut geprüft. Basisbytes stammen unmittelbar aus unveränderlichen
Git-Objekten des genannten C1-Commits. Der Quellcheckpoint selbst liegt nicht
vollständig als Commitobjekt im fremden Finalization-Checkout vor; es wird keine
lokale Verfügbarkeit dieses Commitobjekts vorausgesetzt.

## Genau drei Repository-Pfade im Patch

| Pfad | Aktion | Dateimodus |
| --- | --- | --- |
| `app/src/main/java/at/heinz/deviceai/learning/ContinuumMemoryRetriever.kt` | ändern | `100644` erhalten |
| `app/src/test/java/at/heinz/deviceai/learning/TemporalCueDailyBoundaryTest.kt` | hinzufügen | `100644` |
| `tools/temporal-cue-host-check/run.sh` | ändern | `100755` erhalten |

`C1-INTAKE-011-daily.patch` enthält nur diese drei Pfade. Basis- und Zielkopien
liegen unter `base/` und `target/`. Für die neue Testdatei existiert absichtlich
keine Basisdatei. `manifest.json` enthält sämtliche Basis-/Zielblobs, SHA-256,
Bytezahlen, Modi, Quell-URLs und den Patch-Hash.

Patch-SHA-256:
`476f92efe30e27ba31b60e5718b25f1c04b93da2df646a54276b6197639d1351`.

Die 14 Dateien der gesonderten Sequence-/Abschlusszustellungsreparatur bleiben
zurückgestellt und sind weder im Patch noch als Quellkopien in diesem Paket.
Der gesamte #505-Quellcommit darf nicht mit diesem Drei-Dateien-Slice gleichgesetzt
werden.

## Problem und vorhandene Reparatur

Der alte `TemporalCue` leitete relative Tagesfenster von einem bereits zonierten
Tagesbeginn ab. Wenn eine Mitternachtslücke den heutigen Tagesbeginn auf 01:00
verschob, konnte dieselbe Uhrzeit bei der Ableitung anderer Tage erhalten bleiben.
Dadurch fehlte etwa die erste Stunde von gestern oder die erste Stunde des
Folgetags wurde noch heute zugeordnet.

Die abgeschlossene Reparatur bestimmt zuerst das lokale `LocalDate` und löst
Anfang und Ende jedes Tagesfensters getrennt mit `atStartOfDay(zone)` auf. Die
bestehenden benannten Wochen-/Monatsfenster, Overflow-Grenzen, Zeitgewichte,
Rankingformeln und Trust-Eigenschaften behalten ihre Bedeutung.

Der Runner ergänzt die neue Testklasse im bestehenden Prüfweg. Damit bilden
Produktionsänderung, zwölf Regressionstests und ausführender Testeinstieg einen
geschlossenen Slice. Hauptchat-Aktivierung, Modellgewichte und die bekannte
Rankinggrenze werden durch diesen Intake nicht verändert.

## Unverändert gesicherte RED/GREEN-Rohbelege

Die folgenden Dateien sind bytegenaue Kopien der Originalprotokolle aus dem
veröffentlichten Beleghead `e83f6ac18243b42aadbe8da88df074c7ea1811ef`:

| Paketdatei | Git-Blob des Originals | SHA-256 der gesicherten Bytes |
| --- | --- | --- |
| `evidence/upstream/host-red.log` | `55583a4ba039f6ae1fdf5668948d5aaa9a5c3d64` | `4bb426b1ed5f1496c91952923ff467b9e33ed05d69eb008df394a2826c7a1680` |
| `evidence/upstream/host-green-before-commit.log` | `e131376476ccfc69cd4fde2d682b03677a1c1608` | `0cdd0a14288c2d92fab2b71fa04b442dccc58aa3e680e06d80478fcd888d4b55` |

Ergebnisse der damaligen Autorenläufe: **RED 29 Tests / 8 Fehler**, anschließend
**GREEN 29 Tests / 0 Fehler**. Die acht roten Methoden sind sechs
Tagesfenster-Regressionen und zwei tatsächliche Retrieval-Regressionen.

Beide Rohlogs nennen als damaligen HEAD noch die Basis, weil sie vor dem
Quellcommit entstanden. Maßgeblich für die tatsächlich kompilierten Bytes sind
ihre SHA-256-Zeilen:

- Retriever RED: `8d095be29157246c8f7dad09e2ae3960519ae816c428dfe399ebcdfe65463e1d`.
  Dieser Hash entspricht exakt der hier gesicherten C1-Basisdatei.
- Retriever GREEN: `ff8671fc578403f5ad53c3b7b0c50ea689dfffdf5f5d6a62ac8ec5e43871486e`.
  Dieser Hash entspricht exakt der Zielquelle dieses Pakets.
- Neue Testdatei in beiden Läufen:
  `d4209213a7ddd6df96e09ad73281ed942b1cf0459da6613a76cf99410acdb3f6`.

Die 15 vorhandenen `TemporalCueCalendarTest`-Methoden und die zwei vorhandenen
`ContinuumRetrievalExperimentTest`-Methoden sind ebenfalls mit den Rohloghashes
abgeglichen und in C1 bytegleich vorhanden. Sie werden nicht erneut als
Patchänderungen ausgeliefert. Der ganze Testsatz umfasst 17 bestehende und zwölf
neue Methoden.

Die Rohprotokolle einschließlich ursprünglicher Pfade, Warnungen und abschließender
Leerzeilen wurden nicht normalisiert oder bearbeitet. Ihre Git-Blob-Hashes wurden
vor der Sicherung gegen die abgerufenen Originale geprüft.

## Aussagegrenzen

Dies sind **Autorenläufe aus #505, keine neuen C1-Ausführungen**. Der Host-Runner
kompiliert die vollständige Original-Retrieverquelle mit Java 17/Kotlin 2.0.20
und JUnit 4.13.2. Der nicht ausgeführte Android-/Event-Decorator besitzt einen
ausdrücklich fehlschlagenden Compile-Stand-in. Der Test führt echte BM25-,
Char-N-Gramm- und Default-Retriever aus, aber keinen Eventpfad, Android-Dialog
oder Modelllauf.

Die bekannten Corpuswerte bleiben unverändert: Char-N-Gramm plus Zeit erreicht
42/44 bei Recall@3; der Theater-Treffer bleibt Rang 5. Das Paket enthält keine
Rankingoptimierung und keinen Nachweis eines allgemeinen Qualitätsgewinns.

Bei der Paketvorbereitung fanden ausschließlich Quellenreads, Hash-/Modusabgleiche
und die Erzeugung des Diffs statt. **Kein Testlauf und kein `git apply` wurden
ausgeführt; auch kein `git apply --check`.** Ein eigener GREEN auf dem kombinierten
C1-Stand ist weiterhin erforderlich.

## Korrektur des getrennten #517-Prüfstatus

Aktualisierung aus der C1-Anweisung, mit Verweis auf die Gegenprüfung durch
`repair_review`; in diesem Intake nicht neu ausgeführt oder anhand weiterer
Rohlogs nachgeprüft:

- Die frühere Angabe **53 Tests / 46 PASS / 7 FAIL** gehört zum älteren Stand
  `92f421fa81c57022d903e2c1ff45ae6279c77b22`.
- Für #517 bei `f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4` ist der neuere
  **gezielte Lauf mit 53 PASS** durch `repair_review` verifiziert.
- Der vollständige Lauf dieses neueren Stands endete bei `ReferenceCockpit`
  nach **180 Sekunden Timeout mit Exit 143**.
- **Kein Gesamt-PASS für #517.** Der gezielte neue PASS ersetzt weder den
  abgebrochenen Gesamtlauf noch die eigene kombinierte C1-Abnahme.

## Serieller Einbau durch C1

Nach Abschluss des laufenden Routing-Android-Prüfschritts prüft C1 die drei
aktuellen Basisdateien gegen `manifest.json`, dann die Patch-Anwendbarkeit.
Nur C1 übernimmt die drei freigegebenen Pfade und führt den gezielten GREEN
unter den bestehenden gemeinsamen Locks aus. Der Runner erwartet die angegebenen
Kotlin-2.0.20-/JUnit-Abhängigkeiten; ein fehlendes JAR ist kein PASS.

Die vorhandenen 17 Regressionen sollen zusammen mit den zwölf neuen Fällen
laufen. Die Event-/Android-Grenze bleibt dabei ausdrücklich erhalten. Es ist
keine Datenmigration erforderlich. Ein Rückbau betrifft nur diesen isolierten
Drei-Dateien-Slice; keine vollständige ältere Repository-Dateisammlung über einen
inzwischen weiterentwickelten C1-Stand kopieren.

## Primärquellen

- [Memory-Handoff](https://github.com/Ullmann27/device-ai/blob/e83f6ac18243b42aadbe8da88df074c7ea1811ef/docs/evidence/three-repair-bots-round2-20261104/memory/HANDOFF.md)
- [Originaler RED-Lauf](https://github.com/Ullmann27/device-ai/blob/e83f6ac18243b42aadbe8da88df074c7ea1811ef/docs/evidence/three-repair-bots-round2-20261104/memory/host-red.log)
- [Originaler GREEN-Lauf](https://github.com/Ullmann27/device-ai/blob/e83f6ac18243b42aadbe8da88df074c7ea1811ef/docs/evidence/three-repair-bots-round2-20261104/memory/host-green-before-commit.log)
- [Übergeordnetes 17-Dateien-Manifest; 14 Sequence-Dateien hiervon zurückgestellt](https://github.com/Ullmann27/device-ai/blob/f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4/docs/evidence/finalization-18845-20261104/round2-505-manifest.json)
