# C1-AVATAR-009 — begrenztes Review- und Intakepaket

Status: **READY FOR SERIAL INTAKE; C1-LAUF AUSSTEHEND.** C1 ist Einbauer. Dieses Paket verändert keinen Checkout und führt keine App-, Kotlin-, Android-, Gradle- oder Modelltests aus. C2 extern bleibt PENDING; ein fremdes Team-ACK wird nicht behauptet.

## Feste Quellen und Umfang

- C1-Basis: `165fc9f58ae9e36295690df60145174fd5dc58e7`, Tree `4b3e47f30517cf952ab50c0a52b27bb96d281504`.
- Unveränderliches Ziel aus #517: `f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4`, Tree `e996a49cabf181e67156400f51df2a10c85e5a13`.
- Kombinierter Patch: `C1-AVATAR-009.patch`, SHA-256 `3b0fcaa1a9d093bc26aa7e02fb7b262fcfaf7351f2a616761f223e139e350289`.

Der Patch betrifft genau diese vier Pfade:

1. `app/src/main/java/at/heinz/deviceai/ContinuumHologramView.kt`
2. `app/src/uiTest/java/at/heinz/deviceai/ContinuumAvatar3dLifecycleUiTest.kt`
3. `app/src/uiTest/java/at/heinz/deviceai/ContinuumAvatarNativeUiTest.kt`
4. `app/src/uiTest/java/at/heinz/deviceai/ContinuumHologramMotionUiTest.kt`

Jeder Zielinhalt wurde mit `git show` aus dem festen Zielcommit gelesen und sein Git-Blob selbst nachgerechnet. `manifest.json` enthält Modi, volle Basis-/Zielblobs, SHA-256 und Bytezahlen. `base/` und `target/` enthalten ausschließlich die vier jeweiligen Quelldateien. Der Patch umfasst 141 eingefügte und 51 entfernte Zeilen; die einzige Produktionsdatei hat +3/-4.

Die vollständige Differenz von C1 zur festen Zielversion enthält sowohl den bisherigen pausierten VSync-Aufbau als auch die neue Traversal-Fixture. Es werden keine anderen Änderungen aus #505/#517 übernommen. Der Produktions-Fallback stammt bereits aus `f69cfef3230e7a5a8abcacef0103feb39e325a51`; der jüngste Fixture-Abschluss ist `f17ee62...`.

## Statisches Urteil

**Kein statischer Blocker im begrenzten Slice gefunden.**

Der Produktionszweig zeichnet den bestehenden 2D-Kopf auch dann, wenn ein angeforderter 3D-Pfad tatsächlich fehlgeschlagen ist. `!native3dDrawn` bleibt Voraussetzung. Der Initialisierungstext wird nur während noch ausstehender, nicht fehlgeschlagener 3D-Initialisierung angezeigt. Sonstige Auswahl-, Sichtbarkeits-, Foreground-, Thermal-, Reduced-Motion-, Ressourcen- und Callback-Grenzen werden durch den Patch nicht geändert.

Die drei UI-Klassen verwenden vollständig `@LooperMode(PAUSED)`, einen pausierten Choreographer und 16-ms-Frameabstände. Der neue Helfer schreitet in Schritten von höchstens 16 ms bis zur bisherigen Gesamtdauer fort. Die Fixtures hängen Views über echte Activity-Fenster und feste LayoutParams ein und prüfen anschließend Attachment, Sichtbarkeit, Window-Visibility und tatsächliche Breite/Höhe. Handgesetztes Measure/Layout wird dadurch nicht als Fenstersichtbarkeit ausgegeben.

Die Orb-Suite wählt den bestehenden Orb ausdrücklich mit `setNativeHeadEnabled(false)` und prüft diese Auswahl. Die native Kopf-Suite verlangt einen LIVE-Zustand vor ihren Pixelaufnahmen. Ihre acht PCM-Samples werden mit sieben realen 33-ms-Abständen eingespeist, passend zur von Director und View verwendeten Wanduhr; das ist ein begrenzter, aber weiterhin wanduhrabhängiger Testaufbau. Der Test verwendet synthetische TTS-Ereignisse und belegt keine Geräte-TTS- oder native Filament-Ausführung.

## Assertions und Anforderungen

Die 13 vorhandenen Testmethoden sind in Namen und Reihenfolge unverändert. Ein Multimengenvergleich der getrimmten ursprünglichen Assertion-Zeilen findet keine entfernte oder ersetzte Assertion-Zeile. Zusätzlich wurde die gesamte Vier-Dateien-Differenz statisch gelesen.

| Klasse | Testmethoden vorher/nachher | Assertion-Aufrufe vorher/nachher |
|---|---:|---:|
| ContinuumAvatar3dLifecycleUiTest | 4 / 4 | 36 / 44 |
| ContinuumAvatarNativeUiTest | 3 / 3 | 14 / 22 |
| ContinuumHologramMotionUiTest | 6 / 6 | 28 / 34 |
| Gesamt | 13 / 13 | 78 / 100 |

Die Zählung allein beweist keine Laufzeitkorrektheit. Die erhaltenen fachlichen Anforderungen umfassen 2D-Pixelgleichheit nach tatsächlichem 3D-Fehlerpfad, reduzierte Bewegung, Pause/Resume, keine doppelte Uhr, Gaze-Löschung und Ablehnung verspäteter Samples, sichtbare Mundöffnung, Schließen nach Unterbrechung sowie thermisches Stoppen und Wiederanlaufen. Einzelheiten und alle Methodennamen stehen in `assertion-review.json`.

## Gesicherte externe Evidenz

`evidence/red/` und `evidence/green/` enthalten unveränderte Kopien von Start-/Ergebnis-/Summary-Dateien, vollständigen Rohlogs, den JUnit-Archiven und den Quellmanifesten vor/nach dem Lauf. Die jeweils drei relevanten Avatar-XML-Dateien sind zusätzlich separat abgelegt. Sämtliche sechs XML-Inhalte jedes Archivs wurden gegen die Summary-Hashes und ihre Fall-/Fehlerzahlen geprüft. Die Quellmanifeste vor und nach jedem Lauf sind bytegleich.

| Externer Stand | Gezielter Gesamtlauf | Drei Avatar-Klassen | Exit |
|---|---:|---:|---:|
| 92f421fa81c57022d903e2c1ff45ae6279c77b22 | 46 PASS / 7 FAIL / 0 SKIP | 6 PASS / 7 FAIL | 1 |
| f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4 | 53 PASS / 0 FAIL / 0 SKIP | 13 PASS / 0 FAIL | 0 |

**Der RED-Stand 92f421 enthält bereits den Produktions-Fallback und den früheren VSync-Aufbau. Er ist weder ein RED auf C1 165fc9 noch ein isolierter Vorzustandsnachweis für die 2D-Produktionskorrektur.** Das 53/53-Ergebnis bleibt externe, quellengebundene Fokus-Evidenz; es wird nicht als C1-PASS gezählt.

Der separate vollständige Android-Lauf auf f17ee62 wurde am 2026-11-04 um 20:42:18 UTC mit **Exit 143** abgebrochen: `ContinuumReferenceCockpitUiTest#shortenedWideWindowKeepsEveryRailTargetScrollableAndClickable` überschritt 180 Sekunden. `evidence/full-gate-aborted/` hält dieses Ergebnis und das Thread-Dump-Log getrennt fest. Der Vollgate ist nicht grün; seine Diagnose wird durch dieses Paket nicht erledigt.

## Tatsächliche statische Prüfungen

Im eigenen `base/`:

```sh
git apply --check --whitespace=error-all ../C1-AVATAR-009.patch
```

Exit 0. Im eigenen `target/`:

```sh
git apply --reverse --check --whitespace=error-all ../C1-AVATAR-009.patch
```

Exit 0. `git apply --numstat C1-AVATAR-009.patch` nennt exakt die vier freigegebenen Pfade. Diese Befehle prüfen den Patch; sie wenden ihn nicht an. `static-validation.json` hält die konkreten Prüfungen fest. `SHA256SUMS` deckt alle Paketdateien außer sich selbst ab.

## Serieller Einbau und Rückbau

C1 beendet zunächst den laufenden Routing-Androidtest. Danach sind die vier tatsächlichen Basisdateien gegen die Basisblobs im Manifest abzugleichen; bei abweichenden Bytes ist ein erneuter Diff-Review nötig. Nach Einbau müssen die vier Ergebnisblobs den Zielblobs entsprechen. Der tatsächliche C1-Lauf der drei UI-Klassen und seine Quellen-/Ergebnisbindung stehen aus. Es gibt hier keinen vollständigen Android-, APK-, Geräte- oder C2-Abschluss.

Ein Rückbau betrifft ausschließlich diesen Vier-Dateien-Slice. Nach späteren Änderungen keine vollständige alte Produktionsdatei über aktuelle Arbeit kopieren; den begrenzten Rückwärtsdiff erneut prüfen.

