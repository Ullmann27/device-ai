# worker - future C1 acceptance, NOT_RUN
# Run from /workspace/scratch/174c84456ee3/continuum-c1 only after independent review, exact blob checks and committed clean source.
# Parent C1 is sole integrator; scripts are provided as commands, not executed by this intake.

# node
node --test --test-reporter=tap .github/continuum/development-backlog.test.mjs .github/continuum/backlog-cli.test.mjs .github/continuum/backlog-contract-cli.test.mjs .github/continuum/backlog-investigator.test.mjs .github/continuum/backlog-investigator-recovery.test.mjs .github/continuum/backlog-repair-worker.test.mjs .github/continuum/owner-contract-worker.test.mjs .github/continuum/autonomous-teamleader.test.mjs .github/continuum/local-teamleader-loop.test.mjs .github/continuum/coding-orchestrator-failure-report.test.mjs

# parity
node tools/completed-connections-822e-r2/worker/selection-parity.mjs
