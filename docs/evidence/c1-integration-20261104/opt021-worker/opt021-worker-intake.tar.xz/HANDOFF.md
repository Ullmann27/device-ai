# C1-OPT-021 — Worker

**PREPARED_NOT_RUN.** Drei Pfade: .github/continuum/development-backlog.mjs, .github/continuum/development-backlog.test.mjs und tools/completed-connections-822e-r2/worker/selection-parity.mjs. Alle Zielbytes entsprechen unverändert der getesteten #523-Quelle; Produktion und Testdatei entsprechen zugleich den behaltenen R1-Bytes aus #511. Die ersten beiden Basisblobs sind auf C1 d3487a8 identisch mit der getesteten fremden Basis.

## Produktionsentscheidung und gültiger Vertrag

Nur nextEligible ändert sich: Es hält die bisher beste geeignete Aufgabe statt sämtliche geeigneten Aufgaben zusätzlich zu sammeln und zu sortieren. Die Vergleichsrichtung ist dieselbe wie beim bestehenden Sortierkomparator: höhere Priorität, früherer createdAt-Wert, dann lexikographisch kleinere ID. Der Rückgabewert bleibt das originale Aufgabenobjekt.

Die vorhandene kanonische Dokumentvalidierung erzwingt Priorität 0..1000, sichere nichtnegative Zeitstempel und eindeutige sortierte IDs. BacklogStore.read läuft über die vorhandene Decoder-/Validierungskette. Für diesen gültigen Datenvertrag ist der Vergleich transitiv und die Auswahl stimmt statisch überein. Beliebige manipulierende JavaScript-Getter, lückenhafte Arrays oder ungültige Fremdobjekte werden nicht zu einem neuen unterstützten Eingabevertrag erklärt.

Eligibility, short circuit order der optionalen Filter, Taskzustände, Wiederholungsbudgets, Abhängigkeiten, Operations-/HEAD-Scope, claim/claimNext, Token, Evidenzübergänge, Dateispeicherung und Lockregeln sind vollständig unverändert. Insbesondere claimNext besitzt weiterhin seinen bestehenden separaten Sortierpfad. Diese Optimierung ist daher keine Aussage über sämtliche Worker-Operationen.

Die tatsächlichen vorhandenen Callers wurden gelesen: autonomous-teamleader, backlog-repair-worker, owner-contract-worker, backlog-investigator und owner-kotlin-preview; teamleader-cli und local-teamleader-loop bleiben angeschlossen. Keine neue Scheduling- oder Ausführungsberechtigung entsteht.

## Eingefrorene Tests und Abnahme

Die bestehende Testdatei wird ausschließlich um vier Tests und ihren Fixturehelper ergänzt; keine alte Zeile oder Assertion wird entfernt. Die vollständige fertige Testdatei ist bytegleich mit #511/#523. Die Fälle prüfen Priorität/Zeit/ID/Object identity, alle optionalen Filter und leere Filter, Eligibility vor Filterzugriffen sowie Freigabe abhängiger Aufgaben erst nach passender echter Completion-Evidenz.

Der zusätzlich importierte Testharness ist bytegleich mit #523 und arbeitet ausschließlich mit synthetischen tief eingefrorenen Dokumenten. Er importiert den realen Selektor, lädt die unveränderte Referenz aus Git-Blob 64f798d5cf86ec7b541bd5135972f30fef1be746 und prüft 40.960 exakte Objektidentitätsentscheidungen plus Nichtmutation. Er enthält keine Benchmarks und startet keinen laufenden Owner-Worker.

acceptance-commands.sh enthält exakt die zehn geprüften Suitepfade und den separaten Paritätsaufruf. Der historische Node-Lauf bestand mit 121 Fällen; diese Quell-/Testdateien entsprechen weiterhin C1 plus Patch. Dennoch muss C1 seine eigene neue Ausgabe, Exitcodes, exakte Quellidentität und alle Null-Fehler-/Null-Skip-Zähler erfassen. Der Paritätslauf muss sowohl die eingefrorenen Basis-/Zielhashes als auch den unveränderten Harnesshash ausgeben. Git-Referenzblob muss vorhanden sein; keine externe Bibliothek oder Netzwerkverbindung wird benötigt.

## Grenzen und Stopregeln

Anhalten bei abweichender Dokumentvalidierung, veränderter Filter-/Comparatorsemantik, anderem Ziel-/Baselineblob, Nichtmutation-/Identitätsfehlern oder nicht passenden Completion-Evidenztests. Kein live Backlog, keine Ownerdaten, keine Kernelreparaturausführung und keine zusätzliche Authority. Die Arbeit spart das Kandidatensortieren; Eligibility und deren Abhängigkeitssuche bleiben gleich. Es liegt kein neuer Nachweis für Gesamtdurchsatz oder Geräteleistung vor.

