from __future__ import annotations
import collections, datetime, hashlib, json, pathlib, re, shutil, subprocess, sys, tarfile
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/workspace/scratch/174c84456ee3/continuum-c1')
QA = ROOT.parent / 'qa'
label, destination, remote, expected_file = sys.argv[1:]
assert pathlib.Path(label).name == label and pathlib.Path(destination).name == destination
assert re.fullmatch(r'[a-f0-9]{40}', remote)
expected = json.loads(pathlib.Path(expected_file).read_text())
record = json.loads((QA / (label + '.result.json')).read_text())
assert record['status'] in ('PASS', 'FAIL') and record['sourceUnchanged'] is True
assert record['source']['commit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
start = datetime.datetime.fromisoformat(record['startedAt']).timestamp()
end = datetime.datetime.fromisoformat(record['finishedAt']).timestamp()
stage = QA / (label + '-archive-stage')
stage.mkdir()
(stage / 'junit').mkdir()
seen, cases = {}, []
for path in sorted((ROOT / 'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml')):
    assert path.is_file() and not path.is_symlink()
    assert start - 1 <= path.stat().st_mtime <= end + 1
    suite = ET.parse(path).getroot()
    name = suite.attrib['name']
    tests = suite.findall('testcase')
    assert name in expected and len(tests) == expected[name] and name not in seen
    seen[name] = len(tests)
    shutil.copy2(path, stage / 'junit' / path.name)
    for test in tests:
        failures = test.findall('failure') + test.findall('error')
        cases.append({'class': name, 'name': test.attrib['name'],
                      'status': 'FAIL' if failures else 'SKIP' if test.findall('skipped') else 'PASS',
                      'failure': failures[0].attrib if failures else None})
assert seen == expected
log = (QA / (label + '.log')).read_text()
identities = collections.Counter(c['class'] + '#' + c['name'] for c in cases)
starts = collections.Counter(re.findall(r'^AUDIT_TEST_START (.+)$', log, re.M))
ends = collections.Counter(re.findall(r'^AUDIT_TEST_END (.+) (?:SUCCESS|FAILURE|SKIPPED)$', log, re.M))
assert starts == identities and ends == identities
counts = {'total': len(cases), 'passed': sum(c['status'] == 'PASS' for c in cases),
          'failed': sum(c['status'] == 'FAIL' for c in cases), 'skipped': sum(c['status'] == 'SKIP' for c in cases)}
assert not (record['exitCode'] == 0 and counts['failed'])
for name in [label + '.result.json', label + '.log', label + '-active-test.json',
             'run_c1_gate_v3.py', 'observe-tests.init.gradle', 'archive_android_gate.py']:
    shutil.copy2(QA / name, stage / name)
assert hashlib.sha256((stage / 'run_c1_gate_v3.py').read_bytes()).hexdigest() == record['runnerSha256']
summary = {'taskId': label, 'localSource': record['source']['commit'], 'remoteSource': remote,
           'tree': record['source']['tree'], 'command': record['command'],
           'startedAt': record['startedAt'], 'finishedAt': record['finishedAt'],
           'exitCode': record['exitCode'], 'sourceUnchanged': True, 'counts': counts,
           'suites': seen, 'cases': cases, 'caseStartEndIdentitiesMatch': True,
           'scope': 'ACTUAL_ANDROID_PROJECT_FOCUSED_JVM_OR_ROBOLECTRIC_CLASSES',
           'limits': ['Not a full Android or lint gate', 'No model, native GPU, physical device or APK acceptance',
                      'Overlapping prior and future test groups must not be added']}
(stage / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
output = ROOT / 'docs/evidence/c1-integration-20261104' / destination
output.mkdir()
archive = output / (label + '.tar.xz')
with tarfile.open(archive, 'w:xz') as tar:
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            tar.add(path, arcname=path.relative_to(stage), recursive=False)
summary['archive'] = {'name': archive.name, 'bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'members': [{'path': str(p.relative_to(stage)), 'bytes': p.stat().st_size,
                                   'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                                  for p in sorted(stage.rglob('*')) if p.is_file()]}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'sha256': summary['archive']['sha256'],
                  'source': summary['localSource'], 'counts': counts, 'exitCode': record['exitCode']}))
