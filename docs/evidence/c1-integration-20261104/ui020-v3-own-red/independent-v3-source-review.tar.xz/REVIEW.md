# C1-UI-020 Fixture V3 — unabhängiger Abschlussreview

## Ergebnis: statisch für den neuen RED geeignet

Der eingefrorene V3 behebt den materiellen V2-Abdeckungsfehler: **Der originale Robolectric-4.14.1-controller.recreate()-Ablauf bleibt erhalten**, einschließlich changingConfigurations=true, realem Destroy, neuer Activity und Weitergabe der NonConfigurationInstances. Die neue Fixture ergänzt ausschließlich einen begrenzten asynchronen Framepuls, damit der echte Window-Traversal vor dem ursprünglichen Fokusaufruf stattfinden kann. Kein neuer materieller Quellblocker wurde im begrenzten V3 gefunden. Dies ist kein Runtime-PASS.

| Identität | Wert |
| --- | --- |
| Testpfad | app/src/uiTest/java/at/heinz/deviceai/ContinuumReferenceCockpitUiTest.kt |
| Basisblob | 315f42d32518f0c8de4a73cb46c349bd8dbb04d6 |
| Zielblob | 5059be0cd5f3d4e850eaac6d08faca357e1429fd |
| Ziel-SHA256 | 96962b9d98ffd5590196ef16c4c2be8f7e530925b6d603b18dd8efe297f27d2d |
| Patch-SHA256 | aa9433cd051d077eac9371f4f75d7c966b88b1dc0125cd22abd5f646fe92709c |
| Patchumfang | Eine Testdatei, sieben Hunks, 7.078 Bytes, Dateimodus 100644 |
| Aktuelle C1-Bindung | 5fec06d587dcceded3d066bf3eeded888255fd2f, Tree 0b31bb65445866f0bd0844ee84bdfb4a00a649d0 |

Die Basis wurde auf f31855138d77ecb5e05e7a17a620b1fd6e9d28c5 und 6f7ca725261eb4df502ee868e94babc4e12afc15 unabhängig gelesen. Alle Hunks wurden im Speicher rekonstruiert. Auch die nun integrierte Testdatei auf 5fec06d stimmt vollständig mit dem geprüften Ziel überein. Die Remote-Zuordnung 08370482c609537b5b8d0d8370d2b4a933d4e35d stammt ausdrücklich aus Roots Mitteilung.

## Assertions und Recreate-Anforderungen erhalten

Alle acht Testmethoden und ihre Profilkonfigurationen bleiben identisch. Sämtliche 125 ursprünglichen primitiven JUnit-Assertionausdrücke sind unverändert enthalten; zwölf zusätzliche Assertions erhöhen den Zähler auf 137. Es ist hier keine Controller-Umbenennungsnormalisierung nötig. Die umfassendere lexikalische Zählung aller assert-präfigierten Aufrufe einschließlich Helper beträgt 151 → 163. Beides sind Quellzählungen, keine Testläufe.

Die neuen Assertions verlangen: nur eine Planung, erfolgreicher Post, genau einen ausgeführten Puls, tatsächliche neue Activity, reale Decor-Parent-Verbindung vor dem Puls und danach changingConfigurations, zerstörte alte Activity, andere Instanz, tatsächliche Decor-Anbindung sowie echten Fensterfokus. Fehlende oder doppelte Pulse führen zu einem Fehler.

Die Funktionen withActivity, assertMinimumTarget, assertRealTargets, assertRailGeometry und checkProfile bleiben bytegleich. Scrollen und realer DOWN/UP-Dispatch bleiben nach der Diagnose-Labelwahl unverändert. Es gibt kein neues Ignore, keine Assumption und kein performClick. Nach exaktem Rücknehmen nur der erklärten Importe, des neuen Helpers, seiner beiden Callers, der Labelkorrektur und der Decor-Messung ist **die gesamte Datei wieder bytegleich zur eingefrorenen Basis**. Dadurch sind auch die restlichen funktionalen Assertions, Reflow-/Entwurfserwartungen und 48-dp-/Überlappungsanforderungen erhalten.

## Öffentliche API- und Bytecodekette

Der Callback ist auf activity !== previous und activity === controller.get() beschränkt. Nur die tatsächlich neu resumierte Activity darf genau einen Runnable über Handler.createAsync(mainLooper) posten. SDK-28-Signaturen sowie Klassenhashes für Application, ActivityLifecycleCallbacks und Handler wurden unabhängig mit dem vorhandenen SDK-JAR abgeglichen.

ComponentController.invokeWhilePaused verwendet im PAUSED-Modus runPaused, ohne die Queue zu leeren. Die gelesenen resume-/postResume-Methoden fügen ebenfalls keinen Drain hinzu. Der nächste Controller-visible-Aufruf macht das Decor zuerst sichtbar und leert danach die Queue. Der asynchrone Puls kann daher die neu gesetzte Traversal-Sync-Barriere passieren.

Vor dem Clock-Schritt wird der Pulszähler gesetzt. Einmal ShadowSystemClock.advanceBy(16 ms) löst die vorhandenen Clock-Listener aus; der gelesene SDK-28-FrameDisplayEventReceiver stellt dabei die echte asynchrone VSync-Message ein. Der äußere visible-Drain dispatcht anschließend diesen Frame. Der Helper ruft weder idle noch idleFor verschachtelt auf und entpausiert Choreographer nicht. Er erzeugt keinen Ersatzcontroller und setzt keine privaten Lifecycle-Flags künstlich.

V3 verwendet **keinen IdleHandler**. Der zuvor dokumentierte IdleHandler-Triggergap betrifft nur den verworfenen Vorentwurf in FRAMEWORK-PRELIMINARY.md.

## Cleanup und begrenzte Restunsicherheit

Der neue Application-Callback wird im finally entfernt; ein verschachteltes finally entfernt den Runnable auch dann, wenn das Unregister fehlschlagen würde. Neue Bridgefehler werden nicht verschluckt. Der vorhandene äußere withActivity-Cleanup bleibt unverändert und enthält weiterhin die ursprünglichen runCatching-Aufrufe für Pause/Stop/Destroy. V3 übernimmt somit nicht die zusätzliche Cleanup-Verschärfung aus dem blockierten V2; die alte Grenze bleibt ausdrücklich sichtbar und ist keine neue Assertion-Abschwächung.

Der nullsichere Label-Fallback verändert nur die Diagnose. Die zusätzliche Messung vor dem Home-Rücktap verwendet die aktuellen Decor-Abmessungen und erhält die tatsächlichen Ziel-/Klickprüfungen. Sie ersetzt keine Produktgeometrie durch künstliche Controlgrößen.

Die Timingkette ist statisch durch die vorhandenen Frameworkklassen begründet. Ob der vollständige aktuelle Hostlauf alle Frames rechtzeitig ausführt und die acht ursprünglichen Produktanforderungen erfüllt, muss der neue C1-RED/GREEN zeigen. Die Ergebnisse des älteren V1 dürfen nicht übertragen werden. Geräte-, GPU-, IME- und echter Prozessneustart sind nicht durch diesen Host-Fixturecheck abgenommen.

## Belege

C1-UI-020-fixture-v3-independent-review.json enthält den vollständigen Befund. assertion-integrity.json belegt alle Assertion-/Methoden-/Dateigleichheiten. integration-binding.json bindet die aktuell integrierte Testquelle. frozen/ enthält den unveränderten Vorschlag und dessen Herkunft; framework/ enthält eigene statische Disassemblierungen mit Klassen-/Ausgabehashes. SHA256SUMS.json bindet das gesamte Reviewpaket.

**Keine Tests, Builds, Modelle, Locks oder Repositoryänderungen durch diesen Reviewer.** Ausschließlich statische Dateianalyse und javap-Metadatenlesung vorhandener Frameworkklassen. V2 bleibt blockiert; V3 ist für frische Laufabnahme geeignet. Kein externer C2-ACK.

