# UI020 Fixture V3 — enger Frameworkvorbefund

Dieser Vorbefund prüft die von repair_review vorgeschlagene Timing-Brücke vor Vorlage eines V3-Patches. Er ist keine Patchfreigabe und kein Laufbeleg. Alle Aussagen stammen aus statischer Disassemblierung des bereits vorhandenen Robolectric-4.14.1-JARs bzw. des SDK-28-JARs; die gelesenen Klassen und Toolausgaben sind unter framework/ mit SHA256-Provenienz gesichert. Kein Projektcode, Test oder Build wurde ausgeführt.

## Recreate-Semantik muss erhalten bleiben

Das vorhandene ActivityController.recreate setzt changingConfigurations=true, ruft die originalen Pause-/Stop-/Save-/Destroy-Schritte auf, erhält NonConfigurationInstances und übergibt diese beim Attach der neuen Activity. V2 verliert diese beiden Eigenschaften, obwohl AgentActivity davon Retention und Modellfreigabe abhängig macht. Eine Timing-Brücke darf deshalb weder die Destroy-/Neuinstanzfolge ersetzen noch die relevanten Flags oder NonConfig-Daten künstlich umgehen.

## IdleHandler ist nur bedingt ein Trigger

ShadowPausedLooper.idleIfPaused ruft bei pausiertem Looper idle auf; idle führt IdlingRunnable aus. Dessen Schleife liest eine aktuell ausführbare Message, dispatcht sie, recycelt sie und ruft erst danach triggerIdleHandlersIfNeeded auf. Dieser Trigger prüft ausdrücklich lastMessageRead != null sowie die nun leere/nicht fällige Queue. Ist bereits beim Einstieg keine ausführbare Nachricht vorhanden, beendet die Schleife sich sofort, ohne IdleHandler-Aufruf.

Eine bloße IdleHandler-Registrierung garantiert deshalb im leeren bzw. nur künftig fälligen Fall keinen einzigen Callback. Das ist eine belegte Zuverlässigkeitsgrenze, nicht ein bereits ausgeführter Negativtest. Ein künftiger V3 muss einen geeigneten Trigger belegen oder eine andere gesicherte öffentliche Lösung verwenden. Eine einmalige asynchrone Nachricht für die tatsächlich neue, resumierte Activity könnte dafür als explizite Brücke dienen; dieser Vorschlag ist bis zur konkreten Quellprüfung unbewertet.

## Einmaliger Clock-Schritt und Reentranz

triggerIdleHandlersIfNeeded kopiert die Liste unter dem Queue-Monitor, ruft die Handler aber außerhalb des Monitors auf. false entfernt einen Handler nach dem Callback. Bei eigener Entfernung bzw. Finally-Cleanup ist auch der Fehlerpfad zu beachten.

ShadowSystemClock.advanceBy ändert die virtuelle Clock und informiert deren Listener. NativeDisplayEventReceiver.onClockAdvanced prüft den fälligen VSync und löst onVsync aus. Der echte SDK-28-FrameDisplayEventReceiver stellt dabei eine asynchrone Message in die Queue; erst deren run ruft Choreographer.doFrame auf. Ein einmaliger guarded Clock-Schritt kann deshalb die bereits laufende äußere Drainphase den echten Traversal ausführen lassen, ohne im Callback selbst einen verschachtelten idle-/idleFor-Aufruf zu benötigen.

Der Guard muss vor dem Clock-Schritt gesetzt sein und die Brücke auf die neue Activity begrenzen. Choreographer muss pausiert bleiben, damit die Animation der neuen Activity nicht automatisch unbeschränkt Frames erzeugt. Ein globaler bzw. wiederholter Clock-Pump wäre eine andere Fixture und ist hier nicht geprüft. Registrierungen und etwaige ausstehende Hilfsnachrichten müssen auf Erfolg wie Fehler wieder entfernt werden.

## Offene Abnahme

Noch kein V3-Patch liegt diesem Vorbefund zugrunde. Nicht belegt sind die tatsächliche Ausführung des Triggers, erfolgreiche Decor-Anbindung vor Focus und Runtime-Verhalten der vollständigen acht Fälle. Zusätzliche robuste Assertions sollen tatsächliches Destroy, andere Activity-Instanz, changingConfigurations und reale Anbindung bewahren; die bestehenden funktionalen Assertions bleiben unverändert. Der bisherige V1-RED ist kein V3-Ergebnis.

