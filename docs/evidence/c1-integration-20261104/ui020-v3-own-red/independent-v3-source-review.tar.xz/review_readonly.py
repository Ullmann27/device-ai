#!/usr/bin/env python3
"""Independent static fixture V3 review; no project tests/builds."""
from pathlib import Path
import ast, collections, hashlib, json, re, subprocess, zipfile
ROOT=Path('/workspace/scratch/174c84456ee3');REPO=ROOT/'continuum-c1'
SRC=ROOT/'repair-review/ui020-fixture-v3';OUT=ROOT/'source-audit/ui020-fixture-v3'
OUT.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def meta(b):return {'blob':blob(b),'sha256':sha(b),'bytes':len(b)}
def save(name,b):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def savejson(name,obj):save(name,json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
m=json.loads((SRC/'FIXTURE-V3.json').read_text())
base=(SRC/'base-ContinuumReferenceCockpitUiTest.kt').read_bytes()
target=(SRC/'target-ContinuumReferenceCockpitUiTest.kt').read_bytes()
patch=(SRC/'C1-UI-020-fixture-v3.patch').read_bytes()
assert sha(patch)==m['patchSha256']=='aa9433cd051d077eac9371f4f75d7c966b88b1dc0125cd22abd5f646fe92709c'
assert len(patch)==m['patchBytes']
assert blob(base)==m['baseBlob']=='315f42d32518f0c8de4a73cb46c349bd8dbb04d6'
assert sha(base)==m['baseSha256']
assert blob(target)==m['targetBlob']=='5059be0cd5f3d4e850eaac6d08faca357e1429fd'
assert sha(target)==m['targetSha256']
refs=[m['baseCommit'],'6f7ca725261eb4df502ee868e94babc4e12afc15']
for ref in refs:
 assert subprocess.check_output(['git','-C',str(REPO),'show',ref+':'+m['path']])==base
mode=subprocess.check_output(['git','-C',str(REPO),'ls-tree',m['baseCommit'],'--',m['path']]).decode().split()[0]
assert mode=='100644'
lines=patch.decode().splitlines(True);old=base.decode().splitlines(True)
assert sum(x.startswith('diff --git ') for x in lines)==1
assert lines[0].rstrip()==f"diff --git a/{m['path']} b/{m['path']}"
i=0;cursor=0;out=[];hunks=[]
while not lines[i].startswith('@@ '):i+=1
while i<len(lines):
 x=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n',lines[i]);assert x
 start=int(x[1])-1;oc=int(x[2] or 1);nc=int(x[4] or 1);assert start>=cursor
 out+=old[cursor:start];cursor=start;assert len(out)==int(x[3])-1
 i+=1;ro=rn=0
 while i<len(lines) and not lines[i].startswith('@@ '):
  p=lines[i][0];v=lines[i][1:];assert p in ' +-'
  if p in ' -':assert old[cursor]==v;cursor+=1;ro+=1
  if p in ' +':out.append(v);rn+=1
  i+=1
 assert (ro,rn)==(oc,nc)
 hunks.append({'old_start':start+1,'old_count':oc,'new_start':int(x[3]),'new_count':nc})
out+=old[cursor:];assert ''.join(out).encode()==target
tree=ast.parse((ROOT/'source-audit/ui020/review_readonly.py').read_text())
fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('mask_kotlin','endbalanced','inspect_class')]
env={'re':re};exec(compile(ast.Module(body=fns,type_ignores=[]),'<own-static-kotlin-lexer>','exec'),env)
mask=env['mask_kotlin'];inspect=env['inspect_class'];balanced=env['endbalanced']
b=base.decode();t=target.decode()
bm,ba,bh=inspect(b,'ContinuumReferenceCockpitUiTest')
tm,ta,th=inspect(t,'ContinuumReferenceCockpitUiTest')
assert bm==tm==[x['name'] for x in m['methods']] and len(tm)==8 and bh==th
profile_re=r'@Test\s+@Config\(qualifiers = "([^"]+)"\)\s+fun\s+([A-Za-z_]\w*)'
profiles_before=re.findall(profile_re,b);profiles_after=re.findall(profile_re,t)
assert profiles_before==profiles_after and len(profiles_after)==8
pn={'assertEquals','assertFalse','assertNotNull','assertSame','assertTrue'}
def primitive(calls):return [re.sub(r'\s+',' ',x).strip() for x in calls if re.match(r'\w+',x)[0] in pn]
bp=primitive(ba);tp=primitive(ta)
removed=list((collections.Counter(bp)-collections.Counter(tp)).elements())
added=list((collections.Counter(tp)-collections.Counter(bp)).elements())
assert not removed and len(bp)==125 and len(tp)==137 and len(added)==12
def fn(s,name):
 p=s.index('    private fun '+name+'(');masked=mask(s);o=masked.index('{',p);e=balanced(masked,o,'{','}')
 return s[p:e]
helper=fn(t,'recreateWithBoundedTraversal')
assert helper.count('controller.recreate()')==1
assert helper.count('ShadowSystemClock.advanceBy(Duration.ofMillis(16))')==1
assert 'activity !== previous && activity === controller.get()' in helper
assert helper.index('pulses = 1')<helper.index('ShadowSystemClock.advanceBy')
assert helper.index('pulseScheduled = true')<helper.index('handler.post(traversalPulse)')
assert 'Handler.createAsync(Looper.getMainLooper())' in helper
for absent in ('runCatching','IdleHandler','idle(','idleFor(','setPaused(','buildActivity(','.create(','ReflectionHelpers'):
 assert absent not in mask(helper),absent
for req in ('previous.isChangingConfigurations','previous.isDestroyed','controller.get() !== previous',
            'controller.get().window.decorView.isAttachedToWindow','controller.get().hasWindowFocus()',
            'application.unregisterActivityLifecycleCallbacks(callbacks)','handler.removeCallbacks(traversalPulse)'):
 assert req in helper
assert fn(b,'withActivity')==fn(t,'withActivity')
for name in ('assertMinimumTarget','assertRealTargets','assertRailGeometry','checkProfile'):
 assert fn(b,name)==fn(t,name)
bs=fn(b,'tap');ts=fn(t,'tap')
assert bs[bs.index('        var parent = target.parent'):]==ts[ts.index('        var parent = target.parent'):]
# Remove precisely the bounded fixture changes; the entire remainder must
# reproduce the frozen original file, including both functional test bodies.
normalized=t.replace(helper+'\n\n','',1)
for imp in ('android.app.Activity','android.app.Application','android.os.Bundle','android.os.Handler',
            'org.robolectric.android.controller.ActivityController','org.robolectric.shadows.ShadowSystemClock'):
 assert normalized.count('import '+imp+'\n')==1
 normalized=normalized.replace('import '+imp+'\n','',1)
assert normalized.count('recreateWithBoundedTraversal(controller)')==2
normalized=normalized.replace('recreateWithBoundedTraversal(controller)','controller.recreate()')
measure_add='''        // Size the newly visible native chat rail in this manually sized window.
        val width = root.width
        val height = root.height
        measure(root, width, height)
        settle()
        measure(root, width, height)
'''
assert normalized.count(measure_add)==1
normalized=normalized.replace(measure_add,'',1)
label_add='''        val label = target.contentDescription?.toString() ?: target.tag?.toString()
            ?: (target as? TextView)?.text?.toString() ?: target.javaClass.simpleName
        assertMinimumTarget(target, label)'''
label_old='''        assertMinimumTarget(target, target.contentDescription?.toString() ?: target.tag.toString())'''
assert normalized.count(label_add)==1
normalized=normalized.replace(label_add,label_old,1)
assert normalized==b
for absent in ('@Ignore','performClick('):assert absent not in mask(t)
assert not re.search(r'\bassume\w*\s*\(',mask(t))
p=json.loads((SRC/'SDK28-callback-handler-provenance.json').read_text())
sdkclasses=[]
with zipfile.ZipFile(p['jar']) as z:
 for c,expected in p['classSha256'].items():
  cb=z.read(c.replace('.','/')+'.class');assert sha(cb)==expected
  sdkclasses.append({'class':c,'class_sha256':sha(cb),'bytes':len(cb)})
assert sha((SRC/'SDK28-callback-handler-api.txt').read_bytes())==p['apiTextSha256']
cp=json.loads((SRC/'controller-provenance.json').read_text())
assert sha(Path(cp['jar']).read_bytes())==cp['jarSha256']
with zipfile.ZipFile(cp['jar']) as z:
 assert sha(z.read(cp['class']))==cp['classSha256']
assert sha((SRC/'ActivityController-4.14.1.javap.txt').read_bytes())==cp['javapSha256']
for f in sorted(SRC.rglob('*')):
 if f.is_file():save('frozen/'+str(f.relative_to(SRC)),f.read_bytes())
save('fixture-helper.kt.txt',helper+'\n')
savejson('assertion-integrity.json',{'kind':'STATIC_SOURCE_COMPARISON_ONLY','methods':tm,'profiles':profiles_after,
 'primitive_junit_assertions_before':len(bp),'primitive_junit_assertions_after':len(tp),
 'removed_original_primitive_assertions':removed,'added_primitive_assertions':added,
 'all_assert_prefixed_before':len(ba),'all_assert_prefixed_after':len(ta),
 'unchanged_helpers':['withActivity','assertMinimumTarget','assertRealTargets','assertRailGeometry','checkProfile'],
 'tap_dispatch_and_scroll_byte_identical_after_label':True,'whole_file_exact_after_reversing_only_declared_fixture_changes':True,
 'normalized_full_file_sha256':sha(normalized.encode())})
savejson('C1-UI-020-fixture-v3-independent-review.json',{
 'task':'C1-UI-020-FIXTURE-V3-REVIEW','verdict':'STATIC_REVIEW_ACCEPTABLE_FOR_FRESH_RED_NOT_RUNTIME_PASS',
 'base_refs_with_identical_test_blob':refs,'path':m['path'],'mode':mode,'base':meta(base),'target':meta(target),'patch':meta(patch),
 'hunks':hunks,'hunk_reconstruction_matches':True,
 'original_assertions_preserved':True,'primitive_assertions':[len(bp),len(tp)],'methods':tm,'profiles':profiles_after,
 'whole_file_reversal_recovers_frozen_base':True,
 'lifecycle':{'original_controller_recreate_preserved':True,'manual_replacement_controller':False,
  'configuration_change_and_nonconfig_flow':'Preserved through unchanged Robolectric 4.14.1 recreate implementation; prior SDK28 source/bytecode read',
  'additional_assertions':['changingConfigurations on old Activity','old isDestroyed','new instance','real new decor attachment','real window focus'],
  'sdk28_callback_and_handler_class_hashes':sdkclasses},
 'pulse':{'callback_identity_guard':'activity !== previous && activity === controller.get()','maximum_scheduled':1,'maximum_executed':1,
  'clock_advance_ms':16,'guard_set_before_advance':True,'asynchronous_handler':True,'nested_idle':False,'unpause':False,
  'idle_handler':False,'pre_pulse_real_decor_parent_assertion':True,'fail_closed_on_missing_or_duplicate_pulse':True,
  'mechanism':'Public lifecycle callback schedules async pulse. Controller paused resume/postResume do not drain. visible makes decor visible before drain. Clock listener posts genuine async SDK28 VSync; same outer drain executes frame before original focus.'},
 'cleanup':{'new_callback_unregistered_in_finally':True,'new_runnable_removed_even_if_unregister_throws':True,
  'new_bridge_errors_not_swallowed':True,'inherited_withActivity_byte_identical':True,
  'inherited_cleanup_limit':'Original runCatching pause/stop/destroy remains; V3 does not introduce the stricter V2 cleanup. This is an existing fixture limitation, not weakened assertions.'},
 'other_changes':['null-safe diagnostic label only','real current decor remeasurement before home return lookup/tap'],
 'source_execution':'NOT_RUN','tests':'NOT_RUN','builds':'NOT_RUN','repository_changes':'NONE','locks':'NOT_ACQUIRED',
 'static_disassembly':'JDK javap reads existing framework class metadata only; no project class initialization',
 'limitations':['Runtime delivery/attachment and eight complete cases still require actual C1 RED/GREEN','Host SDK28 coverage only; no device/GPU/real-process-death claim','V2 remains blocked and is not a prerequisite','Framework preliminary IdleHandler note is historical; final V3 uses no IdleHandler'],
 'external_C2_ACK':'NOT_CLAIMED'})
print(json.dumps({'verdict':'STATIC_REVIEW_ACCEPTABLE_FOR_FRESH_RED_NOT_RUNTIME_PASS','patch_sha256':sha(patch),'target_blob':blob(target),
 'methods':len(tm),'primitive_assertions':[len(bp),len(tp)],'all_assert_prefixed':[len(ba),len(ta)],'removed':removed,
 'whole_file_reversal_recovers_base':True,'sdk28_api_hashes_match':True,'hunks':len(hunks)},indent=2))

