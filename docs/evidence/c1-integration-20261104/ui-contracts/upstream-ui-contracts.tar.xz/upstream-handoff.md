# Unabhängiger Integrationsreview – Fertigstellungsbot 2

## Ergebnis und Bezugsstand

Im nachstehend abgegrenzten Reviewumfang kein offener Integrationsblocker gefunden. Die Patches sind für Roots koordinierte Übernahme nach Freigabe des Diagnosefreeze bereit. Dies ist keine APK-, Geräte-, Signatur-, Release- oder Gesamtfreigabe.

Gemeinsam eingefrorene Quelle: Commit `20f888660a967aa1d6b5446e892540538372d319`, Tree `ce1baced5aa5fa1c9c6648ef5dae84c831f806d3`. Diese Quelle blieb bei meinen Prüfungen unverändert; zuletzt waren Git-Status leer sowie Commit/Tree exakt identisch. Eigene Laufzeitproben verwendeten nur getrennte kleine Quellsnapshots. Temporäre Produktionsmutationen/Overlays wurden jeweils bytegleich restauriert.

Die aus verschiedenen Quellen kommenden Patches sind unabhängig voneinander zuzuordnen. Der endgültige kombinierte SHA benötigt seinen eigenen vollständigen Testlauf; frühere Einzelresultate werden nicht rückwirkend dazu umbenannt.

## Übernahmeobjekte

| Umfang | Patch | SHA-256 |
|---|---|---|
| UI/Fold/Layout: neun Tests | `integration-audit/ui-contracts/ui-source-contracts.patch` | `c78066e2a6f0b3f1ff42add03eabcb26361ad10f33e1e49352d44bba8da49b50` |
| Root Cockpit/Avatar, finale Wave2 | `contract-review/root-source-contracts-wave2.patch` | `faa6a58df4e3eb994faa97027e9fa213e88e7d54a21c5199a31a450b3c23ce9b` |
| ECHO, exakt vier Dateien | `integration-audit/echo515-four-file.patch` | `ab432d4782be02820ca40cb38dc5b9ae1a7b9610986b31b2c6e2be7bbaa599d2` |
| AvatarIdleMotion, negative Null | `host-qa/idle-motion-boundary/idle-motion-boundary.patch` | `f689bb8cd5ffd999a16a2f15d97e2726bf6fc9b794a6e5cc527dca1a8932bb1d` |
| Bot- und Owner-Integration | `regression-audit/android-integration-wiring.patch` | `c28b5a1f8abfebdb00ae4b78ad9697524e665f1ad9a0ebe48c0886901aa5206d` |
| Trace/Kontext/Sprache | `regression-audit/trace-context-speech-contracts.patch` | `82c072f71e0e9573ee1d73754dfd673de5cac0a80094976e993dc5cf7161fee8` |
| Lernanzeige | `regression-audit/learning-readout-contract.patch` | `e5bec01122954298bdba1dcae9737db0849699d96ccc0e8047c7f86a4927e764` |
| QA-Signing-Ausschluss | `regression-audit/qa-signing-exclusion.patch` | `d0872ef956695a6009cb4e42f6e76f5b0c3079a78e76c85414e27440d86bc9d1` |
| Memory-Fixtures | `regression-audit/tool-memory-fixtures.patch` | `ed1be3b648287cd46b571a1153e7ffb18b2f33f159c3c0d7ab8d593a2e83a065` |

## UI/Fold/Layout: behobene veraltete Quellverträge

Genau neun Testdateien geändert; keine Produktionsdatei geändert, alle 48 Testfälle erhalten:

- `.github/continuum/app-navigation-wiring.test.mjs`
- `.github/continuum/android-holographic-home.test.mjs`
- `.github/continuum/fold-responsive-reflow.test.mjs`
- `.github/continuum/fold7-portrait-reference.test.mjs`
- `.github/continuum/continuum-fold7-hologram-live-diagnostics.test.mjs`
- `.github/continuum/mobile-builder-existing-integration.test.mjs`
- `.github/continuum/nexus-beginner-ui.test.mjs`
- `.github/continuum/premium-phone-viewport-wiring.test.mjs`
- `scripts/continuum-ui-routing.test.mjs`

Unveränderte Basis: 24 PASS / 24 FAIL / 0 SKIP. Reparierte Verträge: **48 PASS / 0 FAIL / 0 SKIP**. 17 absichtliche Änderungen an Produktionsquellkopien lösten jeweils genau den erwarteten Vertragsfehler aus; anschließend erneut 48/48. 1663 andere materialisierte Dateien wurden Git-blobgenau zur Basis verifiziert. `git apply --check --whitespace=error-all` bestand.

Die Reparaturen verfolgen die heutigen realen Anschlüsse: fünf Arbeitsbereiche mit getrennten Kategorien und unverändertem Zielrouting; native Rail-/Shell-Klickziele; das eine wiederverwendete Hologramm am bestehenden AvatarDirector; tatsächliche gemessene Fensterbreite, Insets und IME-Verhalten; Reflow mit Entwurf, Auswahl und Fokus; Framezählung nach tatsächlichem Canvas-Zeichnen; Modellbereitschaft nur bei geladenem Modell und READY/GENERATING.

Für die geänderte Referenzgeometrie war die Anforderungsquelle `docs/research/omega/ASTRA-REFERENCE-PARITY-20261104.md` maßgeblich, nicht allein der aktuelle Code: elf Rail-Ziele, zehn Aktionen im Masterraster 5×2, vier Informationsfelder, getrennte Kopf-/Kugelregionen und Status. Die spätere Breitenklassen-Regel bestimmt das adaptive Reflow. Deshalb prüfen die aktualisierten Verträge den aktiven JarvisShell-/ReferenceLayout-Pfad statt überholter fester Portrait-Koordinaten oder eines deaktivierten Shell-Modus.

### Negative Kontrollen

- `wrong-category-list`: not ok 1 - all five bottom destinations open their own category
- `category-click-loses-target`: not ok 3 - all navigation taps route to existing trusted screens
- `rail-native-click-disconnected`: not ok 2 - Fold rail has actual click targets for every visible category
- `shell-native-click-disconnected`: not ok 3 - responsive dashboard retains chat composer, updates and keyboard visibility
- `phone-ime-margin-inverted`: not ok 3 - keyboard hides phone navigation and frees the same reserved space
- `reflow-selection-lost`: not ok 2 - reflow preserves the active agent, user draft, conversation views and dashboard telemetry
- `reflow-reads-stale-configuration`: not ok 1 - unfold reflows from actual laid out root window width, not stale screenWidthDp
- `height-only-change-rebuilds-activity`: not ok 4 - keyboard-only height change does not recreate the Fold dashboard
- `draw-counter-disconnected`: not ok 1 - real drawn Canvas frames are counted separately from animation callbacks
- `model-readiness-fabricated`: not ok 6 - start screen never manufactures ready model or internet state
- `font-validation-removed`: not ok 5 - fold, small display and enlarged-font behaviour are expressed by a pure policy
- `head-and-orb-regions-aliased`: not ok 3 - ten action controls share draw bounds while head and original orb retain separate regions
- `current-reference-loses-two-tiles`: not ok 3 - ten action controls share draw bounds while head and original orb retain separate regions
- `memory-panel-reads-system-state`: not ok 2 - current information panels and separate status keep real sources and complete scrollable rows
- `mobile-builder-category-misrouted`: not ok 3 - builder stays in the existing agent UI and opens only an allowlisted Android activity
- `portrait-restores-duplicate-bottom-bar`: not ok 5 - Fold rail offers every current destination without a second bottom bar
- `home-replaces-live-avatar-instance`: not ok 2 - reference start screen reaches all seven real Android feature paths

Rohbelege: `ui-contracts/baseline.tap.gz`, `patched-final.tap`, `result.json`, `negative-controls.json` sowie die einzelnen komprimierten TAPs. Die Source-Verträge beweisen weder Pixelparität zum Referenzbild noch tatsächliches Android-/Fold-/GPU-/Sprachverhalten.

## Root-Patch Wave2 und Idle-Randwert

Finale Root-Version geprüft: `root-source-contracts-wave2.patch`, nicht die historische erste Version. Zusammen mit meinen neun Tests und dem originalen eingehenden AgentActivity-Blob `c1482ed3be0cb91734e10947613ec62d1a3c38cb` aus dem festgelegten #513-Stand liefen **59/59 PASS**. Entfernen ausschließlich der tatsächlichen `audioFrame=frame`-Weiterleitung erzeugte im Root-Zweiersatz **10 PASS / 1 FAIL**, exakt der Avatar/TTS-Vertrag. Danach eigene Kopien restauriert. Belege: `ui-contracts/root-independent-review.json`, `root-wave2-combined.tap`, `root-wave2-missing-frame.tap.gz`.

Der AvatarIdleMotion-Fix ist statisch unabhängig freigegeben: Der ursprüngliche Float-Zeitwert `-0.0f` bzw. ein negatives ganzes Vielfaches von 460 s ergibt einen negativen Nullrest. Double-Binärsuche unterscheidet diesen von dem ersten positiven Nullwert und kann einen Index -1 produzieren. Die ergänzte Gleichheitsprüfung normalisiert beide Nullzeichen vor der Suche; alle Nichtnullpfade bleiben unverändert. Originalblob `c60d0e180d2d3393b2db355b188a61dcba42f79e` und gepatchter Blob `fb2050171cb57ef9729a7a2bc603574bc6ad0292` wurden unabhängig verifiziert. Roots offizielle Kotlin/JDK/JUnit-Probe dokumentiert 1 FAIL vorher und 2 PASS nachher. Kein zweiter JVM-Lauf durch mich; kein neuer Timer, Listener oder Modellpfad.

## Regressionpatches und echte Brand-Grenze

Alle fünf Regressionpatches vollständig gelesen. Drei reine Quellvertragskorrekturen passen zu den realen Produktionsanschlüssen: Bots erhalten den unveränderten Owner-Auftrag und keine privaten Chat-Memories; Planning bleibt ohne Tool-/Retry-Autorität; beide Generierungspfade behalten denselben Trace und ihre Deadline; Entwicklung läuft über die existierende Mehr-Kategorie/Menu-Navigation; STT bleibt de-AT; der Experience-Store erhält seinen vorhandenen automaticRecovery-Parameter.

Der QA-Patch schließt die tatsächlich fehlende Variable `CONTINUUM_MENTOR_SIGNING_P12_BASE64` in denselben frühen Signing-Guard ein. Die ungekürzten Belege des Regressionbots wurden gelesen: zunächst zwei echte Fake-curl-Canary-Fehler aus 12 Fällen, anschließend 43/43 grün. Kein echter Schlüssel, Download oder Signiervorgang. Der gleichartige Produktionsfix aus #505 wird nur einmal übernommen.

### Tool-Memory-Fixtures mit ECHO

`tool-memory-fixtures.patch` verändert genau drei Testdateien. Die Produktionsdateien `coding-provider.mjs`, `repair-loop.mjs`, `ccc1-redgreen-verifier.mjs` und `ccc1-technical-recall.mjs` bleiben unverändert.

- Das synthetische Persistence-Fixture setzt jetzt das bereits produktiv verlangte `verifiedModelExecution: true`. Sein separater Testschlüssel, die Bezeichnung CONTRACT_TEST und die ausdrückliche Einschränkung ohne Inferenz bleiben bestehen. Das Feld erzeugt keine Mitgliedschaft im privaten Produktions-WeakSet.
- Die positiven Accounting-Fälle I11, I12, I13 und I15 verwenden ausschließlich den unitlokalen TEST-ONLY-Validator. Exakte Repair-Funktionskörper und die tatsächliche numerische Host-RED/GREEN-Prüfung bleiben erhalten. Der Data-URL-Import ersetzt nur den Coding-Provider-Import und löst übrige relative Imports wieder auf die echte Quellbasis auf.
- I18 importiert zusätzlich das unveränderte Produktionsmodul: Der numerische Patch darf VERIFIED sein, aber die fremde Test-Brand lässt `verifiedModelExecution` false und `modelInvocations`/`modelId` null. Eine Reparaturbestätigung wird nicht zu einer Modellinferenzbestätigung.
- C03 prüft beide echten read-only Produktionsvalidatoren gegen null, leeres Objekt, synthetisches Original, eingefrorene Kopie und strukturierte Kopie. Alle werden abgewiesen. C02 fordert weiterhin, dass Produktionsspeicherung solche Kopien zurückweist; C27 sagt ausdrücklich, dass die MAC-Provenienz Vertrauen in den Signierer und keinen Inferenzbeweis darstellt.

Meine zusätzliche unabhängige Probe legte **exakt die vier zuvor freigegebenen ECHO-Dateien** über den Snapshot und führte nur Caller + Challenge aus: **60 PASS / 0 FAIL / 0 SKIP**, Node v24.22.1, 14.311 s. `NODE_OPTIONS` war entfernt; weder caller-brand-loader noch fixture-tier-compat wurde geladen. Anschließend importierten alle drei ECHO-Produktmodule erfolgreich mit ihren echten Abhängigkeiten. Es war kein Branch-Scanner-/Scheduler-Import nötig. Sämtliche temporären Overlays wurden restauriert.

Belege: `regression-review/memory-echo-review-result.json`, `echo-memory-compatibility.tap`, `echo-production-imports.tap`. Der übrige Regressionumfang wurde anhand des Produktionscodes und der vorhandenen vollständigen Rohbelege reviewed, nicht unnötig erneut groß ausgeführt.

## ECHO: isolierte fertige Reparatur

Quelle: [PR #515](https://github.com/Ullmann27/device-ai/pull/515), gepinnter Commit `572e12ecc4ce5f7c79f2634a5b5773047b6d674f`. Nur coding-orchestrator.mjs, coding-service-worker.mjs, coding-service-reader.mjs und der neue coding-orchestrator-failure-report.test.mjs werden übernommen; der übrige Branch-Scheduler gehört nicht dazu.

Eigener unveränderter Baselinefall erzeugte den erwarteten kanonischen ABSTAINED-Journalzustand, aber keinen negativen Owner-Bericht: **0 PASS / 1 FAIL** am fehlenden Bericht. Nach den exakt vier Originaldateien: **9 PASS / 0 FAIL / 0 SKIP**. Private WeakMap-Failure-Brand, unveränderter technischer Fehler, aktuelle Grant-/Reporter-/Journalprüfung, MAC-geschützter Snapshot, keine technische Erfolgs-/Lernerfahrung und keine Umdeutung von UNKNOWN sind erhalten. Details und Einschränkungen stehen in `ECHO-REVIEW.md`.

## Bereits geprüfte #512-Integration

Die drei ursprünglichen Produktdeltas aus [#512](https://github.com/Ullmann27/device-ai/pull/512) waren Retriever, JarvisSequenceView und QA-Eingang. Sie wurden unabhängig ohne bestätigten Blocker reviewed. Die angeblichen 15/17 Kalenderfälle waren kein unterschiedlicher Produktfix: der endgültige #505-Retrieverblob `fa67f32044e57a3f23fdd158924f1f8bf004d5cf` ist exakt identisch; 15 Kalenderfälle einschließlich beider Santiago-Mitternacht/DST-Fälle plus zwei Retrieval-Experimentfälle ergeben die 17 Hostfälle. Der gemeinsame Basiscommit enthält diese abgeschlossenen Änderungen bereits.

## Offene kombinierte Abnahme und klare Grenzen

Die von Buildbot gemeldeten echten Android-UI-Fehler bzw. der hängende Gesamtlauf werden durch keinen dieser Source-Vertragspatches umgedeutet. Insbesondere ist die in älteren Arbeitsaufträgen ausdrücklich verlangte 2D-Rückfallebene bei 3D-Ausfall nicht allein durch die heutige Implementierung aufgehoben; mein Framezähler-Vertrag enthält keine Abschwächung dieses Fallback-Solls. Finale Diagnose und neue tatsächliche Androidläufe liegen beim Buildbot/Root.

Der neue gemeinsame SHA, vollständige Node-/Android-/Lint-Ergebnisse und die spätere Geräteabnahme müssen gesondert belegt werden. In diesem Auftrag wurden weder Main noch fremde Branches gemergt, keine Installation/Veröffentlichung ausgeführt und Paketname oder Signatur nicht verändert.
