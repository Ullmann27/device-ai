# C1-MISSING-022 — priorisierte fehlende Verbindungen

## Genau eine nächste Auswahl

**Empfohlen: den dauerhaften Scheduler an einen ausdrücklich übergebenen, abgewarteten Quell-Preflight koppeln.** Dieser fertige Anschlussbaustein aus #515 benötigt genau eine Produktions- und eine Testdatei. Er liegt bereits unveränderlich geprüft vor und kann ohne den aktiven Cursor-/Diagnoseumbau, ohne private Speicherformatänderung und ohne erneuten ECHO-/Sequenzimport durch C1 aufgenommen und selbst geprüft werden.

**Wichtige Wirkungsgrenze:** Das ist die vollständige kleine Scheduler-Kopplung, noch kein aktivierter Branchbot. Die heutigen C1-Aufrufer übergeben noch keinen `sourcePreflight`; ohne ausdrücklich gebundenen vertrauenswürdigen Callback entsteht keine zusätzliche Quellrichtlinie. Der Callback läuft nur im dauerhaften Pfad mit `stateFile`/`sourceRoot`. Discovery-CLI und deren konkrete Quellrichtlinie bleiben ein späterer eigener Anschluss.

Feste Vergleichsbasis: `d3487a83ea1cc61a34afcde4e17601c56def9ed2`, Tree `5c9745630cca44da3cb297761c8c59622e6c3a15`. Auswahlquelle: **#515 `5373ec7c1399cb34fb8896f7318fdfa5437fa283`**. [Unveränderlicher Handoff](https://github.com/Ullmann27/device-ai/blob/5373ec7c1399cb34fb8896f7318fdfa5437fa283/docs/research/omega/BRANCH-INTEGRATION-BOTS-HANDOFF-20261104.md).

| Ausgewählter Pfad | C1-Basisblob | Zielblob |
| --- | --- | --- |
| `.github/continuum/local-teamleader-loop.mjs` | `3dc5d63077fce0244e2bdeeb20b310aa762d2cfa` | `f83e6a1dcd40e7841734f893895766c6c3b1ed29` |
| `.github/continuum/local-teamleader-loop-source-preflight.test.mjs` | fehlt | `13c5661432115c883fc2b64161757aad9d1128f4` |

Der Produktionsdiff macht die vorhandenen Quellprüfungen asynchron und wartet den Callback vor Git-Statusprüfung bei Erstöffnung sowie vor und nach jedem Arbeitszyklus ab. Ein ungültiger Callbacktyp wird abgewiesen. Ablehnung nach Arbeit verhindert die Annahme ihres vermeintlichen Erfolgs. Checkpointformate, Budgets, Ergebnisvokabular und Lock-Implementierung bleiben erhalten. Die spätere `export acquireLoopLock`-Änderung aus dem Nachtstand gehört ausdrücklich nicht zu diesem Slice.

## Priorität und Abschlussgrad

| Rang | Verbindung | Quellenstand und Qualität | Konsequenz |
| --- | --- | --- | --- |
| **1 — ausgewählt** | Dauerhafter Scheduler → awaited source-preflight | Abgeschlossener Baustein auf `5373ec7c…`; vier echte Git-/Prozess-Canarytests sind im hashgeprüften 183er-TAP als PASS enthalten. | Genau die beiden oben genannten Pfade. C1 bleibt Eigentümer des Scheduler-Einbaus und führt einen eigenen RED/GREEN-Vergleich aus. |
| 2 — weiterer Fachbereich | Branch-Discovery/CLI → kanonischer Backlog, finite Wiederaufnahme und bestehende Hostdiagnose | Aktuell gelesener #515-Head `9423d5fb6978496ec843d0f7bcbe8285ee63677f`. Nacht-Handoff ist WIP, `state.json` ACTIVE/VERIFY_HOST_DIAGNOSTICS. M1 meldet 3 RED → 27 GREEN, M2 5 RED → 61 GREEN; abschließende kombinierte Abnahme steht aus. | Nicht den alten 183er-PASS auf den neuen Gesamtstand übertragen. Die alte begrenzte Scanlogik hat inzwischen belegte Wiederholungs-/Starvationsfehler. Verbleibende sieben Code-/Testpfade plus deren neue Nachtänderungen erst mit eindeutigem Abschluss aufnehmen. |
| 3 — getrennter App-Anschluss | Private Übungen für Kora/Link/Iris | #516 `2cd6381f924019c044f3c265b461012b08082222`: sechs Produktions- und vier Testpfade. Ursprünglich 70 vollständige Android/JVM-Fälle; aktueller Codec mit 70 DELTA_JVM-PASS, voller aktueller Android-Nachtest nach drei Daemonverlusten BLOCKED. Null Modellversuche. | Nach den gegenwärtigen C1-Fehlergates als eigener fachlicher Slice prüfen. Aktueller Android-/Activity-Aufrufnachweis und V3-Downgradegrenze bleiben offen. Kein Lernerfolg aus Fixtures ableiten. |

## Echte Testqualität des ausgewählten Bausteins

Die vier Regressionen verwenden tatsächliche temporäre Git-Repositories, ein ausführbares fsmonitor-/Filter-Canaryskript und eine absichtlich asynchrone Callbackgrenze. Sie verlangen:

1. Vor der ersten Statusprüfung keine Ausführung des abgelehnten fsmonitor, kein Arbeitsaufruf und keinen Checkpoint/Lock.
2. Nach Konfigurationsänderung in der Wartephase keinen zweiten Arbeitszyklus; gespeicherten ERROR ohne nächsten Versuch und freigegebenen Lock.
3. Nach Konfigurationsänderung während Arbeit keinen Filteraufruf und keine erfolgreiche Übernahme eines behaupteten `VERIFIED_PATCH_PENDING_REVIEW`; ERROR mit einem gezählten Fehler.
4. Bei einem nicht ausführbaren Callbackwert Abbruch vor Quellstatus, Arbeit und Checkpoint.

Im originalen TAP stehen diese vier Fälle als `ok 61` bis `ok 64`; Gesamtergebnis 183 PASS/0 FAIL/0 SKIP. SHA256 der tatsächlich gelesenen TAP-Bytes: `ad5362e4e3111808ac2e90565962c979f68a72d2f2cbfe894fbaa4574fd912ac`, unabhängig gegen den Receipt abgeglichen. Die unveränderte bestehende Scheduler-Testdatei hat in C1 den ursprünglichen Blob `d325c114c5a35a5d1ce21969f5aa58d53cf4ad56`.

Das sind fremde, quellengebundene Hostbelege. **Eigene Tests/Builds: NOT_RUN.** Kein eigener RED wird behauptet. C1s sinnvoller eigener enger Prüfgegenstand ist die neue Vierfall-Datei zusammen mit `local-teamleader-loop.test.mjs`, anschließend die relevanten vorhandenen Scheduler-Aufrufer. Ein Callback ist eine vertrauenswürdige lokale Programmschnittstelle; diese Prüfung liefert keine OS-Sandboxgarantie gegen beliebige gleichzeitige Manipulation des Hosts.

## Abhängigkeiten, verbleibende Pfade und Einbauzuständigkeit

Der ausgewählte Produktionspfad benötigt nur seine bisherigen Node-Standardmodule. Die neue Regression importiert ausschließlich diesen Scheduler und Node-Standardmodule. Kein Discovery-, Modell-, Android- oder Compilerimport ist erforderlich. Die vorhandenen Aufrufer in `teamleader-cli.mjs`, `ccc1-cli.mjs`, `continuum-workshop.mjs` und `coding-service.mjs` bleiben C1-verwaltet; ihr künftiges Binden einer Quellrichtlinie ist kein Teil dieses Zwei-Dateien-Slices.

Der spätere Branch-Anschluss betrifft `.github/continuum/branch-discovery.mjs` und dessen Test, `.github/continuum/branch-bots-cli.mjs` und dessen Test, `.github/continuum/repair-critic.mjs` sowie `scripts/continuum-release-host-preflight.mjs` und dessen Test. Er nutzt den vorhandenen Backlog, privaten Store, Scheduler und `resolveTermuxEnvironment`. Berichte und Cursor dürfen weiterhin nur `PROPOSED/BRANCH_REVIEW` liefern; sie erteilen keine Ausführungs-, Merge- oder Releasebefugnis. Der Nachtumbau dieses Bereichs bleibt beim Fachautor; dessen aktiver Branch wurde nicht verändert.

Der App-Anschluss aus #516 betrifft exakt:

- `app/src/main/java/at/heinz/deviceai/AgentActivity.kt` — drei begrenzte Anzeige-/Fehlerhunks, allein durch C1 auf seinen aktuellen Activity-Stand zu übertragen.
- `app/src/main/java/at/heinz/deviceai/ContinuumBotRosterDialog.kt`.
- `app/src/main/java/at/heinz/deviceai/chief/ChiefBotConversation.kt`.
- `app/src/main/java/at/heinz/deviceai/chief/ChiefBotPractice.kt`.
- `app/src/main/java/at/heinz/deviceai/chief/ChiefAvatarPracticeCurriculum.kt`.
- `app/src/main/java/at/heinz/deviceai/chief/ChiefEngineeringPracticeCurriculum.kt`.
- Die vier gleichnamigen Practice-/Curriculum-Regressionen unter `app/src/test/java/at/heinz/deviceai/chief/`, einschließlich `ChiefBotPracticeConversationTest.kt`; exakt ausgeschrieben in `matrix.json`.

Bewertet wird dort die akzeptierte terminale Antwort über den bestehenden prepare/generate/complete-Pfad. Prüfungen betreffen Schema, Antwortbindung, private Isolation, veraltete/abgebrochene Abschlüsse, Promptfilter für Wiederholungen und V2/V3-Codec. Die Antworttexte bleiben Testfixtures; sie belegen keine echte Inferenz. Nach tatsächlicher Nutzung eines V3-Verlaufs genügt ein Rückfall auf einen alten V1/V2-Leser nicht. Der aktuelle Delta-Nachweis kompiliert nur zwei geänderte Quellen über erhaltenen echten Buildartefakten, sechs Testklassen stammen aus dem vorherigen Bestand; beide 70er-Läufe dürfen nicht addiert werden.

**AgentActivity, Compiler, Factory und Scheduler bleiben C1-reservierte gemeinsame Einstiegspunkte.** Kein vollständiges altes Activity- oder Compilerfile aus einem Fachbranch ersetzt aktuelle C1-Quellen.

## Doppelimporte ausdrücklich ausgeschlossen

Alle vier ECHO-Dateien aus #515 sind an der festen C1-Basis exakt bytegleich: Orchestrator, Service-Worker, Service-Reader und negative Reportregression. Auch `render-continuum-owner-continuous-qa.sh` ist identisch. Der bestehende erweiterte C1-QA-Test wird nicht durch die ältere Fremdfassung ersetzt. Avatar-Sequenz-/Lifecycle-Reparaturen gehören zu keinem ausgewählten Pfad; sie bleiben vollständig bei C1. Die getrennten #523-Optimierungen gehören ebenfalls nicht zu Missing022.

Eigene Aktionen waren Quellenlesen, Git-Blob-/Textvergleich, Prüfung des vorhandenen TAP-Hashes und Ablage dieser Matrix. Erfolgreicher Vergleichsprozess Exit 0; kein neuer Test, Build, Checkout-Eingriff oder Kommentar. Rückfall des empfohlenen Bausteins vor zusätzlicher Caller-Nutzung: nur diese beiden Dateien auslassen beziehungsweise zurücknehmen; bei später gebundenen Callern zunächst deren Abhängigkeit prüfen. Keine Datenmigration.
