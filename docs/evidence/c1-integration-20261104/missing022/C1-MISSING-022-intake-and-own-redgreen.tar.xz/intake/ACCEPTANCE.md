# C1-MISSING-022 — geplanter echter RED/GREEN-Nachweis

**Status: vorbereitet, nicht ausgeführt.** Die folgenden Befehle sind der Abnahmeplan für C1 im vorhandenen seriellen Host-QA-Slot. Dieses Paket enthält kein gestartetes Worker-, Modell-, Netzwerk- oder Buildverfahren.

## 1. Quellen vor Ausführung binden

Vor Aufnahme muss der C1-Scheduler weiterhin Blob `3dc5d63077fce0244e2bdeeb20b310aa762d2cfa` haben und der neue Testpfad fehlen. Abweichungen sind eine neue Integrationsbasis, keine Erlaubnis zum Überschreiben. Patch-SHA256 `79b7beb43a946c839b93fa7fde6c4371bbc60d64a6eea264894938f6c66fb247` und `SHA256SUMS` prüfen. Node-/Git-Version, Quellenstand, echte Befehle, Start/Ende, Exitcodes und TAP-Hash in den C1-Receipt aufnehmen.

Die vorbereiteten Ordner sind vollständige minimale Node-Fixtures:

- `red/`: exakt alter Scheduler von f318 plus die vier bytegleichen neuen Regressionen.
- `green/`: exakt beide ausgewählten #515-Zieldateien.

Der neue Test braucht ausschließlich Node-Builtins und die lokale Schedulerdatei; weitere Branchbot-, CLI-, Android- oder Modellquellen sind für diesen Viererfokus nicht erforderlich. Alle Git-Fixtures entstehen in temporären Verzeichnissen und räumen ihre eigenen Daten über `t.after()` auf. System-/globale Git-Konfiguration wird für diese synthetischen Fixtures im Test isoliert und anschließend wiederhergestellt.

## 2. Fachlicher RED gegen unveränderte alte API

Vorgesehenes Arbeitsverzeichnis:
`/workspace/scratch/174c84456ee3/repair-review/missing022-intake/red`

```sh
node --test --test-concurrency=1 --test-reporter=tap .github/continuum/local-teamleader-loop-source-preflight.test.mjs
```

C1 zeichnet stdout/stderr und den unmittelbaren Prozess-Exitcode auf. Erwartet ist ein fachlicher nichtnull-Exit; die vier Fälle sollten gegen den alten, die Option ignorierenden Scheduler scheitern. Die tatsächliche Fallzahl wird aus dem Lauf ermittelt und nicht vorab als Ergebnis eingetragen. Import-, Syntax-, Dependency- oder Umgebungsfehler gelten nicht als fachlicher RED.

| Unveränderte Regression | Maßgeblicher Vorzustandsfehler / GREEN-Zusage |
|---|---|
| `initial durable source preflight rejects fsmonitor before any Git status or checkpoint` | Die alte API ignoriert den Callback. Die neue muss die asynchrone Ablehnung vor Git-Status, work, Checkpoint und Sperre beachten; der fsmonitor-Canary bleibt unberührt. |
| `configuration changed while waiting is rejected before the next scheduler status check` | Nach einem echten ersten Zyklus wird die lokale fsmonitor-Konfiguration geändert. Die neue Prüfung verhindert den zweiten Status/Arbeitszyklus; ERROR, cycles=1, nextAttemptAt=null und freigegebene Sperre sind verlangt. |
| `configuration changed during work is rejected before post-work Git filters or success acceptance` | work installiert einen synthetischen Clean-Filter und behauptet VERIFIED_PATCH_PENDING_REVIEW. Die neue Prüfung muss den Filteraufruf und diese Erfolgsannahme verhindern; Summary/Heartbeat ERROR, cycles=1, failures=1, keine nächste Ausführung und freigegebene Sperre bleiben erforderlich. |
| `an invalid preflight option fails closed before a source status or work callback` | Ein nicht aufrufbarer Optionswert wird vom alten Scheduler ignoriert. Die neue API muss vor Status und work mit dem konkreten Typfehler ablehnen; kein Marker/Checkpoint. |

## 3. Identischer Viererfokus mit exaktem Ziel

Vorgesehenes Arbeitsverzeichnis:
`/workspace/scratch/174c84456ee3/repair-review/missing022-intake/green`

```sh
node --test --test-concurrency=1 --test-reporter=tap .github/continuum/local-teamleader-loop-source-preflight.test.mjs
```

Abnahmeziel: genau vier abgeschlossene PASS-Fälle, null FAIL/CANCELLED/SKIP/TODO, Exit 0. Dieselbe Regressiondatei und dieselben Fixture-/Assertiontexte bleiben zwischen RED und GREEN byteidentisch. Nur der Scheduler wechselt vom dokumentierten Basisblob zum Zielblob. Bei einem Fehler zuerst Ursache belegen; kein unveränderter Wiederholungslauf als Ersatz für eine neue Hypothese.

## 4. Einmaliger C1-Kompatibilitätsfokus nach serieller Integration

Nach C1-eigener Aufnahme des Zweidateien-Patches und Sicherung des neuen C1-Quellstands, Arbeitsverzeichnis C1-Repo:

```sh
node --test --test-concurrency=1 --test-reporter=tap .github/continuum/local-teamleader-loop-source-preflight.test.mjs .github/continuum/local-teamleader-loop.test.mjs
```

Abnahmeziel: vier neue und 22 unveränderte bisherige Top-Level-Fälle, also erwartbar 26 PASS, null FAIL/CANCELLED/SKIP/TODO, Exit 0. Maßgeblich bleiben tatsächliche TAP-Zahlen. Die bisherigen Fälle prüfen unter anderem Budgets, Cadence/Backoff, ehrliche Outcomes, Abbruch, Checkpoint-Integrität, Quelländerungen, Sperren und Crash-/Restart-Verhalten. Ihre Abhängigkeiten kommen aus dem C1-Repo; keine zusätzlichen Quellen aus #515 importieren.

Nach dem Lauf den tatsächlich geprüften Produktionsblob und Testblob nochmals mit dem Manifest vergleichen. Dieser Fokus beweist Schedulerkompatibilität und den Hookvertrag. Er beweist weder eine Callback-Bindung in den vier heutigen Aufrufern noch Branchbot-End-to-End, Modellleistung oder Android-Verhalten. Der historische 183er-Beleg bleibt separat und wird nicht zu diesem Lauf addiert.

## Ergebnisfelder, derzeit offen

| Gate | Status / Exitcode jetzt |
|---|---|
| Statischer Quell-/Blob-/Hashvergleich bei der Vorbereitung | PASS / 0 |
| C1 RED mit alter Produktionsdatei | NOT_RUN / kein Exitcode |
| C1 GREEN mit ausgewählter Produktionsdatei | NOT_RUN / kein Exitcode |
| Integrierter C1-Kompatibilitätsfokus | NOT_RUN / kein Exitcode |
