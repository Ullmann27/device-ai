# C1-MISSING-022 — exakter Zweidateien-Slice

## Übergabe

Der Slice ist für C1 vorbereitet, aber noch nicht durch C1 abgenommen. Er enthält ausschließlich den optionalen, abgewarteten SourcePreflight-Hook im dauerhaften Scheduler und die vier unveränderten Quellregressionen. Kein Test oder Build wurde für dieses Intake ausgeführt. C1 bleibt alleiniger Einbauer.

Quelle: #515, unveränderlicher Commit `5373ec7c1399cb34fb8896f7318fdfa5437fa283`. Beide Dateien wurden erneut über ihre commitgebundenen GitHub-URLs gelesen und ihre Git-Blob-IDs sowie SHA256-Werte unabhängig nachgerechnet. Die neueren Night-Änderungen, einschließlich des zusätzlichen Exports von `acquireLoopLock`, sind ausgeschlossen.

Basis: C1 `f31855138d77ecb5e05e7a17a620b1fd6e9d28c5`, Tree `323227c1c05017b0733509e24f0aebc2cc9faa25`. Der Scheduler ist seit der ursprünglichen Auswahlbasis d348 unverändert; auch der bei der Aufnahme gelesene Arbeitsbaumtext entspricht dem Basisblob.

| Pfad | Basisblob | Zielblob |
|---|---|---|
| `.github/continuum/local-teamleader-loop.mjs` | `3dc5d63077fce0244e2bdeeb20b310aa762d2cfa` | `f83e6a1dcd40e7841734f893895766c6c3b1ed29` |
| `.github/continuum/local-teamleader-loop-source-preflight.test.mjs` | Nicht vorhanden | `13c5661432115c883fc2b64161757aad9d1128f4` |

Patch: `C1-MISSING-022-source-preflight.patch`, 9.807 Bytes, SHA256 `79b7beb43a946c839b93fa7fde6c4371bbc60d64a6eea264894938f6c66fb247`. `SOURCE-MANIFEST.json` enthält alle Datei-, Aufrufer- und Evidenzhashes sowie die commitgebundenen Quell-URLs.

## Verhalten und Grenzen

Ein vertrauenswürdiger optionaler Callback wird vor dem ersten Git-Status beim Öffnen des dauerhaften Checkpoints, vor jedem Arbeitszyklus und vor Annahme des Zyklusergebnisses abgewartet. Eine Ablehnung verhindert den betreffenden Git-Status und die Ergebnisannahme. Ein ungültiger Callback-Typ wird vor Quellenöffnung abgelehnt. Der Default `null` erhält bestehende Aufruferkompatibilität. Die internen Funktionen werden asynchron; `runTeamleaderLoop` war bereits asynchron.

Die initiale Ablehnung legt keinen Checkpoint und keine Sperre an. Eine Ablehnung zwischen Zyklen persistiert ERROR und wirft; eine Ablehnung nach Arbeit persistiert ERROR, zählt den fehlgeschlagenen Zyklus und liefert die entsprechende Summary. Die vorhandenen Quellidentitäten, endlichen Budgets, Integritätsprüfung, Checkpoint-Version und Sperrfreigabe bleiben bestehen.

**Dieser Slice aktiviert keinen Branchbot und keine neue Quellenrichtlinie in bestehenden C1-Aufrufern.** Alle vier tatsächlichen Aufrufer wurden am Basiscommit gelesen:

| C1-eigener Aufrufer | Bestehende Betriebsart | Callback nach diesem Slice |
|---|---|---|
| `teamleader-cli.mjs` | Dauerhaft nur mit `--durable`, sonst ohne Checkpoint | Nicht gebunden |
| `ccc1-cli.mjs` | Dauerhafte Schleife mit stateFile/sourceRoot | Nicht gebunden |
| `continuum-workshop.mjs` | Schleife ohne dauerhaften Checkpoint | Nicht gebunden |
| `coding-service.mjs` | Dauerhafte Owner-Service-Schleife | Nicht gebunden |

Ein späterer C1-Slice muss eine geprüfte, begrenzte Quellenrichtlinie ausdrücklich an einen dauerhaften Aufrufer binden. Bei `stateFile=null` existiert keine neue Quellenprüfung. Der Hook ist keine vollständige Sandbox, keine Garantie gegen zeitgleiche fremde Quellenmutation und besitzt keinen eigenen Timeout; seine vertrauenswürdige Implementierung muss selbst begrenzt bleiben. Diese Eigenschaften werden nicht durch die vier Tests erweitert.

## Testqualität und Evidenzabgrenzung

Die vier Regressionen benutzen echte temporäre Git-Repositories, synthetische fsmonitor-/clean-Canaries und eine absichtliche asynchrone Grenze. Sie prüfen Markerfreiheit, Arbeitsaufrufe, Checkpoint-/Sperrzustand und die tatsächliche ERROR-Semantik. Sie importieren nur die bereits vor dem Fix vorhandene API `runTeamleaderLoop`; ein RED kann deshalb auf dem echten alten Scheduler ausgeführt werden, ohne absichtlich fehlende Exporte zu importieren.

Der historische 183-PASS-Beleg der ausgewählten #515-Quellprüfung enthält diese vier Fälle bereits als TAP 61–64 und die 22 bisherigen Schedulerfälle als 65–86. Seine TAP-SHA256 ist `ad5362e4e3111808ac2e90565962c979f68a72d2f2cbfe894fbaa4574fd912ac`. Der Beleg umfasst außerdem Branch-Discovery/CLI, CCC1/ECHO, Coding-Service und Host-Preflight. Er ist weder eine zusätzliche unabhängige 183er-C1-Prüfung noch eine Prüfung des neueren Night-Headers; 183 + 4 oder 183 + 26 dürfen nicht als zusätzliche Abdeckung gezählt werden. Die genauen zwölf historischen Testdateien stehen im vorhandenen Receipt unter `repair-review/missing022/source-receipts/515-5373ec7c-node-tests.json`.

Die 22 bestehenden Schedulerfälle bleiben unverändert, Blob `d325c114c5a35a5d1ce21969f5aa58d53cf4ad56`. Der eigene RED/GREEN-Status lautet ausdrücklich NOT_RUN; konkrete Befehle und Abnahmekriterien stehen in `ACCEPTANCE.md`.

## Ausschlüsse und Rücknahme

Keine Aufnahme von Branch-Discovery/CLI, Callback-Aufrufern, Echo-/Sequenz-Reparaturen, #516-Übungen, #529-Credentials/Privacy, AgentActivity, Compiler oder Factory. Diese gemeinsam genutzten Einstiegspunkte bleiben bei C1.

Die Rücknahme erfolgt bei Bedarf durch C1 als Rücknahme genau seines Slice-Commits. Es entsteht kein neues Checkpointformat. Vor Wiederverwendung eines dauerhaften Checkpoints bleibt die bestehende Bindung an den konkreten Quell-HEAD verbindlich; Checkpoints nicht passend editieren. Falls später ein Aufrufer den Hook als Schutz voraussetzt, darf die Scheduler-Rücknahme nicht allein erfolgen: der alte Scheduler würde den zusätzlichen Optionsschlüssel ignorieren. Diese spätere Abhängigkeit muss C1 dann zusammen prüfen.
