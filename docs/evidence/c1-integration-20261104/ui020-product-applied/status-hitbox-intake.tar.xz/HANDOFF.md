# C1-UI-020 — separater Vorschlag für die native STATUS-Hitbox

## Ergebnis und Einbaugrenze

Der Vorschlag vergrößert ausschließlich die native, weiterhin klickbare STATUS-Aktion auf mindestens 48 dp Höhe. Er ergänzt den geprüften UI020-Produkt-V1 und behebt den im ursprünglichen Android-RED belegten 39-dp-Bereich. **Vorgeschlagen, nicht eingebaut und nicht ausgeführt.** C1 bleibt alleiniger Einbauer; ein GREEN wird nicht behauptet.

Geändert werden genau zwei Stellen in `app/src/main/java/at/heinz/deviceai/ui/ContinuumHomeView.kt`: die native Messhöhe in `measureShellActions` und die untere native Layoutkante in `layoutShellActions`. Activity, Avatar-Lebenszyklus, Layoutmodell, Renderer, andere Aktionen und Tests sind nicht Bestandteil dieses Patches.

| Identität | Wert |
| --- | --- |
| Voraussetzung | UI020-Produkt-V1, Patch-SHA256 `fb3799bfc0b9045d72563dd03ac9e24c0ea262c9920b42bbd02af2f5965ff12d` |
| Basisblob | `977f50f5304677aaaf32f48b4cd0e96794948e8a` |
| Basis-SHA256 | `da5aca2d991f571933d1b927f438ff2598cf907ae4fd5acc13b9265c3b10bee7` |
| Zielblob | `8d643cff16d37c69ca93618cb464b4c94e0ae691` |
| Ziel-SHA256 | `6f53543883ff4b7eabddf8aeca40a5cc5d94484111b294aeeafeb70dcebc472a` |
| Dateimodus | `100644` |
| Patch | `C1-UI-020-status-hitbox-v1.patch`, 2.158 Bytes |
| Patch-SHA256 | `d01d4f47a68f4a5951cae28262847f6eec119ebd1153ac249b31c5588a337f53` |

Die beigefügten vollständigen Basis-/Zieldateien sind Prüfbelege. Falls C1-AVATAR-SLOT-023 inzwischen dieselbe Home-Datei verändert hat, dürfen sie **nicht als vollständiger Dateiersatz** verwendet werden. Nach serieller Übernahme der disjunkten Hunks muss C1 den resultierenden Gesamtblob neu erfassen. apk_readiness hat die Trennung von seinen Attach-/Detach-/Avatar-Andockhunks bestätigt.

## Eigener Read des ursprünglichen RED

Das unveränderte C1-Archiv `red/android-ui020-red-01.tar.xz` wurde unabhängig gelesen und SHA256-geprüft: `191c9330db35639c1bb9bfea11f6dfaec0adfd25f683bb4d4105865de9ecc966`.

Es bindet an Commit `f31855138d77ecb5e05e7a17a620b1fd6e9d28c5`, Tree `323227c1c05017b0733509e24f0aebc2cc9faa25`, saubere Quelle und `sourceUnchanged=true`. Der ursprüngliche Gradle-/Robolectric-Lauf endete am 04.11.2026 um 21:51:51 UTC mit Exit 1. Das frische XML enthält 8 Fälle, 1 PASS, 7 FAIL, 0 ERROR und 0 SKIP; das Log enthält identitätsgleich 8 START und 8 END.

Die beiden Methoden `foldLandscapeHasRealDestinationsAndReadableLargeType` und `foldPortraitHasRealDestinationsAndReadableLargeType` scheitern jeweils mit `jarvis-panel:STATUS actual height 39.0dp` in `assertMinimumTarget`. Das ist ein tatsächlich gemessener nativer Zielbereich, keine aus einer Zeichnung abgeleitete Annahme. `red/receipt.json` enthält Resultat, XML-Zählung und ursprüngliche Fehlerstapel; das Originalarchiv und XML sind separat gesichert.

Die übrigen fünf Fehler bleiben getrennt: vier Fixture-Befunde liegen bei repair_review, die fehlende Kompaktwahl gehört zum schon geprüften Produkt-V1. Der Statuspatch ändert keine dieser Tests und erklärt keinen anderen Fehler für behoben.

## Geometriebegründung aus dem Quelltext

Für das Referenzraster gilt `u = min(widthDp/1536, heightDp/1024)`. Der Referenzzweig benötigt mindestens 840 dp Breite und 560 dp Höhe; damit gilt `u >= 35/64`. STATUS liegt unverändert zwischen `906*u + extraHeight` und `978*u + extraHeight`. Seine gezeichnete Höhe beträgt `72*u`, am schmalsten Referenzprofil also 39,375 dp. Die alte native Pixeltrunkierung erklärt die im mdpi-RED gemessenen 39 Pixel.

Die neue Messung verwendet nur für `panel:STATUS` mindestens `ceil(48*density)` Pixel. Die Layoutkante wird aus derselben gemessenen Höhe gebildet; linke/rechte Grenze und obere Kante bleiben erhalten. Erweitert wird ausschließlich nach unten. Eine symmetrische Vergrößerung könnte unnötig in oberhalb liegende Steuerelemente wachsen und ist hier nicht erforderlich.

Von der unveränderten STATUS-Oberkante bis zum Ende des Referenzinhalts bleiben `118*u >= 64,53125 dp`. Eine 48-dp-Zielfläche lässt mindestens 16,53125 dp freien Platz vor Pixelrundung. Die Rail endet bereits bei `896*u + extraHeight`, die Informationsreihe bei `888*u + extraHeight`; beide liegen oberhalb der unveränderten STATUS-Oberkante. Unter STATUS gibt es im Referenzzweig keine Geschwisteraktion. Bei 840×649 dp und mdpi bleibt der native obere Rand 584 Pixel, die neue Unterkante 632 Pixel, innerhalb von 649 Pixeln Inhaltshöhe.

Im Reflow-Zweig ist STATUS bereits mindestens 56 dp hoch, am Phone 90 dp, jeweils mit dem vorhandenen Schriftfaktor. Daher braucht dieser Zweig keine zusätzliche Mindesthöhenvergrößerung. Alle anderen Aktionen behalten ihre bisherigen Mess-/Layoutausdrücke. Die `shellActionBounds` des Layoutmodells, Referenz-/HERO-Zeichnung, Gesamtinhaltshöhe und normale Reflow-Anordnung werden nicht geändert. Die Native-View-Fläche kann bewusst über den gezeichneten Streifen hinausreichen; ihr bestehender `system`-Handler, Fokus und Klickbarkeit bleiben erhalten.

Diese Aussagen sind eine statische Ableitung aus den eingefrorenen Produktquellen. Es wurde kein Layout-, Kotlin-, Android- oder Geräteprogramm ausgeführt. Rundung, tatsächliche Native-View-Geometrie, Klickwege und Überlappung müssen C1s Laufprüfung bestätigen.

## Unverändertes Test-Orakel und offene Abnahme

Der originale Acht-Fälle-Testpatch bleibt bytegleich mit SHA256 `fdd1d7bccba6c400ccaa2edc0fad8224b83da9dfcbf1be9488a07327829f9b7e`. Die strengen 48-dp-Assertions, Überlappungsprüfungen und Klickprüfungen werden weder entfernt noch abgeschwächt. Beide tatsächlich roten Fold-Methoden bilden das bestehende Regressions-Orakel.

C1 muss nach serieller Integration des Produkt-V1, dieses Zusatzhunks und separat geprüfter Fixturekorrekturen die tatsächlichen Android-Fälle mit dokumentierter Gesamtquelle erneut ausführen. Zu prüfen sind mindestens STATUS-Höhe >=48 dp auf beiden Fold-Profilen, alle bestehenden 48-dp- und Überlappungsbedingungen, die vorhandene Systemnavigation und unveränderte gezeichnete Referenzgeometrie. Für die breite Kompaktansicht gilt weiterhin der V1-Review: sie kann insgesamt höher werden; die acht Fälle belegen keinen universellen Kompaktflächengewinn oder eine breite Compact-Bildabnahme.

`static-verification.json` dokumentiert ausschließlich die erneute dateibasierte Rekonstruktion des Patches und die Hashprüfung. `SHA256SUMS.json` bindet alle Dateien dieses Zusatzpakets. Der ältere V1-Review und sein Index wurden nicht überschrieben.

**Eigene Ausführung: keine Tests, Builds, Modelle, Locks oder Repositoryänderungen. Kein Gesamtgate-PASS und kein externer C2-ACK.**

