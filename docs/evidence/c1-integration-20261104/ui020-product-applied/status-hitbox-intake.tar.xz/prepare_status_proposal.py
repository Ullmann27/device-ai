#!/usr/bin/env python3
"""Prepare only a native STATUS hitbox delta; no app/test/build execution."""
from __future__ import annotations
import datetime,difflib,hashlib,json,pathlib,re,tarfile,xml.etree.ElementTree as ET
ROOT=pathlib.Path('/workspace/scratch/174c84456ee3')
P=ROOT/'apk-audit/ui020'
OUT=ROOT/'source-audit/ui020/status-hitbox'
PATH='app/src/main/java/at/heinz/deviceai/ui/ContinuumHomeView.kt'
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
def save(path,data):
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(data.encode() if isinstance(data,str) else data)
def savejson(path,v):save(path,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
base=(P/'proposed'/PATH).read_bytes()
assert blob(base)=='977f50f5304677aaaf32f48b4cd0e96794948e8a'
assert sha((P/'C1-UI-020-product-v1.patch').read_bytes())=='fb3799bfc0b9045d72563dd03ac9e24c0ea262c9920b42bbd02af2f5965ff12d'
s=base.decode()
old_measure='''            val py = spec.box.height * density
            view.measure(MeasureSpec.makeMeasureSpec(px.toInt().coerceAtLeast(1), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(py.toInt().coerceAtLeast(1), MeasureSpec.EXACTLY))
'''
new_measure='''            val py = spec.box.height * density
            // The reference status strip may paint below 48dp; keep its native action reachable.
            val minHeightPx = if (spec.key == "panel:STATUS") kotlin.math.ceil(48f * density).toInt() else 1
            view.measure(MeasureSpec.makeMeasureSpec(px.toInt().coerceAtLeast(1), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(py.toInt().coerceAtLeast(minHeightPx), MeasureSpec.EXACTLY))
'''
old_layout='''            shellActions[key]?.layout((box.left * density).toInt(), (box.top * density).toInt(),
                (box.right * density).toInt(), (box.bottom * density).toInt())
'''
new_layout='''            shellActions[key]?.let { view ->
                val top = (box.top * density).toInt()
                // Extend only STATUS downward into its existing footer space; painted geometry is unchanged.
                val bottom = if (key == "panel:STATUS")
                    maxOf((box.bottom * density).toInt(), top + view.measuredHeight)
                else (box.bottom * density).toInt()
                view.layout((box.left * density).toInt(), top, (box.right * density).toInt(), bottom)
            }
'''
assert s.count(old_measure)==s.count(old_layout)==1
t=s.replace(old_measure,new_measure,1).replace(old_layout,new_layout,1)
assert t.replace(new_measure,old_measure,1).replace(new_layout,old_layout,1)==s
target=t.encode()
patch=('diff --git a/'+PATH+' b/'+PATH+'\nindex '+blob(base)+'..'+blob(target)+' 100644\n'+''.join(
 difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='a/'+PATH,tofile='b/'+PATH,n=3))).encode()
save('C1-UI-020-status-hitbox-v1.patch',patch)
save('base/'+PATH,base);save('target/'+PATH,target)
# Bind existing RED without executing it.
arc=ROOT/'continuum-c1/docs/evidence/c1-integration-20261104/ui020-own-red/android-ui020-red-01.tar.xz'
arcbytes=arc.read_bytes();arcsha=sha(arcbytes)
assert arcsha=='191c9330db35639c1bb9bfea11f6dfaec0adfd25f683bb4d4105865de9ecc966'
save('red/android-ui020-red-01.tar.xz',arcbytes)
with tarfile.open(arc,'r:xz') as tf:
 result=json.load(tf.extractfile('android-ui020-red-01.result.json'))
 xmlbytes=tf.extractfile('junit/TEST-at.heinz.deviceai.ContinuumReferenceCockpitUiTest.xml').read()
 xml=ET.fromstring(xmlbytes)
 log=tf.extractfile('android-ui020-red-01.log').read().decode()
assert result['source']['commit']=='f31855138d77ecb5e05e7a17a620b1fd6e9d28c5'
assert result['source']['tree']=='323227c1c05017b0733509e24f0aebc2cc9faa25'
assert result['source']['dirty']=='' and result['sourceUnchanged'] and result['exitCode']==1
cases=xml.findall('testcase')
status=[]
for case in cases:
 for fail in case.findall('failure'):
  if 'jarvis-panel:STATUS actual height 39.0dp' in fail.get('message',''):
   status.append({'method':case.attrib['name'],'message':fail.attrib['message'],'stack':fail.text})
assert len(status)==2
assert sorted(x['method'] for x in status)==[
 'foldLandscapeHasRealDestinationsAndReadableLargeType','foldPortraitHasRealDestinationsAndReadableLargeType']
starts=re.findall(r'^AUDIT_TEST_START (.+)$',log,re.M)
ends=re.findall(r'^AUDIT_TEST_END (.+) (SUCCESS|FAILURE|SKIPPED)$',log,re.M)
assert len(starts)==len(ends)==len(cases)==8
assert sorted(starts)==sorted(x[0] for x in ends)
save('red/TEST-at.heinz.deviceai.ContinuumReferenceCockpitUiTest.xml',xmlbytes)
savejson('red/receipt.json',{'archive_sha256':arcsha,'archive_bytes':len(arcbytes),'result':result,
 'xml':{'attributes':xml.attrib,'test_count':len(cases),'starts':len(starts),'ends':len(ends)},
 'status_failures':status,'own_execution':'NOT_RUN','method':'Independent static read of original immutable C1 RED archive'})
manifest={
 'task':'C1-UI-020-STATUS-HITBOX','status':'PROPOSED_NOT_RUN_NOT_INTEGRATED',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Only native panel:STATUS pixel height and bottom layout bound; painted Shell, reference/HERO, text and all other native actions unchanged',
 'prerequisite':'UI020 product-v1 patch fb3799bfc0b9045d72563dd03ac9e24c0ea262c9920b42bbd02af2f5965ff12d applied/reconciled by sole integrator C1',
 'file':PATH,'mode':'100644',
 'base':{'blob':blob(base),'sha256':sha(base),'bytes':len(base)},
 'target':{'blob':blob(target),'sha256':sha(target),'bytes':len(target)},
 'patch':{'path':'C1-UI-020-status-hitbox-v1.patch','sha256':sha(patch),'bytes':len(patch)},
 'scope_integrity':'Exact reversal of the two specific replacements recovers the entire product-v1 base file.',
 'red_receipt':{'archive_sha256':arcsha,'cases':8,'pass':1,'fail':7,'skip':0,'exit':1,'status_height_failures':2},
 'geometry_reasoning':{
  'reference_unit_minimum':'min(840/1536,560/1024)=35/64',
  'painted_status_top':'906*u+extraHeight',
  'painted_status_bottom':'978*u+extraHeight',
  'painted_height':'72*u; at 840dp width u=35/64 -> 39.375dp; original pixel truncation -> 39px at mdpi',
  'untouched_total_content_height':'1024*u+extraHeight',
  'new_native_height':'max(original floor(height*density), ceil(48*density)) pixels',
  'new_native_top':'unchanged floor(box.top*density)',
  'new_native_bottom':'max(original floor(box.bottom*density), nativeTop+measuredHeight)',
  'growth_direction':'downward only; horizontal bounds and top unchanged',
  'available_dp_from_top_to_content_bottom':'118*u >=64.53125dp',
  'remaining_dp_after_48dp_target':'118*u-48 >=16.53125dp before pixel rounding',
  'no_new_overlap':'No sibling below STATUS in reference composition; rail/information remain above unchanged top. Reflow STATUS height>=56dp already satisfies minimum, so its native geometry remains unchanged.',
  'no_runtime_geometry_execution':True},
 'frozen_tests':{'patch_sha256':'fdd1d7bccba6c400ccaa2edc0fad8224b83da9dfcbf1be9488a07327829f9b7e',
  'assertion':'Strict >=48dp and no overlap remain unchanged; existing failing Fold methods are the regression oracle',
  'modified':False},
 'acceptance':'Root must rerun actual UI020 Android cases after separately reviewed fixture changes; exact relevant source, pixel-height>=48dp, zero native overlap, unchanged painted geometry and source identity. No GREEN inferred here.',
 'coordination':'No Activity or Avatar-slot lifecycle edit. C1-AVATAR-SLOT-023 may separately change this same Home file; integrate exact disjoint hunks and rebind resulting full blob, never overwrite its whole file with this old-base target.',
 'repo_changes':'NONE','builds':'NOT_RUN','tests':'NOT_RUN','locks':'NOT_ACQUIRED','external_C2_ACK':'NOT_CLAIMED'}
savejson('C1-UI-020-status-hitbox-v1.json',manifest)
print(json.dumps({'patch':manifest['patch'],'base':manifest['base'],'target':manifest['target'],
 'red_status_failures':2,'runtime':'NOT_RUN'},indent=2))

