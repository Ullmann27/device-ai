import base64
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path('/workspace/scratch/174c84456ee3/continuum-c1')
STATE = pathlib.Path('/workspace/scratch/174c84456ee3/qa/c1-publish-state.json')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

mode = sys.argv[1]
if mode == 'manifest':
    state = json.loads(STATE.read_text())
    assert not git('status', '--porcelain').strip(), 'Tracked checkout must be clean'
    head = git('rev-parse', 'HEAD').decode().strip()
    parent = git('rev-parse', 'HEAD^').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    assert parent == state['local'], 'Publish exactly one committed step'
    chunks = git('diff', '--name-status', '--no-renames', '-z', 'HEAD^', 'HEAD').split(b'\0')
    files = []
    for i in range(0, len(chunks) - 1, 2):
        status, path = chunks[i].decode(), chunks[i + 1].decode()
        assert status in ('A', 'M', 'D', 'T'), status
        if status == 'D':
            files.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': None})
        else:
            meta = git('ls-tree', 'HEAD', '--', path).split(b'\t', 1)[0].decode().split()
            mode, kind, sha = meta
            assert kind == 'blob' and mode in ('100644', '100755', '120000')
            size = int(git('cat-file', '-s', sha))
            files.append({'path': path, 'mode': mode, 'type': kind, 'sha': sha, 'base64Length': ((size + 2)//3)*4})
    print(json.dumps({'state': state, 'head': head, 'parent': parent, 'tree': tree, 'files': files}))
elif mode == 'blob':
    sha, offset = sys.argv[2:4]
    assert re.fullmatch(r'[0-9a-f]{40}', sha)
    start = int(offset)
    assert start >= 0
    data = base64.b64encode(git('cat-file', 'blob', sha)).decode()
    print(data[start:start + 24576])
elif mode == 'state':
    obj = {'branch': 'integration/continuum-c1-candidate-20261104', 'local': sys.argv[2], 'remote': sys.argv[3], 'tree': sys.argv[4]}
    assert obj['branch'] == 'integration/continuum-c1-candidate-20261104'
    assert all(re.fullmatch(r'[0-9a-f]{40}', obj[x]) for x in ('local', 'remote', 'tree'))
    STATE.write_text(json.dumps(obj, indent=2) + '\n')
    print(json.dumps(obj))
else:
    raise SystemExit('Unknown mode')
