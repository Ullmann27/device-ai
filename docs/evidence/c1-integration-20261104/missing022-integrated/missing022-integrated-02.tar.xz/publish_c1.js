async function publish(message) {
  const repo = 'Ullmann27/device-ai';
  const helper = '/workspace/scratch/174c84456ee3/qa/c1_publish_io.py';
  if (!message.includes('[skip ci]')) throw new Error('Commit must preserve Actions suppression');
  const run = async (args) => {
    const r = await tools.exec_command({cmd: 'python3 ' + helper + ' ' + args, max_output_tokens: 10000});
    if (r.exit_code !== 0) throw new Error(r.output);
    return r.output.trim();
  };
  const obj = (r) => {
    if (r.isError) throw new Error(JSON.stringify(r));
    const s = r.structuredContent;
    if (!s) throw new Error('No structured connector result');
    return typeof s.content === 'string' ? JSON.parse(s.content) : s;
  };
  const m = JSON.parse(await run('manifest'));
  const pr = obj(await tools.mcp__codex_apps__github_fetch({url: 'https://api.github.com/repos/' + repo + '/pulls/519'}));
  if (pr.head.ref !== m.state.branch || pr.head.repo.full_name !== repo) throw new Error('Wrong PR target');
  const current = obj(await tools.mcp__codex_apps__github_fetch({url: 'https://api.github.com/repos/' + repo + '/git/commits/' + pr.head.sha}));
  const save = async (remote) => {
    const state = {branch: m.state.branch, local: m.head, remote, tree: m.tree};
    await run('state ' + m.head + ' ' + remote + ' ' + m.tree);
    store('c1-latest-local', m.head); store('c1-latest-remote', remote); store('c1-latest-tree', m.tree);
    return state;
  };
  if (pr.head.sha !== m.state.remote) {
    if (current.tree.sha === m.tree && current.parents.length === 1 && current.parents[0].sha === m.state.remote && current.message.includes(m.head)) {
      return {recoveredPreviouslyCompletedUpdate: true, ...await save(current.sha)};
    }
    throw new Error('Remote lease moved; inspect before any write: ' + pr.head.sha);
  }
  if (current.tree.sha !== m.state.tree) throw new Error('Recorded parent tree mismatch');
  const elements = [];
  for (const f of m.files) {
    if (f.sha === null) { elements.push(f); continue; }
    let content = '';
    for (let start = 0; start < f.base64Length; start += 24576) content += await run('blob ' + f.sha + ' ' + start);
    if (content.length !== f.base64Length) throw new Error('Truncated local blob: ' + f.path);
    const created = obj(await tools.mcp__codex_apps__github_create_blob({repository_full_name: repo, content, encoding: 'base64'}));
    if (created.sha !== f.sha) throw new Error('Blob identity mismatch: ' + f.path);
    elements.push({path: f.path, mode: f.mode, type: f.type, sha: f.sha});
  }
  const tree = obj(await tools.mcp__codex_apps__github_create_tree({repository_full_name: repo, base_tree_sha: m.state.tree, tree_elements: elements}));
  if (tree.sha !== m.tree) throw new Error('Complete Git tree mismatch');
  const commit = obj(await tools.mcp__codex_apps__github_create_commit({repository_full_name: repo, parent_sha: m.state.remote, tree_sha: tree.sha, message: message + '\n\nLocal ' + m.head + '; identical complete Git tree ' + m.tree + '.'}));
  if (!/^[0-9a-f]{40}$/.test(commit.sha)) throw new Error('Invalid commit result');
  await tools.mcp__codex_apps__github_update_ref({repository_full_name: repo, branch_name: m.state.branch, expected_sha: m.state.remote, sha: commit.sha, force: false});
  const verified = obj(await tools.mcp__codex_apps__github_fetch({url: 'https://api.github.com/repos/' + repo + '/pulls/519'}));
  if (verified.head.sha !== commit.sha) throw new Error('Remote readback mismatch');
  return await save(commit.sha);
}
