# C1-LAYOUT-018 — unabhängige statische Aufnahme

## Urteil

Der begrenzte Drei-Dateien-Slice ist für C1s eigene Prüfung geeignet. Kein statischer Integrationsblocker gefunden. Die Änderung repariert die zu kleine berechnete Pill-Höhe, ohne den Mindestwert 48 dp zu senken, bestehende Tests zu ändern oder den HERO-Bereich zu verkleinern. Eine erfolgreiche Android-, Lint- oder Geräteabnahme wird damit nicht behauptet.

## Unveränderliche Quelle und Basis

- PR #524: `235d764f790dee7685c6590cf0a5d07d1fafdce2`, über den GitHub-Connector erneut gelesen.
- Produktionscommit: `652e6e30e63a427546c6a30988906c351406be25`. Dessen Commitdiff enthält ausschließlich `ContinuumLandscapeCockpitLayout.kt`, fünf hinzugefügte und eine entfernte Zeile.
- Eigene Aufnahmebasis C1: `cdea744bc431d56cead71dc6dcbfa287d1903aeb`, Tree `f3827a14469f15088bb1eb64e5d98494aebf850c`; Checkout bei Aufnahme sauber.
- Layout-Basisblob: `6acb79eaf1b90d49037acdfd4a7245e1119a271c`; Zielblob: `245c8c94abdadbe065138561d2c9a2901456b3c2`.
- Alle sechs im fremden Quellmanifest genannten ursprünglichen Geometrieblobs entsprechen C1. Die fünf anderen Geometriequellen sind auch am #524-Head bytegleich; nur der Layoutblob ändert sich. Alle zehn über die PR-Dateiliste gelieferten Quell-/Test-/Evidenzdateien wurden unabhängig mit ihren Git-Blobs abgeglichen.

Der Snapshot enthält vollständige Basis- und Zielquellen, die unveränderte Originaltestklasse sowie Handoff, Quellbindung und die beiden fremden Host-Logs. `upstream-provenance.json` enthält die tatsächlich gelesenen GitHub-Quellen einschließlich Kommentar #6642062089.

## Mechanik und erhaltene Anforderungen

Der alte Ausdruck berechnet `avatar.top + TARGET` als Float. Bei der belegten Konfiguration 832×700/font1 ergibt die spätere Differenz eine Höhe von 47,999996185302734 dp. Der neue gemeinsame `pillBottom` behält den bisherigen Wert bei, sofern `bottom - avatar.top >= TARGET`; nur bei Unterschreitung folgt `Math.nextUp(bottom)`. Alle drei Präsentations-Pills nutzen diesen einen unteren Rand. Links-/Rechts-/Oberkanten, `TARGET = 48f`, `Box.height`, Shell-Aufteilung, Auswahl der Layoutvariante und HERO-Ausdruck bleiben unverändert.

Damit ist die Anpassung auf den tatsächlichen Rundungsfehler begrenzt. Bereits ausreichend hohe Pill-Rechtecke erhalten dieselben Bits. Die getrennte HERO-Unterteilung verwendet weiterhin den unveränderten Ausdruck `avatar.top + TARGET + 6f`; der Fix kann deshalb die HERO-Bounds im Quellcode nicht verschieben. Ein um einen Float-Schritt kleinerer Zwischenraum unter den betroffenen Pills ist die unmittelbare geometrische Folge.

`ContinuumLandscapeCockpitLayoutTest.kt` ist zwischen C1 und #524 vollständig bytegleich. Seine vier Testmethoden bleiben erhalten: Auswahl der Landschaftsvariante und Ausschluss anderer Formate, strenge Mindestgrößen/Position/Überlappung, Komposition mit freiem Avatarbereich sowie ehrliche Darstellung fehlender Zustandsdaten. Die strikte Assertion `b.width >= 48f && b.height >= 48f` bleibt unverändert.

Die zwei neuen Testdateien ergänzen drei JUnit-Methoden: `fractionalTargetsRemainAtLeast48Dp`, `legacyWindowsRetainStrictGeometry`, `avatarBoundsRemainBitIdentical`. Die gemeinsam mit dem Host-Runner verwendeten Checks prüfen die direkte Regression, fünf Fenster mit zwei Schriftfaktoren einschließlich Überlappung und zehn eingefrorene HERO-Bounds mittels `toRawBits()`. Es gibt keine neuen Skip-Regeln, keine abgesenkten Zielmaße und keine Änderung der ursprünglichen Assertions.

Die ausgelagerten Host-Konstanten stimmen mit den aktuellen Produktionsdefinitionen überein: gap 10, margin 13, inputBarHeight 52, Rail-Faktor .147, Mindestbreite 14+108 und Maximalbreite 168. `ConstantsOnly.kt` bleibt ausschließlich unter Evidenz und gehört nicht zum Produktionspatch.

## Belege und Grenzen

Die fremden, unveränderlich archivierten Logs enthalten RED: zwei FAIL/ein PASS und GREEN: drei PASS. Quellmanifest und Handoff berichten dazu Exit 1 beziehungsweise 0. Die Logs enthalten selbst keinen Prozess-Exit-Footer; es handelt sich um fremde Host-Kotlin-Belege, nicht um meinen eigenen Lauf. Der Host ersetzt nur sechs Konstanten; er umfasst weder Android/JUnit-Ausführung noch native Darstellung.

Die Angabe „270 verglichene Boxen, drei veränderte Pill-Unterkanten, zehn identische HERO-Bounds“ steht in Quellmanifest/Handoff. Der vollständige `GeometryProbe.kt` und der rohe 270-Box-Dump sind nicht Teil der zehn committed PR-Dateien. Dieser Zahlenvergleich wurde daher hier nicht unabhängig reproduziert. Die konkrete Produktionsbegrenzung auf die drei Pill-Unterkanten und der unveränderte HERO-Ausdruck wurden statisch geprüft.

Eigene Builds und Tests: **NOT_RUN**. C1 muss auf dem endgültigen kombinierten Tree zunächst die vier ursprünglichen und die drei neuen Layout-Testmethoden sowie anschließend die vollständige konfigurierte Android-Suite und NewApi-Lint ausführen. Bereits bestehende andere Vollgate-Fehler werden durch diesen Slice nicht für behoben erklärt. Keine GPU-, Geräte-, APK- oder Releasefreigabe.

## Tatsächliche eigene Prüfungen

Read-only Git-Quellabfragen, gezieltes Lesen der echten Produktions- und Testdateien sowie GitHub-Connector-Reads. Ein Python-Skript hat die Git-Blobs und SHA256-Werte neu berechnet, die sechs Basisgeometrien und unveränderte Originaltestklasse abgeglichen und ausschließlich diesen eigenen Snapshot geschrieben; Exit 0. Danach:

```
cd /workspace/scratch/174c84456ee3/repair-review/layout018/base
git apply --check /workspace/scratch/174c84456ee3/repair-review/layout018/C1-LAYOUT-018.patch
```

Ergebnis: Exit 0. Das ist eine statische Anwendbarkeitsprüfung in der eigenen Basiskopie; der Patch wurde nicht im C1-Checkout angewendet. Keine fremden Prozesse oder Locks wurden verändert.

## Patch und Rückfall

`C1-LAYOUT-018.patch`, SHA256 `eab1da6e6ed461b068ce90a4d652fc958a840e2c1441bd3c08918e0dba98023a`, enthält genau einen Produktionspfad und zwei neue Testpfade. Kein vollständiger Fremdbranch und keine weiteren #524-/#522-Änderungen sind enthalten.

Bei abweichendem Basisblob vor Übernahme erneut abgleichen. Rückfall: ausschließlich diesen kleinen Layout-/Test-Slice zurücknehmen; dadurch kehrt der dokumentierte alte Rundungsfehler zurück. Negative Ergebnisse und Herkunftsbelege erhalten. Kein Reset des C1-Branches.
