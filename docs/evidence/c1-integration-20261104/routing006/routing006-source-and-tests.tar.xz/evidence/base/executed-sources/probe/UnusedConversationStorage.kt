package at.heinz.deviceai.chief

// Empty-history shape needed by the unchanged profile store. Actual codecs
// deliberately cannot run in this metadata/routing-only probe.
data class ChiefBotConversationHistory(val turns: List<String>, val discardedTurns: Long)
data class ChiefBotConversationSnapshot(
    val profile: ChiefBotProfile, val workingContext: String?, val history: ChiefBotConversationHistory
)
object ChiefBotConversationCodec {
    const val MAX_BYTES = 64 * 1024
    fun encode(profile: ChiefBotProfile, history: ChiefBotConversationHistory): ByteArray =
        error("Conversation encoding is outside the routing probe")
    fun decode(profile: ChiefBotProfile, bytes: ByteArray): ChiefBotConversationHistory =
        error("Conversation decoding is outside the routing probe")
}
