package at.heinz.deviceai.cognitive

// Compile-only boundaries for methods outside this metadata/routing probe.
// Every operation throws: the probe must exercise the real profile file store,
// and must not claim to test conversation-object storage.
data class ContinuumObjectId(val value: String) {
    companion object {
        fun of(type: ContinuumObjectType, payload: ByteArray): ContinuumObjectId =
            error("Object-storage path is outside the routing probe")
    }
}
enum class ContinuumObjectType { TASK_CHECKPOINT }
data class ProbeObjectMetadata(val type: ContinuumObjectType)
data class ProbeStoredObject(val id: ContinuumObjectId, val metadata: ProbeObjectMetadata, val payload: ByteArray)
class FileContinuumObjectStore(directory: java.io.File, maxBytes: Int, storeBytes: Long) {
    fun put(type: ContinuumObjectType, payload: ByteArray): ProbeStoredObject =
        error("Object-storage write is outside the routing probe")
    fun get(id: ContinuumObjectId): ProbeStoredObject? =
        error("Object-storage read is outside the routing probe")
}
