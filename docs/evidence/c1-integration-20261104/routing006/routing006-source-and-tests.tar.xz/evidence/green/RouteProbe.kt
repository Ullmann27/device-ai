package at.heinz.deviceai

import at.heinz.deviceai.chief.ChiefBotProfile
import at.heinz.deviceai.chief.ChiefBotProfileStore
import at.heinz.deviceai.chief.ChiefBotConversationHistory

class ProbeText {
    var value = ""
    fun clear() { value = "" }
    override fun toString() = value
}
class ProbeInput {
    val text = ProbeText()
    fun setText(value: String) { text.value = value }
}
class ProbeExecutor {
    var isShutdown = false
    private val jobs = ArrayDeque<Runnable>()
    fun execute(job: Runnable) {
        if (isShutdown) throw java.util.concurrent.RejectedExecutionException()
        jobs.addLast(job)
    }
    fun drain() { while (jobs.isNotEmpty()) jobs.removeFirst().run() }
}
object Toast {
    const val LENGTH_LONG = 1
    fun makeText(owner: RouteProbe, message: String, duration: Int) = ProbeToast(owner, message)
}
class ProbeToast(private val owner: RouteProbe, private val message: String) {
    fun show() { owner.toasts += message }
}

// Only collaborators at the Activity method's boundaries are controlled.
// routeBotInput itself is appended byte-for-byte from the selected source.
class RouteProbe(val botProfiles: ChiefBotProfileStore) {
    val input = ProbeInput()
    val backlogExecutor = ProbeExecutor()
    var selectedBot: ChiefBotProfile? = null
    var botLookupPending = false
    var botLookupRevision = 0
    var busy = false
    var isFinishing = false
    var isDestroyed = false
    val toasts = mutableListOf<String>()
    val ordinary = mutableListOf<Pair<String, Boolean>>()
    val privateTurns = mutableListOf<Pair<String, String>>()
    val selections = mutableListOf<String>()
    private val ui = ArrayDeque<() -> Unit>()
    fun runOnUiThread(job: () -> Unit) { ui.addLast(job) }
    fun cancelSpeechInputScope() = Unit
    fun returnToJarvis() { selectedBot = null }
    fun selectBot(agentId: String) { selections += agentId }
    fun enterBotConversation(profile: ChiefBotProfile) { selectedBot = profile }
    fun showBotHistory(profile: ChiefBotProfile, history: ChiefBotConversationHistory) = Unit
    fun runBotDialogue(profile: ChiefBotProfile, request: String) { privateTurns += profile.agentId to request }
    fun sendCurrentInput(botRoutingChecked: Boolean) { ordinary += input.text.toString() to botRoutingChecked }
    fun route(request: String): Boolean = routeBotInput(request)
    fun flush() {
        backlogExecutor.drain()
        while (ui.isNotEmpty()) ui.removeFirst().invoke()
    }

    private fun routeBotInput(request: String): Boolean {
        val address = at.heinz.deviceai.chief.ChiefBotAddressRouter.parse(request)
        if (address is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Jarvis) {
            returnToJarvis()
            input.setText(address.text.orEmpty())
            if (address.text != null) sendCurrentInput(botRoutingChecked = true)
            return true
        }
        if (address == null && selectedBot == null) return false
        if (botLookupPending || backlogExecutor.isShutdown) return true
        cancelSpeechInputScope()
        botLookupPending = true
        val revision = ++botLookupRevision
        try { backlogExecutor.execute {
            val found = runCatching {
                botProfiles.seedDefaults(20)
                val profile = when (address) {
                    is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Select ->
                        at.heinz.deviceai.chief.ChiefBotAddressRouter.resolve(botProfiles, address.name)
                    is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Message ->
                        at.heinz.deviceai.chief.ChiefBotAddressRouter.resolve(botProfiles, address.name)
                    else -> selectedBot?.agentId?.let(botProfiles::get)
                }
                profile to if (profile != null && selectedBot?.agentId != profile.agentId &&
                    address is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Message)
                    botProfiles.loadConversation(profile.agentId, profile.agentId) else null
            }
            runOnUiThread {
                botLookupPending = false
                if (revision != botLookupRevision || isFinishing || isDestroyed) return@runOnUiThread
                if (busy || input.text.toString() != request) return@runOnUiThread
                if (found.isFailure) {
                    Toast.makeText(this, "Bot-Zuordnung unklar oder nicht lesbar. Bitte über Team auswählen.", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val (profile, history) = found.getOrThrow()
                if (profile == null) {
                    // A successful lookup with no bot leaves natural selection syntax as ordinary text.
                    // Lookup failures above and explicit mentions still fail closed.
                    if (request.trimStart().startsWith("@") ||
                        (address is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Select &&
                            address.name.startsWith("@"))) {
                        Toast.makeText(this, "Diesen Bot finde ich nicht. Bitte Namen prüfen oder über Team auswählen.", Toast.LENGTH_LONG).show()
                    } else if (selectedBot != null) {
                        input.text.clear(); runBotDialogue(selectedBot!!, request)
                    } else sendCurrentInput(botRoutingChecked = true)
                    return@runOnUiThread
                }
                input.text.clear()
                if (address is at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Select) {
                    selectBot(profile.agentId)
                    return@runOnUiThread
                }
                if (selectedBot?.agentId != profile.agentId) {
                    enterBotConversation(profile)
                    history?.let { showBotHistory(profile, it) }
                }
                else selectedBot = profile
                val text = (address as? at.heinz.deviceai.chief.ChiefBotAddressRouter.Address.Message)?.text ?: request
                runBotDialogue(profile, text)
            }
        } } catch (_: java.util.concurrent.RejectedExecutionException) { botLookupPending = false }
        return true
    }

}
