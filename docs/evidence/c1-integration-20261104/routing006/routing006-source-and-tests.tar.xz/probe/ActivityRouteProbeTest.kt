package at.heinz.deviceai

import at.heinz.deviceai.chief.ChiefBotProfileStore
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ActivityRouteProbeTest {
    private fun fixture(body: (RouteProbe, File) -> Unit) {
        val directory = Files.createTempDirectory("routing006-").toFile()
        try {
            val store = ChiefBotProfileStore(directory)
            store.seedDefaults(20)
            body(RouteProbe(store), directory)
        } finally { directory.deleteRecursively() }
    }

    private fun submit(probe: RouteProbe, request: String) {
        probe.input.setText(request)
        assertTrue(probe.route(request))
        probe.flush()
    }

    private fun assertBlocked(probe: RouteProbe, request: String) {
        assertTrue(probe.ordinary.isEmpty())
        assertTrue(probe.privateTurns.isEmpty())
        assertTrue(probe.selections.isEmpty())
        assertEquals(request, probe.input.text.toString())
        assertEquals(1, probe.toasts.size)
    }

    @Test fun unknownModeSelectionReachesOrdinaryInputOnceWithOriginalText() = fixture { probe, _ ->
        val request = "  wechsle zu dunklem Modus  \n"
        submit(probe, request)
        assertEquals(listOf(request to true), probe.ordinary)
        assertTrue(probe.privateTurns.isEmpty())
        assertTrue(probe.selections.isEmpty())
        assertTrue(probe.toasts.isEmpty())
    }

    @Test fun ordinaryTalkSelectionReachesOrdinaryInputOnce() = fixture { probe, _ ->
        val request = "sprich mit mir über den Plan"
        submit(probe, request)
        assertEquals(listOf(request to true), probe.ordinary)
        assertTrue(probe.privateTurns.isEmpty())
        assertTrue(probe.toasts.isEmpty())
    }

    @Test fun unknownSelectionKeepsTheSelectedPrivateConversation() = fixture { probe, _ ->
        val selected = requireNotNull(probe.botProfiles.get("bot-kora"))
        probe.selectedBot = selected
        val request = "  sprich mit mir über den Plan  "
        submit(probe, request)
        assertEquals(listOf("bot-kora" to request), probe.privateTurns)
        assertSame(selected, probe.selectedBot)
        assertTrue(probe.ordinary.isEmpty())
        assertTrue(probe.selections.isEmpty())
        assertTrue(probe.toasts.isEmpty())
    }

    @Test fun knownSelectionsStillSelectTheResolvedBotWithoutRunningTheText() {
        for (request in listOf("rufe Kora auf", "sprich mit Kora", "wechsle zu bot-kora")) fixture { probe, _ ->
            submit(probe, request)
            assertEquals(listOf("bot-kora"), probe.selections)
            assertTrue(probe.ordinary.isEmpty())
            assertTrue(probe.privateTurns.isEmpty())
            assertTrue(probe.toasts.isEmpty())
        }
    }

    @Test fun unknownExplicitMentionIsNeverAdmittedAsOrdinaryInput() = fixture { probe, _ ->
        val request = "  @Unbekannt Prüfe den Status."
        submit(probe, request)
        assertBlocked(probe, request)
    }

    @Test fun explicitMentionInsideNaturalSelectionStaysBlocked() {
        for (request in listOf("wechsle zu @Unbekannt", "sprich mit @Unbekannt", "rufe @Unbekannt auf")) fixture { probe, _ ->
            submit(probe, request)
            assertBlocked(probe, request)
        }
    }

    @Test fun ambiguousNameIsNeverAdmittedAsOrdinaryInput() = fixture { probe, _ ->
        probe.botProfiles.create("bot-duplicate", "KORA", "Review", "Präzise")
        val before = probe.botProfiles.page(limit = 100).items
        val request = "wechsle zu Kora"
        submit(probe, request)
        assertBlocked(probe, request)
        assertEquals(before, probe.botProfiles.page(limit = 100).items)
    }

    @Test fun corruptRegistryIsNeverTreatedAsAnUnknownName() = fixture { probe, directory ->
        val damaged = byteArrayOf(0)
        val registry = File(directory, "bot-profiles-v1.bin")
        registry.writeBytes(damaged)
        val request = "wechsle zu dunklem Modus"
        submit(probe, request)
        assertBlocked(probe, request)
        assertTrue(damaged.contentEquals(registry.readBytes()))
    }

    @Test fun changedDraftRejectsTheLateFallback() = fixture { probe, _ ->
        val request = "wechsle zu dunklem Modus"
        probe.input.setText(request)
        assertTrue(probe.route(request))
        val replacement = "Diesen neuen Entwurf nicht absenden."
        probe.input.setText(replacement)
        probe.flush()
        assertEquals(replacement, probe.input.text.toString())
        assertTrue(probe.ordinary.isEmpty())
        assertTrue(probe.privateTurns.isEmpty())
        assertTrue(probe.selections.isEmpty())
    }
}
