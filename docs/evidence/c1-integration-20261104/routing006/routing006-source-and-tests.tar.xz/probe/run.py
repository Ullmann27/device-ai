#!/usr/bin/env python3
"""Compile unchanged real routing/store bytes and the extracted Activity method.

This is an isolated caller probe, not a Robolectric/Android build. Only Activity
collaborators and unused conversation-object storage boundaries are test doubles.
All outputs stay inside routing006; shared toolchain inputs are read only.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VARIANT = sys.argv[1]
if VARIANT not in {"base", "candidate"}:
    raise SystemExit("Usage: run.py base|candidate")
SOURCE = ROOT / VARIANT
LABEL = sys.argv[2] if len(sys.argv) > 2 else VARIANT
if not LABEL or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in LABEL):
    raise SystemExit("Evidence label must use lowercase letters, digits and hyphens")
OUT = ROOT / "evidence" / LABEL
OUT.mkdir(parents=True, exist_ok=False)
ACTIVITY = "app/src/main/java/at/heinz/deviceai/AgentActivity.kt"
ROUTER = "app/src/main/java/at/heinz/deviceai/chief/ChiefBotAddressRouter.kt"
STORE = "app/src/main/java/at/heinz/deviceai/chief/ChiefBotProfileStore.kt"
TEST = "app/src/test/java/at/heinz/deviceai/chief/ChiefBotAddressRouterTest.kt"
text = (SOURCE / ACTIVITY).read_text()
start = text.index("    private fun routeBotInput(request: String): Boolean {")
end = text.index("    private fun runBotDialogue(", start)
method = text[start:end]
generated = OUT / "RouteProbe.kt"
generated.write_text((ROOT / "probe/RouteProbePrefix.kt.txt").read_text() + method + "}\n")

deps = Path("/workspace/scratch/18845e31bc4a/host-qa/compiler-deps")
classpath = ":".join(str(deps / name) for name in [
    "kotlin-stdlib-2.4.0.jar", "junit-4.13.2.jar", "hamcrest-core-1.3.jar", "annotations-23.0.0.jar"
])
classes = OUT / "classes"
classes.mkdir(exist_ok=True)
sources = [SOURCE / ROUTER, SOURCE / STORE, ROOT / "candidate" / TEST, generated,
           ROOT / "probe/UnusedObjectStorage.kt", ROOT / "probe/UnusedConversationStorage.kt",
           ROOT / "probe/ActivityRouteProbeTest.kt"]
compiler = "/workspace/scratch/18845e31bc4a/regression-audit/real-kotlinc/bin/kotlinc"
compile_cmd = [compiler, "-no-stdlib", "-no-reflect", "-jvm-target", "17", "-classpath", classpath,
               "-d", str(classes), *map(str, sources)]
compiled = subprocess.run(compile_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=60)
(OUT / "compile.log").write_text(compiled.stdout)
result = {"variant": VARIANT, "activityMethodSha256": hashlib.sha256(method.encode()).hexdigest(),
          "sourceSha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
          "compileCommand": compile_cmd, "compileExit": compiled.returncode,
          "scope": "Isolated actual-method caller probe and real Router/ProfileStore metadata tests; no Android build"}
if compiled.returncode != 0:
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(compiled.stdout)
    raise SystemExit(compiled.returncode)
java = "/workspace/scratch/b6ee64d418cf/toolchain/jdk17/bin/java"
test_cmd = [java, "-Xms32m", "-Xmx256m", "-cp", str(classes) + ":" + classpath,
            "org.junit.runner.JUnitCore", "at.heinz.deviceai.chief.ChiefBotAddressRouterTest",
            "at.heinz.deviceai.ActivityRouteProbeTest"]
tested = subprocess.run(test_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
(OUT / "junit.log").write_text(tested.stdout)
result.update({"testCommand": test_cmd, "testExit": tested.returncode})
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(tested.stdout)
raise SystemExit(tested.returncode)
