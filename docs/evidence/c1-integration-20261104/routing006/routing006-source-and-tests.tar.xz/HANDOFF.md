# C1-ROUTING-006 — vorbereiteter Patch, GREEN ausstehend

Status: **LOCAL_ONLY / NOT_PUSHED. C1 ist der einzige Einbauer.**

Der Patch verändert genau drei Dateien: einen kleinen Zweig in
`app/src/main/java/at/heinz/deviceai/AgentActivity.kt` und Ergänzungen der
bestehenden `ChiefBotAddressRouterTest` und `ContinuumBotTaskRoutingUiTest`.
Router und Profilspeicher bleiben in der Produktion bytegleich.

## Basis und Einbaugrenze

Die eingefrorene Basis ist `8873030fdfe23bdd4153f96004b786bff2cddecf`.
Beim letzten Dateivergleich am C1-HEAD
`0dac310728a84bd1adc296377ed7d124bc09692a` waren alle fünf gelesenen
Basisdateien weiterhin bytegleich. `base-manifest.json` nennt ihre vollständigen
SHA-256- und Git-Blob-Hashes; `patch-manifest.json` enthält zusätzlich die
Kandidaten-Hashes und den Hash des Patches.

Activity-Basisblob: `c1482ed3be0cb91734e10947613ec62d1a3c38cb`.
Activity-Kandidatenblob: `bc1a08495f56696b2f0a6613260beb92bb3dbc62`.

`git apply --check --whitespace=error-all` wurde gegen den echten C1-Checkout
erfolgreich ausgeführt. Der Patch wurde dort **nicht angewendet**. Vor einem
späteren Einbau muss C1 die inzwischen aktuellen Bytes erneut vergleichen.

## Verhalten

Der Resolver bleibt unverändert. Erst wenn `runCatching` erfolgreich ist und
`profile == null` zurückkommt, darf eine unbekannte natürliche Auswahlformulierung
den vorhandenen Textpfad erreichen:

- Ohne ausgewählten Bot: `sendCurrentInput(botRoutingChecked = true)` mit der
  vorhandenen vollständigen Eingabe. Kein erneuter Durchlauf durch den Botrouter.
- Mit ausgewähltem Bot: der bestehende private Dialogpfad mit dem ursprünglichen
  Text; die Auswahl wird nicht heimlich zu JARVIS geändert.
- Bekannter Bot: der bestehende `selectBot`-Zweig bleibt unverändert.
- Mehrdeutiger Name, beschädigte Registry oder anderer Lookup-Fehler: der
  vorhandene `found.isFailure`-Abbruch bleibt vor dem Fallback.
- Unbekannte explizite `@`-Nachricht bleibt blockiert. Auch ein explizit markiertes
  Select-Ziel wie `wechsle zu @Unbekannt`, `sprich mit @Unbekannt` oder
  `rufe @Unbekannt auf` bleibt blockiert. Der Parser liefert diese Zielnamen mit
  führendem `@`; dieses Merkmal wird im null-Profil-Zweig erhalten.
- Revision, Busy-Zustand, Activity-Lebensdauer und unveränderte Eingabe werden
  weiter vor der Übergabe geprüft.

Die Änderung verleiht keine neuen Werkzeugsrechte und ersetzt keinen ToolGate.
Sie behebt die bisherige vorzeitige Übernahme durch einen reinen Toast.

## Tatsächlich ausgeführte Prüfungen

### RED vor der Produktionsänderung

`python3 probe/run.py base` führte einen echten Kotlin-2.4/JVM-17-Compile und
JUnit 4.13.2 aus. Compiler-Exit 0, Compiler-Log leer. JUnit: **25 Tests,
22 PASS, 3 FAIL**. Die drei erwarteten Fehler sind:

1. `unknownModeSelectionReachesOrdinaryInputOnceWithOriginalText`
2. `ordinaryTalkSelectionReachesOrdinaryInputOnce`
3. `unknownSelectionKeepsTheSelectedPrivateConversation`

Jeweils blieb der erwartete Aufruf des gewöhnlichen beziehungsweise privaten
Textpfads aus. Das ist der belegte Fehler, kein Compiler- oder Fixture-Abbruch.
Rohbelege: `evidence/base/compile.log`, `evidence/base/junit.log` und
`evidence/base/result.json`. Die ausgeführten Quellbytes sind zusätzlich unter
`evidence/base/executed-sources/` mit den im ursprünglichen Ergebnis erfassten
Hashes gesichert.

### Was die isolierte Probe wirklich ausführt

- Den Originaltext von `routeBotInput` aus der ausgewählten Activity-Datei,
  unverändert zwischen einem Testgerüst und der abschließenden Klassenklammer.
- Den tatsächlichen `ChiefBotAddressRouter`, seinen Resolver und den
  tatsächlichen `ChiefBotProfileStore` für Profilanlage, Metadatenserialisierung,
  Paging, Namensauflösung und beschädigte Registry-Dateien.
- Die bestehenden Router-Tests einschließlich der damals drei neuen Tests.

Testdoubles sind die UI-Grenzen, deterministische Executor-/UI-Warteschlangen,
Toast sowie die Aufrufziele für gewöhnlichen Text, privaten Dialog und Auswahl.
Die Probe zeichnet die tatsächlich gewählten Aufrufe und ihren vollständigen
Text auf; sie führt diese nachgelagerten Android-/Modellpfade nicht aus.
Unbenutzter Conversation-Objektspeicher und Codec sind reine Compile-Grenzen,
deren Operationen bei einem Aufruf absichtlich fehlschlagen. Es gibt daraus
keinen Nachweis für Conversation-Objektspeicherung, echte Threads, Android-UI,
Gerät oder Modellinferenz.

### Ausstehende Prüfungen und Lock-Blockaden

Zwei spätere Aufrufe konnten die gemeinsamen Locks nicht erwerben; sie starteten
keinen Compiler und erzeugten keine Kandidaten-Evidenz:

- Erster Versuch: Exit 1, ohne Compiler-/JUnit-Ausgabe.
- Zweiter Versuch mit eindeutigem Conflict-Exit-Code: Exit 75, ebenfalls ohne
  Compiler-/JUnit-Ausgabe.

Lock-Dateien:

- `/workspace/scratch/b6ee64d418cf/toolchain/gradle-build.lock`
- `/workspace/scratch/d663e8444310/qa/gradle.lock`

Keine Locks wurden gelöscht und keine fremden Prozesse verändert. Auf C1-Auftrag
wurden weitere Erwerbsversuche beendet. **GREEN ist NOT_RUN**, nicht FAIL.

Nach dem RED wurden noch ein Router-Test und ein Probe-Test für die ausdrücklich
mit `@` markierten Select-Ziele ergänzt. Der aktuelle isolierte Testbestand
umfasst deshalb 27 Tests; dieser vollständige aktuelle Bestand ist noch nicht
ausgeführt. Auch die aktuelle Activity-Änderung ist noch nicht kompiliert.

Die sechs zusätzlichen Robolectric-Methoden in
`ContinuumBotTaskRoutingUiTest` sind **NOT_RUN / NOT_COMPILED**. Sie prüfen
gewöhnliche Eingabe, Beibehaltung des privaten Bots, explizite Adressen,
Mehrdeutigkeit, beschädigte Registry und einen inzwischen geänderten Entwurf.
Die ersten beiden Tests deaktivieren den Modell-Executor absichtlich und prüfen
die tatsächliche Activity-Aufnahmegrenze. Das ist kein Modelltest.

## Nächster serieller Schritt für C1

Nach Review und in einem tatsächlich freien Compilerfenster kann C1 zunächst die
isolierte Kandidatenprobe unter beiden Locks ausführen:

```sh
flock --exclusive --wait 20 --conflict-exit-code 75 /workspace/scratch/b6ee64d418cf/toolchain/gradle-build.lock \
  flock --exclusive --wait 20 --conflict-exit-code 75 /workspace/scratch/d663e8444310/qa/gradle.lock \
  python3 probe/run.py candidate green
```

Arbeitsverzeichnis ist dieses `routing006`-Verzeichnis. Zwei begrenzte Wartezeiten
ergeben zusammen höchstens 40 Sekunden für den Erwerb. Der Probe-Runner legt
seine Ausgabe ausschließlich hier an und lehnt das Überschreiben einer schon
vorhandenen Evidenzbezeichnung ab. Das gemeinsame Compilerverzeichnis wird nur
gelesen.

Anschließend benötigt der tatsächliche Activity-/Robolectric-Weg die beiden
Testklassen `at.heinz.deviceai.chief.ChiefBotAddressRouterTest` und
`at.heinz.deviceai.ContinuumBotTaskRoutingUiTest` im bestehenden Android-QA-Aufbau.
Keine vollständige Android-, Gradle-, APK- oder Geräteabnahme wurde hier begonnen.

Ein Rückbau betrifft ausschließlich den geänderten null-Profil-Zweig und die
zugehörigen Testergänzungen. Nach weiteren Activity-Änderungen keine vollständige
alte Activity-Datei über den aktuellen Stand kopieren.
