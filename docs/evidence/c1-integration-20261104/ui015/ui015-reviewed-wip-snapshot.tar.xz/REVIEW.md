# C1-UI-FIXTURE-015 — statischer WIP-Review und eigener Snapshot

Status: **STATIC WIP CANDIDATE / C1 EXECUTION REQUIRED.** Der unveränderte externe Entwurf wird als begrenzter C1-Prüfschritt aufgenommen. Er wird weder als extern abgeschlossener Fix noch als extern freigegeben ausgegeben. C2 extern bleibt PENDING.

## Quellen und unveränderter Umfang

C1-Basis: `38917560671b13795bf85d5a68d329658ba4eb7d`, Tree `687fe9a8267cb0cd8546acc7818f66fdbf3a1891`.

Ursprung: `/workspace/scratch/18845e31bc4a/build-audit/ui-fullsuite-harness/ui-fullsuite-harness.patch`, dort ausgewiesene Basis `f17ee62f8cfda8914ed217fe2ed88882ba1fa8a4`.

Die eigene Kopie `C1-UI-FIXTURE-015.patch` hat exakt denselben SHA-256:

`4897b424eec14a6c92ce87dfbc1d0b86cba868d362e3929558fd0cb0cdb1f575`

Alle vier C1-Basisdateien stimmen mit den im externen Manifest festgehaltenen Vorzustands-Hashes überein. Die Patch-Hunks wurden im Arbeitsspeicher ohne Fuzz auf diese festen Basisbytes angewendet. Die resultierenden Bytes stimmen mit sämtlichen vier vorbereiteten Zieldateien und ihren angegebenen SHA-256 überein. `base/` und `target/` sichern diese Bytes; `manifest.json` enthält vollständige Basis-/Zielblobs, SHA-256, Modi, Größen und Herkunft. Die Zielblobs sind berechnete Inhaltskennungen des WIP; es wird kein Zielcommit erfunden.

Der Patch verändert **vier UI-Testdateien und fünf Testklassen**, insgesamt +129/-19 Zeilen. Produktionspfade: **0**.

## Fünf verbindlich zu prüfende Klassen

| Vollqualifizierter Name | Testmethoden | Assertion-Aufrufe vorher/nachher |
|---|---:|---:|
| at.heinz.deviceai.ContinuumReferenceCockpitUiTest | 8 | 76 / 76 |
| at.heinz.deviceai.ContinuumTaskEffectsUiTest | 3 | 20 / 26 |
| at.heinz.deviceai.ContinuumTaskEffectsCallerUiTest | 5 | 20 / 25 |
| at.heinz.deviceai.JarvisShellStageUiTest | 3 | 13 / 13 |
| at.heinz.deviceai.JarvisAvatarSlotUiTest | 1 | 7 / 7 |
| Gesamt | 20 | 136 / 147 |

Die letzten beiden Klassen stehen gemeinsam in `JarvisShellStageUiTest.kt`. Der spätere C1-Fokus muss **beide** ausführen. `test-classes.txt` enthält die fünf vollständigen Namen.

Die Zählung erfasst vollständige Aufrufausdrücke, einschließlich vorhandener Assertion-Helferaufrufe, und überspringt Kommentare, Strings und Funktionsdeklarationen. Der externe einfache Textzähler nennt 138/149; er zählt zusätzlich die beiden unveränderten Helferdeklarationen `assertRealTargets` und `assertDialog`. Das ist keine entfernte Prüfung. Auch `@Test @Config(...)`-Methoden werden vollständig erfasst.

## Statisches Urteil

**Der Umfang ist als begrenzter C1-Prüfschritt vertretbar. Kein statischer Blocker gefunden; der Runtime-Erfolg ist offen.**

### ReferenceCockpit und VSync-Hypothese

Alle fünf Klassen ergänzen `@LooperMode(PAUSED)` sowie ein `@Before`, das den Choreographer bereits vor der Activity-Erzeugung pausiert und 16-ms-Frameabstände setzt. Das soll verhindern, dass der echte Avatar-Loop schon während Activity-Setup unbeschränkt virtuelle Zeit vorantreibt. `advanceFrames` reduziert einen endlichen Restwert bei jedem Schritt um höchstens 16 ms. Für die vorhandenen positiven Dauern bleibt die Gesamtdauer gleich.

`ContinuumReferenceCockpitUiTest` ändert seine vorhandenen acht Tests und Assertions nicht. Die bestehende echte Activity-/Window-Fixture bleibt bestehen; neu ist die kontrollierte VSync-Zeit und die Umleitung von `settle()` auf die begrenzte 40-ms-Fortschaltung. Die reale Fensterprüfung war hier bereits vorhanden. Das ist eine plausible Hypothese für den belegten Hänger, kein bereits nachgewiesener Erfolg dieses Patches.

### TaskEffects und tatsächlicher Fensterzustand

Die beiden TaskEffects-Klassen verwenden stabile LayoutParams und lassen den echten Fenster-Traversal ablaufen. Zusätzliche Assertions verlangen Attachment, Sichtbarkeit, tatsächliche Abmessungen und einen LIVE-Foreground-Takt; die bestehende Window-Visibility-Kontrolle im Caller bleibt erhalten. Manuelles Measure/Layout wird in diesen beiden Fixtures durch die geprüfte Fenstergröße ersetzt.

Die bisherigen Grenzen bleiben als vollständige Assertion-Ausdrücke erhalten: kein Effekt bei bloßem Busy/Proposal, echte Runner-Ankunft/-Beendigung, kein Backend und keine Ankunft bei abgelehntem Tool, Worker-Ankunft beim tatsächlichen Status-Worker, begrenztes Audiofeedback, stummes Feedback bei ausstehender Sprache, Darstellung über einem undurchsichtigen Kind sowie Verwerfen statt Nachspielen bei Pause, reduzierter Bewegung und Hitze.

### ShellStage und AvatarSlot

`JarvisShellStageUiTest` behält seine drei Darstellungsprofile. `JarvisAvatarSlotUiTest` behält den echten Registrierungs-/Docking-/Detach-Test und seine sieben Assertions, einschließlich Slot-Geometrie, Event-/State-Zustellung und Platzhalter nach Deregistrierung.

Die explizite Orb-Auswahl in den TaskEffects-Fixtures beziehungsweise `native-head=true, native-head-3d=false` im AvatarSlot-Test ist eine **Host-Fixture-Grenze**. Der AvatarSlot-Test verwendet weiterhin einen Fake-Renderer für seine beobachteten Registrierungs-/Dispatch-Aufrufe. Daraus entsteht kein Nachweis für natives Filament, GPU, Geräte-Rendering oder Modellinferenz.

## Vollständigkeit der erhaltenen Prüfungen

Für jede der fünf Klassen wurden alle ursprünglichen Testmethodennamen und die vollständigen ursprünglichen Assertion-Aufrufausdrücke verglichen. Keine ursprüngliche Assertion fehlt oder wurde ersetzt. Die beiden vorhandenen Assertion-Helferdeklarationen bleiben erhalten. Es kommen elf Assertion-Aufrufe hinzu. Der Patch fügt keine Ignore-/Assume-Klausel und keinen Testfilter hinzu.

Die vollständigen ursprünglichen Ausdrücke und Methodennamen stehen in `assertion-review.json`. Die Erhaltung von Assertions allein ist noch kein Beweis, dass die neuen Zeit-/Fenster-Fixtures unter C1 tatsächlich laufen.

## Gesicherter negativer Befund und offene Ausführung

`evidence/prior-external-timeout/` enthält unveränderte Kopien des bereits gesicherten externen Vollgate-Ergebnisses, der Summary und des Thread-Dump-Logs auf f17ee62. Ergebnis: **Exit 143**, Abbruch nach 180 Sekunden in `ContinuumReferenceCockpitUiTest#shortenedWideWindowKeepsEveryRailTargetScrollableAndClickable`, beendet am 2026-11-04 um 20:42:18 UTC.

Dieser Befund bleibt negativ. Er ist weder ein neuer RED auf C1 3891756 noch ein Lauf des hier vorbereiteten Patches. Dieses Paket enthält keinen positiven Laufnachweis für UI-FIXTURE-015 und keine vollständige Android-Abnahme.

## Eigene statische Prüfungen

Im eigenen `base/`:

```sh
git apply --check --whitespace=error-all ../C1-UI-FIXTURE-015.patch
```

Exit 0. Im eigenen `target/`:

```sh
git apply --reverse --check --whitespace=error-all ../C1-UI-FIXTURE-015.patch
```

Exit 0. `git apply --numstat C1-UI-FIXTURE-015.patch` nennt exakt vier UI-Testpfade. Diese Befehle wenden den Patch nicht an. Die Quelldateien wurden ausschließlich als eigener Scratch-Snapshot geschrieben. `static-validation.json` hält die Prüfungen fest; `SHA256SUMS` sichert das Paket.

## Serieller nächster Schritt

C1 gleicht nach seinem laufenden Prüfschritt die vier tatsächlichen Basisdateien mit dem Manifest ab, übernimmt den begrenzten Patch seriell und führt alle fünf Klassen auf dem festgehaltenen Kandidatenstand aus. Ergebnis, Exitcode, aktuelle XML und Quellenbindung müssen aus diesem eigenen Lauf stammen. Ein erwarteter Lauf ist kein GREEN. Bei weiteren Änderungen an den vier Dateien ist ein neuer Abgleich nötig; ein Rückbau darf nur die begrenzten Hunks betreffen.

Keine Repoänderung, kein Testlauf, kein Build und keine fremde Prozessaktion durch den Reviewer.

