# C1-PRIVACY-024 — #529 Intake und Readiness

**Der begrenzte Fachbeitrag ist mit gefrorenen Testbytes und tatsächlichem SDK-/UI-Nachweis bereit für C1s serielle Aufnahme. Diese Gegenprüfung hat keine Tests ausgeführt und überträgt das externe Ergebnis nicht auf C1.** Der ältere PR-Body ist WIP; maßgeblich ist der neu gelesene Final-Handoff/State am öffentlichen Carrier `00049e5c76b30e3a3587755a65ac6a30a693eb8a`, Status `SPECIALIST_GATE_PASS_READY_FOR_C1`.

## Quelle und genaue Aufnahme

Getestete öffentliche Quelle: `4a60c758fd31f5436401769d9ed91da646de815c`; lokaler Zwilling `c5e1a4f5cd8fd2c414cbac9d18a2cd7a9e563756`; vollständiger Tree `cf3f45bb3c59aa9bfc20d063c896d4d1d8a7d95d`; App-Tree `33f71427f63730aa56d4be838787620817f69f22`. Der folgende reine Belegcarrier hat denselben App-Tree. Die sieben Ziel-Dateien wurden zusätzlich einzeln über den GitHub-Connector am öffentlichen Carrier gelesen und mit den lokalen getesteten Bytes sowie dem Test-Quelleninventar verglichen.

C1-Vergleichsquelle ist `9a442485f2569b39be2bcd8d6687da6f6c15c45d`, Tree `8fe54137e976c718c91a4b3bbcfc02d50ca52bdd`. Alle drei schon bestehenden Slice-Dateien stimmen bytegenau mit #529s eingefrorener #522-Basis überein; die vier neuen Testpfade fehlen in dieser C1-Basis. Spätere unabhängige C1-UI-/Belegcommits verlangen vor der Aufnahme erneut den Vergleich dieser sieben Pfade, keinen vollständigen Fremdbranchimport.

| Produktionsdatei | C1-Basisblob | Exakter Zielblob |
|---|---|---|
| `app/src/main/java/at/heinz/deviceai/cognitive/AiContextCompiler.kt` | `beb0f37d8de8965984bf38846b6479e0137d2340` | `0e4718176518131828688092ea95e894a1d4c2fa` |
| `app/src/main/java/at/heinz/deviceai/cognitive/MemoryEcology.kt` | `1c3a7543ebaa826b0105002c8bfe5e23fa1c0c84` | `3368e6939061d259e9c8b8c6d419e3dc71cabcaf` |

Genau fünf Testpfade gehören dazu:

- `app/src/test/java/at/heinz/deviceai/cognitive/ContextCredentialBoundaryTest.kt`: 12 Methoden.
- `app/src/test/java/at/heinz/deviceai/cognitive/ContextCredentialHoldoutTest.kt`: 6 Methoden, darunter 180 tatsächlich durchlaufene Varianten im einen Matrixfall.
- `app/src/test/java/at/heinz/deviceai/cognitive/ContextCredentialFramingTest.kt`: 8 Methoden.
- `app/src/test/java/at/heinz/deviceai/cognitive/MemoryPrivacyPrecedenceTest.kt`: 8 Methoden.
- `app/src/test/java/at/heinz/deviceai/cockpit/CompiledMemoryOrbIntegrationTest.kt`: zwei neue Methoden; vier bestehende bleiben unverändert, insgesamt 6.

Der fünfklassige Fokus hat damit 40 definierte Methoden; dies ist eine Quellzählung, kein eigener Lauf. Die vollständigen Zielbytes liegen unter `target/`, die drei vorhandenen C1-Basisdateien unter `base/`. Alle Zielmodi sind `100644`. Blobs, SHA256 und sämtliche Methodennamen stehen im Abschlussmanifest.

## Quellbewertung

Der neue Redaktor entfernt ausdrücklich zugewiesene Bearer-/Basic-Werte einschließlich kurzer Token sowie korrekt geschlossene, auch mehrteilige oder maskierte quoted Werte. Er behält die bestehende eigenständige Bearer-Regel und verlangt bei einem begonnenen, nicht geschlossenen Credential-Wert einen Fehler `UNTERMINATED_CREDENTIAL_VALUE`. Der Holdout bewahrt unter anderem bisherige `x-token`-/`client-secret`-Fälle. Das ist ein begrenzter Erkenner, keine universelle Geheimnisdetektion.

`fullUntrusted` redigiert jetzt das einzelne rohe Feld **vor** der Darstellungssanitisierung. Dadurch kann ein eingefügtes `[U+000A]` nicht mit einer folgenden Negation als Credential verschluckt werden; ein offenes Zitat kann nicht erst im nächsten Datensatz geschlossen werden. Nur die drei vollständig feldweise verarbeiteten Gruppen `UNRESOLVED CONTRADICTIONS`, `RELEVANT MEMORY` und `RESEARCH EVIDENCE` verwenden `redact=false` beim anschließenden Zusammenbau. Die freien Felder werden vorher durch `fullUntrusted` geführt. Übrige Werte sind feste Labels, Enums, numerische Werte oder der in `ResearchSource` tatsächlich auf 64 Hexzeichen geprüfte Hash. Kein freies Feld wird durch diese drei Flags ungeprüft weitergereicht.

Die gesamte Section wird weiterhin atomar aufgenommen oder verworfen. Der Ausdruck zur UTF-8-Budgetprüfung und die Pflichtsection-Fehler bleiben erhalten. Die Recall-Beobachtung liegt weiterhin hinter erfolgreicher Kompilierung. Der ergänzte Orbtest verlangt tatsächlich ausgeschlossene sensitive Geräteinformationen, verschwundene Credentials, erhaltene Negation, genau einen Recall und den vorhandenen Hauptthread-Flush. Der zweite Fall verlangt bei defektem Credential keinerlei Recall-/Darstellungseffekt.

`MemoryWritePolicy.decide` ändert ausschließlich die Klassifikationsreihenfolge: ein wahrer Sensitivitätsmarker hat nun Vorrang vor Geräteinformation/-provenienz. Dauerhaftigkeit, Vertrauensschwelle und `shouldWrite`-Bedingungen bleiben unverändert. Die acht Fälle schließen auch echte ProofCarryingMemory-/Ledgerprüfungen mit synthetischem HMAC-Signer ein; sie sind keine AndroidKeyStore-Abnahme.

**Kein materieller Quellblocker innerhalb dieses abgegrenzten Fachbeitrags gefunden.**

## Originalbelege und unveränderte Regressionen

| Originaler Lauf | Getestete Quelle | Tatsächlicher Befund |
|---|---|---|
| initial-red | öffentlich `b40a3d8061203bcab5be7c6846f6ad39cadca508`, lokal `cbb528c…` | 20 Fälle: 4 PASS / 16 FAIL, Kompilierung 0, JUnit 1 |
| edge-holdout-before | öffentlich `410519751c3e40db96a5e4c3727ce8f4980467b1`, lokal `707a995…` | 6 Fälle: 5 PASS / 1 FAIL, Kompilierung 0, JUnit 1 |
| android-framing-red | öffentlich `36a7fe1fe0a69d62427e1cac6b32326cf8b9c071`, lokal `e510ce5…` | 92 Fälle: 91 PASS / 1 FAIL / 0 SKIP; die unveränderte Negationsassertion des Orbtests schlägt fehl; Lint nicht erreicht |
| framing-red | öffentlich `cca78329dc2ed3e97451f09c7507870f5b907a67`, lokal `ac0df517…` | 8 Fälle: 1 PASS / 7 FAIL, Kompilierung 0, JUnit 1 |
| framing-green | öffentlich `a717658b91c2f9703d8b6ab36bcdc7eb914cc589`, lokal `ce1a4be…` | 67 tatsächliche Hostfälle bestanden; keine frische Android-/Activity-Abnahme dieses Laufes |
| android-final | öffentlich `4a60c758…`, lokal `c5e1a4f5…` | **100 PASS / 0 FAIL / 0 ERROR / 0 SKIP, 15 Suites; Gradle 0, NewApi 0** |

Die ersten beiden neuen Testdateien sind seit dem initialen RED bytegleich; der sechsfallige Holdout seit seinem RED; die acht Framingfälle seit ihrem RED. Der gesamte Orbtest ist zwischen originalem SDK-FAIL und finalem SDK-GREEN bytegleich. Die beiden initialen RED-Produktionsdateien entsprechen auch der gelesenen C1-Produktionsbasis. Frühere und spätere Testgruppen überlappen; ihre Zahlen werden nicht addiert.

Finaler SDK-Lauf am 2026-11-04: **22:08:22.182528 bis 22:10:40.079736 UTC**, 137,786 Sekunden. Originalreceipt nennt beide gemeinsamen Sperren; Vor-/Nachinventare sind bytegleich. Gradle führte `testDebugUnitTest` tatsächlich aus; ein vorhandenes Init-Skript verhindert UP-TO-DATE für Testtasks, Buildcache ist ausgeschaltet. Alle 15 XMLs wurden einzeln gelesen und gezählt. Das tatsächliche Lint-XML enthält null Issues; `app/build.gradle.kts` begrenzt Lint auf `NewApi`.

- Finales Roharchiv: SHA256 `31b752397956b071076557a46c986b01151d2c07fa411a4752502cf6a8e11436`, 53.704 Byte, alle 21 enthaltenen Dateien gegen das öffentliche Manifest geprüft.
- Originales SDK-RED: vollständiges Roharchiv und alle 19 Mitglieder separat gesichert und geprüft.
- Die vier ausgewählten rohen Hostresultate/-logs/-quellenmanifeste wurden gegen die veröffentlichten Einzelhashes geprüft und unter `original-host-evidence/` gesichert.
- Die 1.084 Vor-/Nachinventareinträge wurden auf Gleichheit geprüft; die sieben Intake-Quellen zusätzlich individuell gegen Git/Connector. Dieser Review behauptet keine eigene Neuhashung sämtlicher übrigen Assets.

## Verbleibende C1-Arbeit

Zuerst den unveränderten Fünf-Dateien-Testpatch aufnehmen und den dadurch entstandenen sauberen Quellcommit binden. Dann den begrenzten eigenen RED ausführen, sofern der reguläre Slot verfügbar ist. Import-/Compile-/Umgebungsfehler wären kein fachlicher RED. Danach ausschließlich den Zwei-Dateien-Produktionspatch aufnehmen, neuen Quellcommit binden und den eigenen 15-Klassen-/100er-Fokus mit UI-Modus und NewApi-Lint ausführen. Die realen Befehle stehen separat; anschließend bleiben die vollständigen gemeinsamen Gates erforderlich.

Der aktuelle C1-Activity-Catch führt für `UNTERMINATED_CREDENTIAL_VALUE` weiterhin zum generischen Modellfehlertext; `setBusy(false)` folgt im vorhandenen Ablauf. C1 muss den neuen Kontextformatfehler gezielt und verständlich einordnen. Diese sieben Dateien verändern weder Activity noch den UI-Fehlerpfad. Auch bestehende Owner-Fakten werden nicht nachträglich neu klassifiziert; der Sensitivitätsmarker muss weiterhin vom Aufrufer korrekt gesetzt sein.

OPT021 bleibt ein eigener nachfolgender Schritt. Sein gespeicherter vollständiger Compilerzielblob `2aab35194170710b216f81b6ec886521ca767fbe` basiert auf `beb0f37…` und würde bei Ganzdateiersatz die neue Reparatur zurücksetzen. Ausschließlich den kleinen Bytezählerhunk nach dem Privacy-Slice semantisch neu ansetzen, Zielblob und Gates neu binden. Der eingefrorene OPT021-Originalpatch bleibt unverändert.

Der Spezialistenlauf umfasst SDK/JUnit und zwei angehängte Activity-/Robolectric-SDK28-Fälle. Er belegt keinen vollständigen Activity-Start-/Destroy-Zyklus, keine native GPU, kein echtes lokales Modell, keine Stimme, kein physisches Gerät, kein APK und keine Installation. Der zusätzliche 26er-Host-Bridge-Lauf wurde in diesem begrenzten Intake nicht erneut vollständig auditiert und wird nicht als neues C1-Ergebnis gezählt. Keine eigene Ausführung oder Repositoryänderung dieses Reviewers.
