# C1-PRIVACY-024 — reale Befehle für C1

**Nur vorbereitet; durch diesen Reviewer nicht ausgeführt.** Der UI020-V3-Schritt bleibt zuerst bei C1. Diese Befehle gelten erst nach der seriellen Aufnahme der jeweiligen unveränderten Patchhälfte und einem sauberen, gebundenen C1-Quellcommit.

Vorhandener Runner `/workspace/scratch/174c84456ee3/qa/run_c1_gate_v3.py`, SHA256 `209e4fe8bcb66c48590a69ac743750ba2a1943076af37ea01eb8204d659e7cdd`. Er verlangt einen sauberen Checkout, erwirbt die bestehenden b6- und d663-Sperren in dieser Reihenfolge, prüft die Platzgrenze, setzt das bestehende gemeinsame SDK/Gradle-Cache und archiviert den wirklichen Prozess-Exit. Fehlende/besetzte Sperren oder nicht gestartete Kindprozesse werden nicht als Testresultat behandelt.

Vorhandenes `observe-tests.init.gradle`, SHA256 `5c2471c275872167f60a2ada33f018d01921bb1c563608de00014b568a66fdeb`, erzwingt frische Testtaskausführung und schreibt die Fortschrittsdatei für den vorhandenen Timeoutschutz. Das ist beim fokussierten Lauf erforderlich; erneute Compilation aller unveränderten Tasks ist nicht die Fachbehauptung dieses Fokus. Der vollständige Androidlauf unten verwendet ausdrücklich `--rerun-tasks` und keinen Klassenfilter.

## 1. Einmaliger eigener RED nach reinem Testfreeze

Patch: `C1-PR529-tests.patch`, SHA256 `47e6ea92f473e2bc8f9d84e386eb64058cbd34fd8c7010e2c4ebc60146b09583`.
Die zwei Produktionsblobs müssen hierbei noch `beb0f37d8de8965984bf38846b6479e0137d2340` und `1c3a7543ebaa826b0105002c8bfe5e23fa1c0c84` sein. Fünf Klassen definieren 40 Methoden. Erwartete fachliche Fehler werden nicht vorab als Ergebnis eingetragen; maßgeblich sind die tatsächlichen frischen XMLs und unmittelbaren Exitcodes.

```sh
cd /workspace/scratch/174c84456ee3/continuum-c1
C1_LOCK_WAIT_SECONDS=900 python /workspace/scratch/174c84456ee3/qa/run_c1_gate_v3.py privacy024-own-red-01 \
  /workspace/scratch/b6ee64d418cf/toolchain/gradle-8.11.1/bin/gradle \
  --offline --no-daemon --no-build-cache --max-workers=1 --console=plain \
  -Pkotlin.compiler.execution.strategy=in-process -Pandroid.builder.sdkDownload=false \
  '-Dorg.gradle.jvmargs=-Xmx1536m -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Dfile.encoding=UTF-8' \
  --init-script /workspace/scratch/174c84456ee3/qa/observe-tests.init.gradle \
  -PcontinuumAuditProgressFile=/workspace/scratch/174c84456ee3/qa/privacy024-own-red-01.progress.json \
  -PcontinuumUiWidgetTests=true \
  :app:testDebugUnitTest \
  --tests at.heinz.deviceai.cockpit.CompiledMemoryOrbIntegrationTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialBoundaryTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialFramingTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialHoldoutTest \
  --tests at.heinz.deviceai.cognitive.MemoryPrivacyPrecedenceTest
```

Die Labels müssen neu sein; der Runner verweigert das Überschreiben vorhandener Belege. Bei einem nachgewiesenen Ausführungsabbruch den Originalbeleg erhalten und eine begründete neue Laufnummer verwenden. Die eingefrorenen Tests bleiben unverändert.

## 2. Eigener 15-Klassen-Fokus nach genau zwei Produktionsdateien

Produktpatch: `C1-PR529-production.patch`, SHA256 `580a908cfb10bf0c4ce07bfffef295119c4155e5567e5d3db0d6950893407770`.
Zielcompiler `0e4718176518131828688092ea95e894a1d4c2fa`, Ziel-MemoryEcology `3368e6939061d259e9c8b8c6d419e3dc71cabcaf`. Neuer sauberer Quellcommit; keine pauschale Ergebnisübertragung von #529. Bei unveränderten Testbytes sind 100 Fälle zu erwarten; 0 FAIL/ERROR/SKIP und Prozess-Exit 0 sind erst nach dem eigenen Lauf zu beurteilen.

```sh
cd /workspace/scratch/174c84456ee3/continuum-c1
C1_LOCK_WAIT_SECONDS=900 python /workspace/scratch/174c84456ee3/qa/run_c1_gate_v3.py privacy024-own-green-01 \
  /workspace/scratch/b6ee64d418cf/toolchain/gradle-8.11.1/bin/gradle \
  --offline --no-daemon --no-build-cache --max-workers=1 --console=plain \
  -Pkotlin.compiler.execution.strategy=in-process -Pandroid.builder.sdkDownload=false \
  '-Dorg.gradle.jvmargs=-Xmx1536m -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Dfile.encoding=UTF-8' \
  --init-script /workspace/scratch/174c84456ee3/qa/observe-tests.init.gradle \
  -PcontinuumAuditProgressFile=/workspace/scratch/174c84456ee3/qa/privacy024-own-green-01.progress.json \
  -PcontinuumUiWidgetTests=true \
  :app:testDebugUnitTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialBoundaryTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialHoldoutTest \
  --tests at.heinz.deviceai.cognitive.ContextCredentialFramingTest \
  --tests at.heinz.deviceai.cognitive.MemoryPrivacyPrecedenceTest \
  --tests at.heinz.deviceai.cognitive.MemoryEcologyTest \
  --tests at.heinz.deviceai.cognitive.AiContextCompilerTest \
  --tests at.heinz.deviceai.cognitive.AiContextIntegrityTest \
  --tests at.heinz.deviceai.cognitive.ContradictionBoundaryRegressionTest \
  --tests at.heinz.deviceai.cognitive.ContradictionBoundaryHoldoutTest \
  --tests at.heinz.deviceai.cognitive.ContinuumIntelligencePhase2Test \
  --tests at.heinz.deviceai.cognitive.MemoryRecallObservationTest \
  --tests at.heinz.deviceai.cockpit.CompiledMemoryOrbIntegrationTest \
  --tests at.heinz.deviceai.cockpit.MemoryEventMapperLifecycleRegressionTest \
  --tests at.heinz.deviceai.cockpit.ContinuumMemoryEventSourceIntegrationTest \
  --tests at.heinz.deviceai.MemoryRecallActivityUiTest \
  :app:lintDebug
```

Lint bleibt gemäß vorhandener Projektkonfiguration **NewApi-only**. Der echte XML-/Log-/Receiptbestand, Source vor/nach, Testdateihashes und unmittelbarer Exit sind zu sichern. 100 Fachfälle sind ein begrenzter Schwerpunkt, kein Gesamt-PASS.

## 3. Vollständiges gemeinsames Android-Gate erst am kombinierten Kandidaten

Dies ersetzt weder die übrigen Node-/Backend-/Hostgates noch den UI-/Suite-/Minima-Validator aus dem geltenden C1-Gateplan. Es ist der unterstützte vollständige Androidaufruf ohne Testfilter. Erst nach Abschluss der separaten C1-Slices und expliziter Quellbindung seriell planen.

```sh
cd /workspace/scratch/174c84456ee3/continuum-c1
C1_LOCK_WAIT_SECONDS=900 python /workspace/scratch/174c84456ee3/qa/run_c1_gate_v3.py privacy024-combined-android-full-01 \
  /workspace/scratch/b6ee64d418cf/toolchain/gradle-8.11.1/bin/gradle \
  --offline --no-daemon --no-build-cache --max-workers=1 --console=plain \
  -Pkotlin.compiler.execution.strategy=in-process -Pandroid.builder.sdkDownload=false \
  '-Dorg.gradle.jvmargs=-Xmx1536m -XX:ActiveProcessorCount=2 -XX:+UseSerialGC -Dfile.encoding=UTF-8' \
  --init-script /workspace/scratch/174c84456ee3/qa/observe-tests.init.gradle \
  -PcontinuumAuditProgressFile=/workspace/scratch/174c84456ee3/qa/privacy024-combined-android-full-01.progress.json \
  -PcontinuumUiWidgetTests=true \
  --rerun-tasks \
  :app:testDebugUnitTest \
  :app:lintDebug
```

Kein APK-Auftrag, keine Signierung, kein Modell-/Gerätetest ist in diesen Befehlen enthalten. Die gemeinsame APK-Entscheidung bleibt bei C1 nach tatsächlichem Abschluss sämtlicher Pflichtgates.
