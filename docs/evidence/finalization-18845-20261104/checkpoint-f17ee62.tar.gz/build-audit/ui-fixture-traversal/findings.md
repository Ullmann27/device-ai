# Android UI fixture diagnosis after the 92f421 focus run

## Observed result

Frozen source `92f421fa81c57022d903e2c1ff45ae6279c77b22`, tree `e6dc16a26b5926c36cade4b1c6afe3c9fe327989`: 53 executed JUnit cases, 46 pass, 7 failure, 0 skipped. The six fresh XML reports are archived in `../targeted-92f421fa81c5.reports.zip`. Source hashes, HEAD, tree and clean Git state matched before and after. All 25 new sequence lifecycle tests, all 12 daily boundary tests, the three adaptive cockpit tests and the original 2D fallback pixel/lifecycle case passed.

## Seven failures and narrowly scoped corrections proposed

| Existing assertion | Source-supported cause | Fixture correction |
|---|---|---|
| Avatar3dLifecycle: observed gaze after foreground activation | View rejects GazeObserved unless canAnimateFrame is true; paused first window traversal may still be pending | Finish an actual 16 ms window traversal and assert attached/shown/visible/exact dimensions before foreground activation; assert LIVE before gaze admission |
| AvatarNative: callbackCount after 200 ms | A single large idleFor jump delivers only one paused VSync, which can first perform the window traversal | Complete initial traversal; step the same total wait duration in at most 16 ms intervals |
| AvatarNative: visible mouth pixels | Renderer explicitly forces speak/jaw to zero when canAnimateFrame is false; duplicate timestamps also no longer resmooth the envelope | Establish and assert LIVE before all three snapshots; model the existing 33 ms PCM cadence on the unchanged real Director/View wall clock |
| Motion: phases advance over successive seconds | A large idleFor jump does not deliver all intervening paused VSyncs | Advance each original one-second interval in at most 16 ms steps |
| Motion: recovery after thermal pressure | Same discrete VSync issue, with production first-frame delta zero | Complete traversal and step the original one-second interval |
| Motion: visible foreground schedules rendering | Window traversal and actual attachment are required by canAnimateFrame | Assert real attachment/visibility after actual traversal before foreground activation |
| Motion: distinct phases change Orb pixels | Fresh View now defaults to the 3D head, while this existing test explicitly intends to test the original Orb | Select Orb through the existing public setNativeHeadEnabled(false) method, preserving production defaults |

The seven previous test failures did not log actual attachment and visibility flags. The framework bytecode and renderer gating support the lifecycle diagnosis, but the added precondition assertions and the next focused runtime run must confirm it. This report does not claim that the patch has passed.

## Framework and source evidence

The independently inspected, actually cached Robolectric 4.14.1 ActivityController bytecode shows that setup() already invokes visible(). Adding another visible() is therefore not the correction. Paused NativeDisplayEventReceiver.scheduleVsync stores the next VSync time, without putting a corresponding normal task deadline in the Looper queue. ShadowPausedLooper.idleFor can jump directly to the requested end time; its clock listener then delivers one VSync. Relevant independent bytecode dumps are in `../../integration-audit/paused-ui-diagnosis/`.

ContinuumHologramView.canAnimateFrame requires foregroundActive, motionAllowed, isAttachedToWindow, isShown and visible window state. The real renderer receives that predicate and zeroes mouth motion when it is false. An 8-callback burst at the same millisecond is not eight nominal frames under the current elapsed-time smoothing. AvatarDirector and the actual View render both use System.currentTimeMillis; advancing only a synthetic Director clock would inject future audio that the reducer correctly rejects. Seven short real 33 ms intervals preserve this common clock while the separately paused virtual VSync prevents unrelated idle-pose changes between the closed and stopped images.

## Patch boundaries and verification performed

Only the three existing UI fixture files are changed. Production code, renderer timing, mode defaults, pixel regions, pixel thresholds, phase bounds, interruption equality and lifecycle assertions remain unchanged. A line-multiset check confirms every original assertion line remains present. Stable viewport sizes are enforced by Activity.setContentView with fixed LayoutParams and assertions after actual traversal, replacing manual child layout that could later be overwritten by the window.

`git apply --check` succeeded on documentation-only parent `c92220c5468e2bd0e506b19267a9eed8b5739459`, with source still clean. Patch SHA-256 and per-file before/after hashes are in `manifest.json`. No Gradle run has yet been performed with these changes; root must first review, publish and freeze the exact next candidate.
