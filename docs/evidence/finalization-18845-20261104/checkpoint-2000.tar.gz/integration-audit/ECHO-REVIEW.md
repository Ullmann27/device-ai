# Unabhängige Abschlussprüfung: negative ECHO-Berichte

## Entscheidung und genau geprüfter Stand

Die drei Produktdateien und der zugehörige Negativtest aus [PR #515](https://github.com/Ullmann27/device-ai/pull/515) sind als eigener Vier-Dateien-Patch auf den lokalen #517-Prüfkandidaten übertragbar. Im beschriebenen Review- und Testumfang wurde kein bestätigter Blocker gefunden.

- Lokaler, unverändert gelesener Zielstand: `20f888660a967aa1d6b5446e892540538372d319`.
- Tatsächlich per GitHub-Connector gelesener Quellstand: `572e12ecc4ce5f7c79f2634a5b5773047b6d674f`.
- Kein Import des übrigen #515-Branches, seiner Branch-Erkundung, CLI, Scheduler-Änderung oder Repair-Critic-Änderung.
- #517 und fremde Arbeitsbäume wurden durch diese Prüfung nicht verändert. Die Tests liefen in zwei eigenen Modulsnapshots unter `integration-audit`.
- Der Stand nach einer späteren Übernahme benötigt seine eigenen kombinierten Abschlussgates.

## Kleinstes geprüftes Übernahmepaket

| Datei unter .github/continuum | Baseline-Blob | Geprüfter Quell-Blob |
|---|---|---|
| coding-orchestrator.mjs | c6927f90e510e8cb62e214655f84ff79e7901425 | 31f7a598d4d560e0374b9e8656446b30c512e611 |
| coding-service-worker.mjs | 0f6db2f363530124d0886c7bfc812a02f2099bc7 | 0d3097bd2b9422993849fb6882868e1d431b65b6 |
| coding-service-reader.mjs | 6368654ed693d2ada9622c45de0fd1942c24d9c8 | eef34b205f791e1b8e82871020635400addfbde4 |
| coding-orchestrator-failure-report.test.mjs | neu | 8ebcc0900571c78fdf279038a40fff7706a491be |

Alle Quellinhalte wurden erneut mit ihrer Git-Blob-SHA-1 verifiziert. Die Produktänderungen umfassen insgesamt 71 hinzugefügte und 18 entfernte Zeilen; dazu kommen 240 Zeilen Negativtests. Der vollständige Patch liegt in `echo515-four-file.patch`, SHA-256 `ab432d4782be02820ca40cb38dc5b9ae1a7b9610986b31b2c6e2be7bbaa599d2`.

`git apply --check --whitespace=error-all` gegen den unveränderten lokalen Zielstand: **PASS**. `node --check` für alle vier Dateien: **PASS**. Die zusätzlichen Importbindungen betreffen ausschließlich `codingTaskFailureResult` aus dem geänderten Orchestrator und das bereits vorhandene `assertCcc1BotAssignment`. Die bisher vorhandenen dynamischen Report-/Recall-Module bleiben erhalten. Kein fehlendes relatives Modul und kein Import zu Branch-Discovery, Branch-Bots-CLI oder dem geänderten Scheduler wurde festgestellt.

## Tatsächlicher FAIL→GREEN-Nachweis

Die Baseline bestand aus den unveränderten, aus dem Zielcommit archivierten Verzeichnissen `.github`, `scripts` und `tools`. Für den Baseline-Test wurden ausschließlich die zwei Testimports mit neuen API-Namen in Namespace-Imports umgeschrieben. Dadurch scheiterte der Test nicht bereits beim Laden wegen eines fehlenden Exports. Ausgeführt wurde genau der verhaltensbezogene Fall:

`strict observation failure exposes the canonical negative Echo report without learning`

Der bestehende `runCodingTask` wurde mit realen temporären Git-Repositories, kanonischem Grant, Bot-Zuordnung und CCC1-Journal ausgeführt. Die ursprüngliche Modellablehnung trat erwartungsgemäß ein. Die unmittelbar vorausgehende Prüfung des Journals auf `ABSTAINED` bestand. Anschließend scheiterte die erwartete Berichtsrückgabe: `error.botReport?.status` war **undefined** anstelle von **ABSTAINED**.

- Baseline: **0 PASS / 1 FAIL / 0 SKIP**, Node-Exitcode **1**.
- Mit exakt den vier Quell-Dateien: **9 PASS / 0 FAIL / 0 SKIP**, Node-Exitcode **0**, Laufzeit rund **5,2 Sekunden**.
- Runtime: **Node v24.22.1, Linux x64**.
- Der grüne Lauf verwendete den unveränderten vollständigen Upstream-Test; die Baseline-Importanpassung wurde dort nicht verwendet.
- Die Reparatur-Rekursionstiefenvariable war in diesen äußeren Läufen nicht gesetzt. Es wurden keine Gates deaktiviert.

Der grüne Lauf deckt ab:

1. Einen kanonischen negativen ECHO-Bericht trotz weiterhin geworfener strikter Modellablehnung, ohne Lernaufnahme.
2. Wiederholung ohne zusätzliche Inferenz, Ausführung oder Journaländerung.
3. Entzug des Reporter-Profils während des fehlgeschlagenen Versuchs.
4. Verhinderung eines Erfolgsberichts aus einem alten, früher abgeschlossenen Reparaturlauf.
5. Konkurrenz eines anderen Writers, ohne Wiederverwendung eines alten Erfolgs.
6. Authentifizierte private Speicherung für den Owner-Lookup unter Beibehaltung des Fehlers.
7. Zurückweisung nachgebildeter bzw. JSON-kopierter Fehler und Schutz des echten prozessgebundenen Resultats.
8. Beibehaltung des ursprünglichen Modellfehlers bei fehlgeschlagener Belegspeicherung; kein Überschreiben früherer Belege.
9. Nur den geprüften negativen Bericht im UNKNOWN-Owner-Lookup; kein künstliches Erfolgsresultat und weiterhin wirksamer Profilentzug.

Diese neun Fälle sind der gesamte gezielte grüne Lauf, nicht neun zusätzliche Fälle neben dessen Gesamtsumme.

## Statischer Befund zur Vertrauensgrenze

Der Orchestrator lässt nur einen von diesem Lauf beobachteten kanonischen `ABSTAINED`-Abschluss mit demselben Journal-Head in den negativen Berichtsweg. Der bestehende Reportwriter überprüft Reporterzuordnung, aktuellen Owner-Grant, Quellstand, Journal und Belegdatei erneut. Das resultierende Reportobjekt ist eingefroren. Das Resultat wird in einer prozessinternen `WeakMap` an das originale Fehlerobjekt gebunden; beliebige Error-Felder oder kopierte JSON-Daten begründen keine Berechtigung.

Der Service-Worker liest dieses Resultat nur bei einer echten gebundenen Ablehnung. Vor der Speicherung prüft er erneut Task-ID, CCC1-ID, Fingerprint, Source, aktuellen Grant und kanonischen Journal-Head. Er verwendet den vorhandenen CCC1-Schlüssel für den MAC und die vorhandene exklusive private Schreibfunktion. Auch nach erfolgreicher Belegspeicherung wirft er den ursprünglichen Fehler weiter. Die Service-Antwort wird dadurch nicht erfolgreich und die Ressourcenbarriere nicht aufgehoben.

Der Reader macht bei einer UNKNOWN-Zustellung nur den negativen Bericht auffindbar, wenn der kanonische Zustand ABSTAINED sowie Grant und Quelle aktuell sind. Der eigentliche Evidence-Leseweg prüft weiterhin MAC, Dateihash, kanonische Einträge, Receipts und Profile. Negative Berichte erzeugen in diesem Pfad keine erfolgreiche Reparatur, neue Experience oder Training.

## Belege und Grenzen

- `echo515-materialization.json`: gepinnte Source-/Target-Identitäten und alle Datei-Hashes.
- `echo515-static-checks.json`: Syntax- und lesender Apply-Check.
- `echo515-baseline.tap` / `echo515-baseline.result.json`: tatsächlicher Defekt vor dem Patch.
- `echo515-patched.tap` / `echo515-patched.result.json`: neun tatsächlich ausgeführte grüne Negativtests.
- `echo515-sources.json`: unveränderte, gepinnte GitHub-Quellinhalte.
- `historical-pr-inventory.json`: abgeschlossene frühere 25-PR-Inventur; spätere parallele Änderungen sind darin ausdrücklich nicht enthalten.

Diese Prüfung attestiert Host-Node-Logik und die genannten kanonischen Speicher-/Lesepfade. Die externe Docker-Ausführung wurde im Test kontrolliert als Fehlschlag ersetzt; die JVM-Profilabfrage im Owner-Reader-Fall verwendet eine dokumentierte Testantwort. Es wurde kein Container, lokales neuronales Modell, persistenter Owner-Worker oder Android-Gerät betrieben.

Der ältere S01-Ressourcenblocker, fehlende Live-Aktivierung und die Android-/APK-/Geräteabnahme werden durch diesen Patch nicht behoben. Der Testsnapshot ist kein vollständiger Android-Checkout. Es wurden keine Secrets, Paketsignaturen, Paketnamen, Releases oder Main geändert.

