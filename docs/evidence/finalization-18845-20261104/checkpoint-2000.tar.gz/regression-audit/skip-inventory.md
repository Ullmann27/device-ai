# Node skip inventory for frozen candidate 20f888660a967aa1d6b5446e892540538372d319

The initial full run reported 37 skipped tests. These are unavailable/unexecuted, never PASS.

| Group | Count |
|---|---:|
| Docker/profile integration | 1 |
| Docker integration | 5 |
| Official compiler/API dependencies | 3 |
| Actual JVM snapshot | 1 |
| Reviewed Harness SDK | 2 |
| Docker synthetic Gradle report contract | 1 |
| kotlinc CLI | 6 |
| Docker native transport | 1 |
| Kernel resource bounds | 3 |
| Native process isolation | 14 |

## Individual skips

1. **HOST SOFTWARE CONTRACT: real persisted Forge/Lint profiles receive distinct observed containers for builder and both verifier sites**
   - File: `.github/continuum/ccc1-bot-workspace-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1; actual configured Docker/pinned image; exact-source GENESIS_HANDOFF_CLASSPATH; GENESIS_ISOLATION_IMAGE.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

2. **HOST_INTEGRATION: two canonical worker jobs run in separate confined Docker workspaces**
   - File: `.github/continuum/ccc1-workspace-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1 and actual configured Docker/pinned image.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

3. **HOST_INTEGRATION: actual canonical worker claim admits RED, repaired GREEN and independent Docker runs**
   - File: `.github/continuum/ccc1-workspace-lifecycle-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1 and actual configured Docker/pinned image.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

4. **HOST_INTEGRATION: live canonical lease clamps the real Docker timeout**
   - File: `.github/continuum/ccc1-workspace-lifecycle-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1 and actual configured Docker/pinned image.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

5. **HOST_INTEGRATION: in-flight owner revocation suppresses the completed profile result at checkpoint**
   - File: `.github/continuum/ccc1-workspace-lifecycle-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1 and actual configured Docker/pinned image.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

6. **actual Android shell adapters compile against official APIs and the unchanged Binder contract**
   - File: `.github/continuum/cognitive-action-integration.test.mjs`
   - Prerequisites: CONTINUUM_FABRIC_JVM_DEPS points to existing flat regular official dependency JARs; shell compile also needs CONTINUUM_SHELL_ANDROID_DEPS. Runners: scripts/continuum-shell-android-compile.sh, scripts/continuum-cognitive-action-jvm.sh, scripts/continuum-dialogue-jvm.sh. JAVA_HOME/PATH official JDK17.
   - TAP reason: NOT_RUN: configure official Kotlin and Shizuku/annotation jars

7. **native natural request → actual tool → receipt → persisted episode, with negative regressions**
   - File: `.github/continuum/cognitive-action-integration.test.mjs`
   - Prerequisites: CONTINUUM_FABRIC_JVM_DEPS points to existing flat regular official dependency JARs; shell compile also needs CONTINUUM_SHELL_ANDROID_DEPS. Runners: scripts/continuum-shell-android-compile.sh, scripts/continuum-cognitive-action-jvm.sh, scripts/continuum-dialogue-jvm.sh. JAVA_HOME/PATH official JDK17.
   - TAP reason: NOT_RUN: set CONTINUUM_FABRIC_JVM_DEPS to run the real Kotlin graph

8. **actual memory, CRE1 and CTX3 graph preserves provenance and emits content-free traces**
   - File: `.github/continuum/cognitive-action-integration.test.mjs`
   - Prerequisites: CONTINUUM_FABRIC_JVM_DEPS points to existing flat regular official dependency JARs; shell compile also needs CONTINUUM_SHELL_ANDROID_DEPS. Runners: scripts/continuum-shell-android-compile.sh, scripts/continuum-cognitive-action-jvm.sh, scripts/continuum-dialogue-jvm.sh. JAVA_HOME/PATH official JDK17.
   - TAP reason: NOT_RUN: configure official Kotlin/JUnit jars

9. **native JVM export feeds Node byte-for-byte when cross-language runner is configured**
   - File: `.github/continuum/compute-fabric-model-adapter.test.mjs`
   - Prerequisites: Run scripts/continuum-fabric-jvm-check.sh <external-output-dir> with CONTINUUM_FABRIC_JVM_DEPS. Runner creates and passes CONTINUUM_FABRIC_SNAPSHOT_FILE.
   - TAP reason: Run scripts/continuum-fabric-jvm-check.sh for the actual JVM→Node test

10. **real Harness service preserves the existing strict wire schema without mounting tools**
   - File: `.github/continuum/harness-coding-provider.test.mjs`
   - Prerequisites: CONTINUUM_HARNESS_RUNTIME must point to actual reviewed SDK; no replacement harness used.
   - TAP reason: NOT_RUN: configure actual reviewed Harness SDK

11. **authority smuggling, no-op and HTTP failure remain rejected without hidden retries**
   - File: `.github/continuum/harness-coding-provider.test.mjs`
   - Prerequisites: CONTINUUM_HARNESS_RUNTIME must point to actual reviewed SDK; no replacement harness used.
   - TAP reason: NOT_RUN: actual SDK required

12. **fixed isolated Android runner rejects 401 reports instead of returning a green subset**
   - File: `.github/continuum/isolated-report-cap.test.mjs`
   - Prerequisites: CONTINUUM_TEST_ISOLATION_CONFIG points to real Docker config. Even when enabled this checks synthetic report counts, not an Android build.
   - TAP reason: Requires explicitly configured Docker; synthetic Gradle reports, not an Android build

13. **generated Kotlin code must compile RED before and GREEN after, then compute two expected outputs**
   - File: `.github/continuum/kotlin-delegate-acceptance.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

14. **wrong independent expected output rejects a compiling patch**
   - File: `.github/continuum/kotlin-delegate-acceptance.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

15. **an arbitrary red baseline is never accepted as proof of the requested missing method**
   - File: `.github/continuum/kotlin-delegate-acceptance.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

16. **new method compiles and computes a nontrivial result with real kotlinc**
   - File: `.github/continuum/kotlin-delegate-synthesizer.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

17. **HOST_INTEGRATION: typed dispatch binds actual canonical repair containers and refuses replay**
   - File: `.github/continuum/momega1-typed-workspace-host.test.mjs`
   - Prerequisites: CONTINUUM_WORKSPACE_HOST_PROOF=1 and actual configured Docker/pinned image.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

18. **owner Kotlin IMPLEMENT generates real reviewable Git patch with two independent JVM oracles**
   - File: `.github/continuum/owner-kotlin-preview.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

19. **false owner output cannot create a verified Kotlin preview**
   - File: `.github/continuum/owner-kotlin-preview.test.mjs`
   - Prerequisites: Successful official kotlinc -version in PATH and absent CONTINUUM_REPAIR_DEPTH.
   - TAP reason: Boolean skip flag; no reason text supplied by test.

20. **fixed Docker CLI transport rejects mismatched weights before native launch, with no observation**
   - File: `scripts/continuum-local-model-7b.test.mjs`
   - Prerequisites: Fixed Docker client, actual local daemon and pinned image; test does not pull images.
   - TAP reason: HOST_DOCKER_PROOF_NOT_RUN: fixed Docker client unavailable

21. **actual launcher gives exact private 7B profile two CPU seconds per remaining wall second**
   - File: `scripts/continuum-local-model-cpu.test.mjs`
   - Prerequisites: Actual cgroup/rlimit prerequisites inaccessible (ENOENT); setting an environment claim cannot replace them.
   - TAP reason: HOST_RESOURCE_PROOF_NOT_RUN: kernel prerequisite inaccessible: ENOENT

22. **two-thread CPU allowance leaves the existing wall cancellation deadline unchanged**
   - File: `scripts/continuum-local-model-cpu.test.mjs`
   - Prerequisites: Actual cgroup/rlimit prerequisites inaccessible (ENOENT); setting an environment claim cannot replace them.
   - TAP reason: HOST_RESOURCE_PROOF_NOT_RUN: kernel prerequisite inaccessible: ENOENT

23. **actual isolated synthetic ELF observes the new kernel CPU limit and unchanged native AS limit**
   - File: `scripts/continuum-local-model-cpu.test.mjs`
   - Prerequisites: Actual cgroup/rlimit prerequisites inaccessible (ENOENT); setting an environment claim cannot replace them.
   - TAP reason: HOST_RESOURCE_PROOF_NOT_RUN: kernel prerequisite inaccessible: ENOENT

24. **actual namespace binds admitted descriptors and fixture output; never inference evidence**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

25. **deadline cancels actual isolated process with bounded return**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

26. **STOP cancels actual isolated process and leaves no trusted observation**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

27. **malformed/oversized output and missing generation counters are rejected**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

28. **actual FD mount retains selected inode across model path replacement**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

29. **prompt evaluation counter alone cannot masquerade as output generation**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

30. **inference sandbox denies host files, external interfaces, secrets and writable model**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

31. **seccomp denies fork and rlimits bound native memory/descriptor budgets**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

32. **changing model during actual execution invalidates otherwise valid output**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

33. **production provider rejects synthetic fixture receipt even when transport MAC is valid**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

34. **native worker threads remain permitted while process creation stays denied**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

35. **process evidence classification cannot claim LOCAL_MODEL_HOST from a configured kind**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

36. **invalid model JSON retains authenticated process observation without a candidate**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

37. **provider retains authenticated rejected-response observation and consumed durable budget**
   - File: `scripts/continuum-local-model-observation.test.mjs`
   - Prerequisites: Actual root-owned non-writable bwrap/prlimit plus permitted network namespace. Observed uid65534 and NETLINK_ROUTE EPERM fail host policy; no policy bypass used.
   - TAP reason: HOST_ISOLATION_PROOF_NOT_RUN: /usr/bin/bwrap fails root-owned regular non-writable tool policy (uid=65534, mode=755); /usr/bin/prlimit fails root-owned regular non-writable tool policy (uid=65534, mode=755); bwrap: loopback: Failed to create NETLINK_ROUTE socket: Operation not permitted

## Additional tools scope

The separate 25-file tools run reported five additional skipped 7B CPU-policy cases in `tools/momega1-challenger/seven-b-cpu-contract.test.mjs`. They require `MOMEGA1_EXPECT_JOB_CAP=1` backed by actual kernel cgroup bounds. The flag was not asserted without that evidence.

Eleven tool files were excluded before execution, with exact filenames/reasons in `tools-final-command.json`: five historical frozen native review fixtures; three exact-source Kotlin/approved-runtime MCP integration suites; two actual service lifecycle suites requiring approved native runtime/classpath/isolation; one historical immutable final-promotion audit tied to commit fb0f8152cfe4e85b778c2f2ef17034b2ef6333be.

Host isolation failures in executed tool suites remain FAIL in their original TAP; they have not been relabelled as SKIP.
