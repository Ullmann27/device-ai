# Regression-Abnahme und minimale Reparaturen

## Verbindlicher Prüfstand

- Checkout: `/workspace/scratch/18845e31bc4a/continuum-finalization`
- Commit: `20f888660a967aa1d6b5446e892540538372d319`
- Tree: `ce1baced5aa5fa1c9c6648ef5dae84c831f806d3`
- Node: `v24.22.1`; jeweils `--test --test-concurrency=1 --test-reporter=tap`.
- Quellen vor und nach beiden vollständigen Sätzen clean und SHA-/Tree-identisch. Keine Quelldatei dieses Checkouts geändert.
- Kein Gradle, keine APK-Erstellung/-Installation/-Signierung, kein Release, kein Merge, kein Training, keine bezahlte API/CI. Backend lag separat bei Root.

## Tatsächlich ausgeführte vollständige Sätze

| Scope | Dateien | Tests | PASS | FAIL | SKIP | Laufzeit | Exit |
|---|---:|---:|---:|---:|---:|---:|---:|
| `.github/continuum/**/*.test.mjs` und `scripts/*.test.mjs` | 322 | 2342 | 2273 | 32 | 37 | 453.970 s | 1 |
| Geeignete zusätzliche `tools/**/*.test.mjs` | 25 | 296 | 219 | 72 | 5 | 22.967 s | 1 |

Beide Sätze haben null cancelled/todo. Sie wurden nacheinander ausgeführt. Vollständige exakte Argumentlisten, UTC-Zeiten, Node-Version und Vorher-/Nachherzustand stehen in `node-final-command.json` bzw. `tools-final-command.json`; die Dateilisten in den jeweiligen `*-files.txt`. Ungekürzte TAP-Protokolle: `node-final.tap` und `tools-final.tap`. Die entsprechenden `*-summary.json` enthalten SHA-256 der Rohlogs, Footer, FirstFailure und sämtliche Fehler-/Skip-Zeilen.

FirstFailure des Hauptlaufs: `.github/continuum/aaa-cockpit-and-effects.test.mjs:21` fordert `ContinuumHomeLayout.phone` im heutigen `ContinuumHomeView`. Die Diagnose/Korrektur dieser Datei gehört Root. Die nachstehenden Zahlen bleiben rote Originalergebnisse; erfolgreiche Reparaturproben ersetzen diese nicht rückwirkend.

Der frühere 18/18-Lauf in `owner-update-baseline.tap` lief ausschließlich auf `8abea828833d8833d40e3d3d36feaa6d3685b82e` und wird nicht als kombinierte Endabnahme gezählt.

## Echter Fehler am QA-Eingang

`scripts/render-continuum-owner-continuous-qa.sh` ließ `CONTINUUM_MENTOR_SIGNING_P12_BASE64` aus der bestehenden Liste verbotener Signing-Variablen aus. Eine getrennte Probe aller sechs Variablen in beiden QA-Modi verwendete ausschließlich `fixture-not-a-key` und einen lokalen Fake-`curl`, der protokolliert und mit Exit97 stoppt. Ergebnis: 10 PASS / 2 FAIL. In beiden Mentor-Base64-Fällen wurden bereits QA-Logs und Buildverzeichnis erstellt und die Downloadstelle erreicht. Keine echte Signatur, kein echter Download, kein Schlüsselzugriff.

Unabhängig bereits erledigter Fremdfix: PR #505, Commit `84cd8cfc05dedef5d4feb28ecfa103530e95f7ff`, GitHub-Dateiblob `9ea8eae2011504b5283a0cf4e62231f0aaa7c39b`. Der unveränderlich gelesene Produktionsfix ist exakt identisch mit meiner vorbereiteten Guard-Ergänzung; auch der restliche Skriptinhalt stimmt überein. Produktionsänderung daher #505 zuordnen und nur einmal übernehmen. Vergleich: `remote-505-guard-comparison.json`.

`qa-signing-exclusion.patch` enthält zusätzlich die Erweiterung des vorhandenen Preflight-Vertrags: alle sechs Signing-Variablen in beiden Modi, mit Ablehnung vor Download, Logs und Buildverzeichnis. Der korrigierte vorhandene Satz bestand **43/43**, null SKIP/FAIL. Die vorherigen 32 Fälle bleiben enthalten. Belege: `qa-signing-exclusion.probe.tap`, `qa-signing-exclusion.fixed.tap`.

## Eigene Korrekturen der Quellverträge

Alle Änderungen liegen ausschließlich als Patches und kleine Kopien unter `proposed-root`; dessen `app` verweist lesend auf den unveränderten Checkout. Jeder Patch bestand `git apply --check` gegen 20f.

| Patch | Diagnose und erhaltene Schranke | Tatsächliche Reparaturprobe |
|---|---|---|
| `android-integration-wiring.patch` | Alte Stringregeln übersehen den neuen Bot-Zweig. `AgentActivity.kt:7789` gibt Bots den unveränderten Auftrag; der bisherige FollowUp-Pfad bleibt erhalten. :8007 verlangt vor privatem Memory sowohl `codingPlanning == null` als auch `botTask == null`. :8024 setzt Planung weiter auf null Toolaufrufe/Retry. Test wird an diesen strengeren Pfad gebunden. | 21/21 PASS, `android-integration-wiring.proposed.log` |
| `trace-context-speech-contracts.patch` | Trace-Aufrufe führen jetzt Promptlänge/Deadline mit, bleiben am selben `turnTrace` gebunden. Früherer Chatbezug ist zusätzlich durch `botTask == null` begrenzt. Deutsches On-device-STT nutzt weiterhin `de-AT`; die alte Regex scheiterte an einem Leerzeichen. Entwicklerroute läuft über die vorhandene Mehr-Kategorie, `JarvisMenu` und `openHomeSlot`; sämtliche Übergänge werden geprüft. | 11/11 PASS, `trace-context-speech-contracts.proposed.tap` |
| `learning-readout-contract.patch` | `ContinuumLearningCore.kt:134` übergibt jetzt `automaticRecovery` an denselben getrennten Experience-Store. Encoderdatei, Knowledge-Archiv und Store bleiben getrennt. | 5/5 PASS im Protokoll `tool-memory-fixtures.proposed.tap` |

Vier zusätzliche synthetische Quellmutationen wurden jeweils erwartungsgemäß rot: ownerTurn auf aufgelösten Kontext ändern; Bot-Schranke vor privatem Memory entfernen; `turnTrace` aus Generierung entfernen; `de-AT` durch `en-US` ersetzen. Die unveränderten Quellen wurden dafür nur im Arbeitsspeicher transformiert. `negative-contract-controls.json` enthält Mutation, Befehl und Ergebnis; Rohlogs `negative-owner-input.tap`, `negative-bot-memory.tap`, `negative-trace-drop.tap`, `negative-speech-locale.tap`. Diese sind Negativkontrollen und keine zusätzlichen erfolgreichen Produktionstests.

Vorhandene Laufzeittests, die die fachlichen Grenzen ausdrücken: `ContinuumBotToolTaskUiTest.readyTaskUsesCurrentPersonaAndCompleteOwnerTextWithoutPrivateContext`, `LocalFollowUpTaskFrameTest`, `OwnerMemoryRecoveryTest`, `CognitiveTurnTraceTest`, `JarvisMenuNavigationTest`. Diese Kotlin-/Robolectric-Tests wurden von mir nicht ausgeführt; der separate Buildbot muss deren tatsächlichen Lauf belegen.

## Tool-Rot und Reparaturgrenze

Von den ursprünglichen 72 Tool-Fehlern sind **38 echte Host-Voraussetzungsblockaden**: 19 native Tests in `tools/momega1-challenger/runtime-review.test.mjs` scheitern an `BLOCKED_LOCAL_ISOLATION_UNAVAILABLE`; 6 in `tools/momega1-workspace-review/adversarial.test.mjs` und 13 in `claim-adversarial.test.mjs` an `ISOLATION_UNAVAILABLE`. Der Host meldet u. a. root-owned-Policy-Verletzung für bwrap/prlimit (uid65534) und NETLINK_ROUTE-EPERM. Diese Fehler bleiben im TAP FAIL. Keine OS-/Trust-Policy wurde gelockert, kein Docker oder Native-Harness nachgebildet.

Die übrigen ursprünglichen 34 Fehler sind veraltete Testfixtures/-Erwartungen: 33 einzelne Memory-Vertragsfehler und ein Importabbruch der Caller-Datei. Der aktuelle Produktionsvalidator verlangt zu Recht `verifiedModelExecution === true`; das alte synthetische Positivfixture enthielt dieses Feld nicht. Der Caller-Unit-Loader leitete außerdem den neuen `assertCcc1BotAssignment`-Import an einen alten Stub ohne diesen Export um.

`tool-memory-fixtures.patch` verändert ausschließlich drei Dateien unter `tools/momega1-memory-review/tests`:

- `fixture.mjs`: explizites synthetisches positives Feld, weiterhin klar als CONTRACT_TEST ohne Inferenz markiert; kein Produktions-Brand wird dadurch erzeugt.
- `caller-accounting.test.mjs`: echter Bot-Assignment-Import bleibt erhalten. Accounting der exakten Repair-Funktionskörper wird über einen ausschließlich unitlokalen TEST-ONLY-Brand-Prüfer getestet; übrige realen Imports und numerische RED/GREEN-Prüfung bleiben bestehen. Die Namen sagen ausdrücklich `UNIT TEST-ONLY BRAND`.
- `challenge.test.mjs`: moderne read-only Brand-Prüfer dürfen exportiert werden, müssen synthetische/fremde/kopierte Objekte ablehnen.

Der erste Reparaturlauf (fünf Memory-Testdateien plus Readout) hatte 112 Tests, 107 PASS und fünf weitere Diagnosefehler. Nach Korrektur nur dieser beiden zuletzt betroffenen Testdateien bestand der zielgerichtete Lauf **60/60**, null SKIP/FAIL (`tool-memory-fixtures.fixed.tap`). Die anderen drei Memory-Dateien plus Readout waren im vorherigen Lauf bereits grün und wurden nicht erneut nur zum Zählen ausgeführt.

Wesentliche zusätzliche echte Negativkontrolle: `I18 PRODUCTION refuses foreign test WeakSet brand despite a valid numeric patch` ruft die **unveränderte** Produktions-`repairSession` auf. Der numerische Patch darf unabhängig RED/GREEN bestehen; `verifiedModelExecution` bleibt trotzdem false, `modelInvocations` und `modelId` bleiben null. Diese Kontrolle und die direkten Produktions-Prüfer gegen kopierte Belege bestanden. Der positive Unit-Slot ist kein Nachweis positiver Produktions- oder nativer Modellannahme.

## Unvollständige Voraussetzungen / getrennte Host-Aufträge

`skip-inventory.md` und `node-skip-inventory.json` inventarisieren jeden der 37 Hauptlauf-Skips. Gruppen: sechs Docker-/Profil-Integrationsfälle; drei offizielle Compiler/API-JAR-Fälle; ein echter JVM-Snapshot; zwei Harness-SDK-Fälle; ein Docker-Vertrag mit synthetischen Gradle-Reports; sechs kotlinc-CLI-Fälle; ein Docker-Nativtransport; drei Kernel-Ressourcenfälle; 14 native Isolationsfälle. Zusätzlich fünf Tool-CPU-Skips mangels tatsächlicher Job-Cgroup-Begrenzung.

Elf Tool-Dateien wurden vor Ausführung mit dokumentierter Begründung ausgeschlossen: fünf historische frozen native-review-Fixtures; drei MCP-Integrationsdateien mit exakt kompiliertem Kotlin-/genehmigtem Runtime-Artefakt; zwei tatsächliche Service-Lifecycle-Dateien mit Runtime/Isolation/Classpath; eine unveränderliche historische Promotion-Prüfung, die einen anderen festen HEAD verlangt. Exakte Liste in `tools-final-command.json`. Ausschlüsse sind weder PASS noch nachträglich erzeugte TAP-SKIPs.

Vorhandene sinnvolle Compiler-Gates, getrennt von Docker:

```sh
# Mit offiziellen vorhandenen JDK17-/Kotlin-/Android-/JUnit-/Shizuku-JARs.
# CONTINUUM_FABRIC_JVM_DEPS und CONTINUUM_SHELL_ANDROID_DEPS müssen
# auf vorhandene flache Verzeichnisse regulärer passender JAR-Dateien zeigen.
node --test --test-concurrency=1 --test-reporter=tap   .github/continuum/cognitive-action-integration.test.mjs
bash scripts/continuum-fabric-jvm-check.sh /EXTERNAL_OUTPUT_DIRECTORY
```

Der erste Befehl aktiviert `continuum-shell-android-compile.sh`, `continuum-cognitive-action-jvm.sh` und `continuum-dialogue-jvm.sh`. Der zweite erzeugt den JVM-Snapshot selbst und übergibt `CONTINUUM_FABRIC_SNAPSHOT_FILE` an den Node-Vertrag. Laut Roots neuem Umgebungsbefund fehlt bislang die vom Runner erwartete nicht instrumentierte `android-all-15.jar`; instrumentierte JARs/API-Stubs wurden hier nicht als Ersatz eingesetzt.

Die sechs kotlinc-Skips lassen sich mit einem erfolgreichen offiziellen `kotlinc -version` im PATH und ohne `CONTINUUM_REPAIR_DEPTH` gezielt aktivieren:

```sh
node --test --test-concurrency=1 --test-reporter=tap   .github/continuum/kotlin-delegate-acceptance.test.mjs   .github/continuum/kotlin-delegate-synthesizer.test.mjs   .github/continuum/owner-kotlin-preview.test.mjs
```

## Wiederholbare gezielte Abnahme nach Integration

Nach Roots koordiniertem Source-Wechsel und neu dokumentiertem festem SHA:

```sh
node --test --test-concurrency=1 --test-reporter=tap   .github/continuum/android-integration-wiring.test.mjs   .github/continuum/cognitive-trace-wiring.test.mjs   .github/continuum/continuum-local-dialogue-quality-wiring.test.mjs   .github/continuum/coding-agent-speech-wiring.test.mjs   scripts/continuum-learning-parity-readout.test.mjs   scripts/continuum-owner-continuous-qa-preflight.test.mjs
MOMEGA1_CANDIDATE_ROOT="$PWD" node --test --test-concurrency=1 --test-reporter=tap   tools/momega1-memory-review/tests/*.test.mjs
```

Die initiale vollständige Node-Argumentliste lässt sich aus `node-final-command.json` wiederverwenden; alle bestehenden Dateien werden dort explizit genannt. Ein voller neuer Satz ist erst nach koordiniertem Einspielen aller Quellen-/Testkorrekturen sinnvoll. Root besitzt Avatar/Cockpit, Integrationsbot die UI/Fold/Layout-Verträge; deren Änderungen sind nicht Teil meines Pakets.

## Alle roten Hauptlauf-Dateien

| Datei | Fehler |
|---|---:|
| `.github/continuum/aaa-cockpit-and-effects.test.mjs` | 1 |
| `.github/continuum/android-avatar-wiring.test.mjs` | 1 |
| `.github/continuum/android-holographic-home.test.mjs` | 4 |
| `.github/continuum/android-integration-wiring.test.mjs` | 1 |
| `.github/continuum/app-navigation-wiring.test.mjs` | 5 |
| `.github/continuum/coding-agent-speech-wiring.test.mjs` | 2 |
| `.github/continuum/cognitive-trace-wiring.test.mjs` | 1 |
| `.github/continuum/continuum-fold7-hologram-live-diagnostics.test.mjs` | 1 |
| `.github/continuum/continuum-local-dialogue-quality-wiring.test.mjs` | 1 |
| `.github/continuum/fold-responsive-reflow.test.mjs` | 3 |
| `.github/continuum/fold7-portrait-reference.test.mjs` | 5 |
| `.github/continuum/mobile-builder-existing-integration.test.mjs` | 1 |
| `.github/continuum/nexus-beginner-ui.test.mjs` | 1 |
| `.github/continuum/premium-phone-viewport-wiring.test.mjs` | 2 |
| `scripts/continuum-learning-parity-readout.test.mjs` | 1 |
| `scripts/continuum-ui-routing.test.mjs` | 2 |

## Abnahmeaussage

Der unveränderte Kandidat20f hat eine vollständig dokumentierte, aber rote Host-Regression. Es gibt geprüfte minimale Reparaturen und klar getrennte Umgebungsblockaden. Die neue kombinierte Regression nach Integration, ein tatsächliches APK-Artefakt, Originalsignatur, VersionCode-Abgleich mit dem Gerät und die reale Offline/Dialog-/Avatar-/Upgrade-Geräteabnahme bleiben getrennt zu belegen. Kein positiver Hostvertrag ist eine produktive Veröffentlichung oder Gerätefreigabe.
