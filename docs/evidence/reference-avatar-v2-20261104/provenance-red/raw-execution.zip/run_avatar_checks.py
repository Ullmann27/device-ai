import json
import pathlib
import re
import subprocess
import sys

root = pathlib.Path('/workspace/scratch/acc992a972a4/device-ai-avatar')
cache = pathlib.Path('/workspace/scratch/d663e8444310/gradle-cache/caches/modules-2/files-2.1')
out = pathlib.Path('/workspace/scratch/acc992a972a4/qa') / sys.argv[1]
out.mkdir(parents=True, exist_ok=True)
java = '/workspace/scratch/b6ee64d418cf/toolchain/jdk17/bin/java'

def jar(group, artifact, version):
    matches = list((cache / group / artifact / version).glob('*/' + artifact + '-' + version + '.jar'))
    if len(matches) != 1:
        raise RuntimeError(f'Expected one jar for {group}:{artifact}:{version}, got {matches}')
    return str(matches[0])

stdlib = jar('org.jetbrains.kotlin', 'kotlin-stdlib', '2.4.0')
annotations = jar('org.jetbrains', 'annotations', '13.0')
compile_cp = ':'.join([
    jar('org.jetbrains.kotlin', 'kotlin-compiler-embeddable', '2.4.0'), stdlib,
    jar('org.jetbrains.kotlin', 'kotlin-reflect', '2.4.0'),
    jar('org.jetbrains.kotlin', 'kotlin-script-runtime', '2.4.0'),
    jar('org.jetbrains.kotlinx', 'kotlinx-coroutines-core-jvm', '1.11.0'), annotations])
test_cp = ':'.join([stdlib, annotations,
    jar('junit', 'junit', '4.13.2'), jar('org.hamcrest', 'hamcrest-core', '1.3'),
    jar('org.json', 'json', '20240303')])
source_root = root / 'app/src/main/java/at/heinz/deviceai'
sources = [source_root / name for name in [
    'avatar/AvatarContract.kt', 'avatar/AvatarDirector.kt',
    'avatar3d/AvatarGlbContract.kt', 'avatar3d/AvatarMorphMapper.kt',
    'avatar3d/AvatarIdleMotion.kt']]
tests = sorted((root / 'app/src/test/java/at/heinz/deviceai/avatar').glob('*.kt'))
tests += sorted((root / 'app/src/test/java/at/heinz/deviceai/avatar3d').glob('*.kt'))
classes = []
for path in tests:
    text = path.read_text()
    package = re.search(r'^package ([\w.]+)', text, re.M).group(1)
    classes += [package + '.' + name for name in re.findall(r'^class (\w+)', text, re.M)]
sources += tests + [root / 'tools/fable-avatar-motion-check/Main.kt', root / 'tools/epsilon-avatar-contract/ValidateAvatarGlb.kt']
target = out / 'tests.jar'
commands = [
    [java, '-Xmx768m', '-cp', compile_cp, 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
     '-no-stdlib', '-no-reflect', '-classpath', test_cp, '-jvm-target', '17',
     '-d', str(target)] + [str(p) for p in sources],
    [java, '-cp', str(target) + ':' + test_cp, 'org.junit.runner.JUnitCore'] + classes,
    [java, '-cp', str(target) + ':' + test_cp, 'at.heinz.deviceai.avatar3d.MainKt']]
(out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
codes = {}
for name, command in zip(['compile', 'junit', 'motion'], commands):
    result = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (name + '.log')).write_text(result.stdout)
    codes[name] = result.returncode
    print(name + ': exit=' + str(result.returncode), flush=True)
    print(result.stdout, flush=True)
    if name == 'compile' and result.returncode:
        break
(out / 'results.json').write_text(json.dumps(codes, indent=2) + '\n')
sys.exit(0 if codes and all(v == 0 for v in codes.values()) else 1)
