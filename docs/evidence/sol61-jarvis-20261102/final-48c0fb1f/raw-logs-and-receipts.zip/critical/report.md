<!-- coderabbit-ai-generated:v1 -->

# Continuum reliability QA

Scope: critical. Status: **PASS**. Commit: 48c0fb1f2b4db06619e170bf36f8d070e002eca4.

Node 22.16.0; linux/x64. Source unchanged during run: true.

| Check | Severity | Status | Exit | PASS / FAIL / SKIP |
|---|---|---|---|---|
| process | P0 | PASS | 0 | 37 / 0 / 0 |
| storage-agent | P0 | PASS | 0 | 32 / 0 / 0 |
| android-source-contracts | P1 | PASS | 0 | 64 / 0 / 0 |
| host-checker | P0 | PASS | 0 | 2 / 0 / 0 |
| gradle | P0 | NOT_RUN | — | — / — / — |
| lint | P0 | NOT_RUN | — | — / — / — |
| apk | P0 | NOT_RUN | — | — / — / — |
| fold7 | P0 | NOT_RUN | — | — / — / — |
| model-inference | P0 | NOT_RUN | — | — / — / — |

PASS applies only to executed tests in the selected scope. JSON contains commands, case identities, diagnostics, source hashes and original process outcomes. Gradle/lint/APK/device/model inference remain NOT_RUN. No signing or deployment.

<!-- /coderabbit-ai-generated:v1 -->
