<!-- coderabbit-ai-generated:v1 -->

# Continuum reliability QA

Scope: full-node. Status: **FAIL**. Commit: 62b3aa90f0b418db4522249d967bfa1bca5b4f3a.

Node 22.16.0; linux/x64. Source unchanged during run: true.

| Check | Severity | Status | Exit | PASS / FAIL / SKIP |
|---|---|---|---|---|
| full-node | P0 | FAIL | 1 | 1968 / 1 / 13 |
| gradle | P0 | NOT_RUN | — | — / — / — |
| lint | P0 | NOT_RUN | — | — / — / — |
| apk | P0 | NOT_RUN | — | — / — / — |
| fold7 | P0 | NOT_RUN | — | — / — / — |
| model-inference | P0 | NOT_RUN | — | — / — / — |

PASS applies only to executed tests in the selected scope. JSON contains commands, case identities, diagnostics, source hashes and original process outcomes. Gradle/lint/APK/device/model inference remain NOT_RUN. No signing or deployment.

<!-- /coderabbit-ai-generated:v1 -->
